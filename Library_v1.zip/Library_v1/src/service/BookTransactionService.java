package service;

import enums.BookCopyStatus;
import enums.BookStatus;
import enums.TransactionStatus;
import enums.UserRole;
import model.Book;
import model.BookCopy;
import model.Transaction;
import model.User;
import repository.BookCopyRepository;
import repository.BookRepository;
import repository.DataStore;
import repository.TransactionRepository;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class BookTransactionService {
    private final BookRepository books;
    private final BookCopyRepository copies;
    private final TransactionRepository transactions;
    private final PolicyService policy;
    private final AuditService auditService;
    private final NotificationService notificationService;
    private final FineService fineService;
    private final OverdueFineSchedulerService overdueFineSchedulerService;
    private final repository.UserRepository userRepository;



    public BookTransactionService(BookRepository books, BookCopyRepository copies, TransactionRepository transactions, PolicyService policy,
    AuditService auditService, NotificationService notificationService, FineService fineService, repository.UserRepository userRepository) {
        this.books=books;
        this.copies=copies;
        this.transactions=transactions;
        this.policy=policy;
        this.auditService=auditService;
        this.notificationService=notificationService;
        this.fineService=fineService;
        this.userRepository=userRepository;
        if (fineService != null && notificationService != null) {
            this.overdueFineSchedulerService = new OverdueFineSchedulerService(transactions, books, fineService, notificationService, userRepository);
            this.overdueFineSchedulerService.startScheduler();
        } else {
            this.overdueFineSchedulerService = null;
        }
    }

    private void sendUserNotification(String phone, String message) {
        if (notificationService == null || phone == null || phone.isBlank()) return;
        String normalizedPhone = phone.trim();
        User user = userRepository != null ? userRepository.findByPhone(normalizedPhone) : null;
        if (user != null) {
            notificationService.send(user, message);
        } else {
            notificationService.send(normalizedPhone, message);
        }
    }



    private void record(String phone, String action, Transaction t, String details) {
        if (auditService != null) auditService.record(phone, action, "TRANSACTION", String.valueOf(t.getTransactionId()), details);
    }



    private boolean hasActiveTransactionForBook(String phone, int bookId) {
        for (Transaction transaction : transactions.findByUserPhone(phone)) {
            if (transaction.getBookId() == bookId && transaction.isActive()) {
                return true;
            }
        }
        return false;
    }

    public List<String> getRequestFailureReasons(String phone, String isbn) {
        List<String> failures = new java.util.ArrayList<>();
        if (phone == null || phone.isBlank() || isbn == null || isbn.isBlank()) {
            failures.add("Member phone, ISBN are required.");
            return failures;
        }

        String normalizedPhone = phone.trim();
        Book book = books.findByIsbn(isbn.trim());
        if (book == null) {
            failures.add("Book not found.");
        } else if (book.getStatus() == BookStatus.REMOVED) {
            failures.add("This book has been removed and is not available for new requests.");
        }

        User targetMember = userRepository == null ? null : userRepository.findByPhone(normalizedPhone);
        if (targetMember == null || targetMember.getRole() != enums.UserRole.MEMBER) {
            failures.add("The selected account is not a member.");
        } else {
            if (book != null && hasActiveTransactionForBook(normalizedPhone, book.getBookId())) {
                failures.add("This member already has an active request or loan for this book.");
            }
            failures.addAll(policy.getBorrowingEligibilityFailureReasons(normalizedPhone));
        }
        return failures;
    }

    public Transaction requestBookByIsbn(String phone, String isbn, User caller) {
        String normalizedIsbn = isbn == null ? null : isbn.trim();
        String normalizedPhone = phone == null ? null : phone.trim();
        List<String> failures = getRequestFailureReasons(normalizedPhone, normalizedIsbn);
        if (!failures.isEmpty()) {
            throw new IllegalStateException(String.join("\n- ", failures));
        }
        Book book = books.findByIsbn(normalizedIsbn);
        Transaction transaction = new Transaction(DataStore.getTransactionId(), normalizedPhone, book.getBookId());
        transactions.save(transaction);
        record(caller.getPhone(), "BOOK_REQUESTED", transaction, "Book ID " + book.getBookId());
        autoReserveAvailableCopies(book.getBookId());
        Transaction updated = transactions.findById(transaction.getTransactionId());
        if (updated == null || updated.getStatus() != TransactionStatus.RESERVED) {
            sendUserNotification(normalizedPhone, "Your request is queued.");
        }
        return updated == null ? transaction : updated;

    }

    public boolean markReadyForPickup(int transactionId, User staff) {
        if (getMarkReadyFailureReason(transactionId, staff) != null) return false;
        Transaction t = transactions.findById(transactionId);
        if (t == null) return false;
        t.markReadyForPickup();
        transactions.save(t);
        record(staff.getPhone(), "BOOK_READY_FOR_PICKUP", t, "Copy ID " + t.getBookCopyId());
        sendUserNotification(t.getUserPhone(), "Your requested book is ready for pickup.");
        return true;
    }




    public String issueBookWithResult(int transactionId, User librarian) {
        if (!policy.canManageInventory(librarian)) {
            return "Not allowed.";
        }
        Transaction t = transactions.findById(transactionId);
        if (t == null) {
            return "Transaction not found.";
        }
        if (t.getStatus() != TransactionStatus.READY_FOR_PICKUP) {
            return "Book is not ready for pickup.";
        }
        List<String> eligibilityFailures = policy.getIssueEligibilityFailureReasons(t.getUserPhone());
        if (!eligibilityFailures.isEmpty()) {
            return "Member not eligible: " + String.join(", ", eligibilityFailures);
        }
        BookCopy copy = copies.findById(t.getBookCopyId());
        if (copy == null) {
            return "Reserved copy not found.";
        }
        if (copy.getStatus() != BookCopyStatus.RESERVED) {
            return "Copy is not reserved.";
        }
        if (copy.getBookId() != t.getBookId()) {
            return "Copy does not match loan.";
        }
        t.issue(LocalDate.now().plusDays(policy.getLoanPeriodDaysForUser(t.getUserPhone())));
        copy.issue();
        copies.save(copy);
        transactions.save(t);
        record(librarian.getPhone(), "BOOK_ISSUED", t, "Copy ID " + copy.getBookCopyId() + ", due " + t.getDueDate());
        sendUserNotification(t.getUserPhone(), "Book issued. Due date: " + t.getDueDate());
        return null;
    }




    private void applyCopyCondition(BookCopy copy, Transaction transaction, User librarian,
                                    boolean lost, String identifiedMemberPhone) {
        int bookCopyId = copy.getBookCopyId();
        String librarianPhone = librarian.getPhone();
        boolean wasIssued = transaction != null && transaction.getStatus() == TransactionStatus.ISSUED;
        boolean identifiedMember = identifiedMemberPhone != null && !identifiedMemberPhone.isBlank();
        String action = lost ? "BOOK_COPY_MARKED_LOST" : "BOOK_COPY_MARKED_DAMAGED";

        if (transaction != null) {
            if (wasIssued && identifiedMember && !identifiedMemberPhone.equals(transaction.getUserPhone())) {
                throw new IllegalStateException("The identified member does not match the issued loan.");
            }
            if (wasIssued) {
                if (lost) transaction.markLost();
                else transaction.markDamaged();
                transactions.save(transaction);
            } else if (transaction.getStatus() == TransactionStatus.RESERVED
                    || transaction.getStatus() == TransactionStatus.READY_FOR_PICKUP) {
                transactions.save(transaction);
            }
        }

        if (lost) copy.markLost();
        else copy.markDamaged();
        copies.save(copy);

        if (identifiedMember && fineService != null) {
            if (wasIssued) {
                if (lost) fineService.createLostBookFine(transaction.getTransactionId());
                else fineService.createDamagedBookFine(transaction.getTransactionId());
                sendUserNotification(transaction.getUserPhone(), lost
                        ? "Your issued book has been marked lost. Please check your outstanding fine."
                        : "Your issued book has been marked damaged. Please check your outstanding fine.");
            } else {
                if (lost) fineService.createLostBookIncidentFineForMember(identifiedMemberPhone);
                else fineService.createDamagedBookIncidentFineForMember(identifiedMemberPhone);
                sendUserNotification(identifiedMemberPhone, lost
                        ? "A lost-book incident fine has been assigned to your account."
                        : "A damaged-book incident fine has been assigned to your account.");
            }
        }

        if (auditService != null) {
            String details = "Copy marked " + (lost ? "lost" : "damaged") + " by staff";
            if (transaction != null) details += "; transaction ID " + transaction.getTransactionId();
            if (identifiedMember) details += "; fine assigned to member " + identifiedMemberPhone;
            auditService.record(librarianPhone, action, "BOOK_COPY", String.valueOf(bookCopyId), details);
            if (!identifiedMember) {
                auditService.record(librarianPhone, "UNIDENTIFIED_BOOK_INCIDENT", "BOOK_COPY",
                        String.valueOf(bookCopyId), "Copy marked " + (lost ? "lost" : "damaged")
                                + " without assigning a member fine");
            }
        }
    }

    public String processReturnWithResult(int transactionId, int condition, User staff) {
        if (!policy.canManageInventory(staff)) return "Not allowed.";
        Transaction transaction = transactions.findById(transactionId);
        if (transaction == null) return "Transaction not found.";
        if (transaction.getStatus() != TransactionStatus.ISSUED) return "Loan is not issued.";
        BookCopy copy = copies.findById(transaction.getBookCopyId());
        if (copy.getStatus() != BookCopyStatus.ISSUED) return "Copy is not issued.";
        if (condition < 1 || condition > 3) return "Invalid condition.";
        LocalDate asOfDate = LocalDate.now();
        if (transaction.getDueDate() != null && asOfDate.isAfter(transaction.getDueDate()) && fineService == null) {
            return "Fine service unavailable.";
        }
        if (asOfDate.isAfter(transaction.getDueDate())) {
            fineService.createOverdueFine(transaction.getTransactionId(), asOfDate);
        }
        if (condition == 1) {

            transaction.returnBook();
            copy.returnCopy();
            copies.save(copy);
            transactions.save(transaction);
            record(staff.getPhone(), "BOOK_RETURNED", transaction, "Copy ID " + copy.getBookCopyId());
            sendUserNotification(transaction.getUserPhone(), "Your returned book has been processed successfully.");
            autoReserveAvailableCopies(transaction.getBookId());
            return null;
        }

        boolean lost = condition == 3;

        if (lost) transaction.markLost();
        else transaction.markDamaged();
        transactions.save(transaction);
        if (lost) copy.markLost();
        else copy.markDamaged();
        copies.save(copy);
        if (lost) fineService.createLostBookFine(transaction.getTransactionId());
        else fineService.createDamagedBookFine(transaction.getTransactionId());
        record(staff.getPhone(), lost ? "BOOK_COPY_MARKED_LOST" : "BOOK_COPY_MARKED_DAMAGED", transaction,
                "Copy ID " + copy.getBookCopyId());
        sendUserNotification(transaction.getUserPhone(), lost
                ? "Your issued book has been marked lost. Please check your outstanding fine."
                : "Your issued book has been marked damaged. Please check your outstanding fine.");
        autoReserveAvailableCopies(transaction.getBookId());
        return null;
    }



    public void cancelRequest(String phone, String isbn, User caller) {
        if (phone == null || phone.isBlank() || isbn == null || isbn.isBlank() || caller == null) {
            throw new IllegalStateException("Member phone, ISBN, and acting user are required.");
        }

        String normalizedPhone = phone.trim();
        String normalizedIsbn = isbn.trim();
        List<String> failures = new ArrayList<>();

        User targetMember =userRepository.findByPhone(normalizedPhone);
        if (targetMember == null || targetMember.getRole() != UserRole.MEMBER) {
            failures.add("A valid member must be selected.");
        }

        Book book = books.findByIsbn(normalizedIsbn);
        if (book == null) {
            failures.add("Book with ISBN '" + normalizedIsbn + "' not found in the catalogue.");
        }

        if (!failures.isEmpty()) {
            throw new IllegalStateException(String.join("\n- ", failures));
        }

        Transaction match = null;
        for (Transaction transaction : transactions.findByUserPhone(normalizedPhone)) {
            if (transaction.getBookId() != book.getBookId()) continue;

            TransactionStatus status = transaction.getStatus();
            if (status != TransactionStatus.REQUESTED
                    && status != TransactionStatus.RESERVED
                    && status != TransactionStatus.READY_FOR_PICKUP) continue;

            match = transaction;
            break;
        }

        if (match == null) {
            throw new IllegalStateException("No cancellable request was found for this ISBN. The request may already be issued, returned, cancelled, or expired.");
        }
        int bookId = match.getBookId();
        int copyId = match.getBookCopyId();
        match.cancel();
        if (copyId > 0) {
            BookCopy copy = copies.findById(copyId);
            if (copy != null && copy.getStatus() == BookCopyStatus.RESERVED) {
                copy.releaseReservation();
                copies.save(copy);
            }
        }
        transactions.save(match);
        record(caller.getPhone(), "BOOK_REQUEST_CANCELLED", match, "Copy ID " + copyId);
        sendUserNotification(match.getUserPhone(), "Request cancelled.");
        autoReserveAvailableCopies(bookId);
        
    }




    public List<String> getRenewFailureReasons(int transactionId, User caller) {
        List<String> failures = new java.util.ArrayList<>();
        Transaction transaction = transactions.findById(transactionId);
        if (transaction == null) {
            failures.add("Loan transaction with ID " + transactionId + " not found.");
            return failures;
        }
        if (transaction.getStatus() != TransactionStatus.ISSUED) {
            failures.add("Loan is not active.");
            return failures;
        }
        if (transaction.getDueDate() == null) {
            failures.add("Loan has no due date. Staff review is required before renewal.");
        } else if (transaction.isOverdue()) {
            long days = java.time.temporal.ChronoUnit.DAYS.between(transaction.getDueDate(), LocalDate.now());
            failures.add("Loan overdue by " + days + " day(s). Return it and settle fines.");
        }
        if (fineService != null && fineService.hasPendingFineForUser(transaction.getUserPhone())) {
            failures.add("Settle outstanding fines first.");
        }
        failures.addAll(policy.getBorrowingEligibilityFailureReasons(transaction.getUserPhone()));
        return failures;
    }





    public boolean renewBook(String phone, String isbn, User caller) {
        if (phone == null || phone.isBlank() || isbn == null || isbn.isBlank() || caller == null) {
            throw new IllegalStateException("Member phone, ISBN, and acting user are required.");
        }

        String normalizedPhone = phone.trim();
        List<String> failures = new java.util.ArrayList<>();

        User targetMember = userRepository == null ? null : userRepository.findByPhone(normalizedPhone);
        if (targetMember == null || targetMember.getRole() != enums.UserRole.MEMBER) {
            failures.add("A valid member must be selected.");
        }

        Book book = books.findByIsbn(isbn.trim());
        if (book == null) {
            failures.add("Book not found.");
        }

        if (!failures.isEmpty()) {
            throw new IllegalStateException(String.join("\n- ", failures));
        }

        Transaction transaction = findUniqueIssuedLoanForBook(normalizedPhone, book.getBookId());
        if (transaction == null) {
            throw new IllegalStateException("No unique active issued loan found for '" + book.getTitle()
                    + "'. The loan may not exist or duplicate active loans may need staff review.");
        }

        List<String> renewalFailures = getRenewFailureReasons(transaction.getTransactionId(), caller);
        if (!renewalFailures.isEmpty()) {
            throw new IllegalStateException(String.join("\n- ", renewalFailures));
        }
        transaction.renew(transaction.getDueDate().plusDays(policy.getLoanPeriodDaysForUser(transaction.getUserPhone())));
        transactions.save(transaction);
        record(caller.getPhone(), "BOOK_RENEWED", transaction, "New due date " + transaction.getDueDate());
        sendUserNotification(transaction.getUserPhone(), "Book renewed. New due date: " + transaction.getDueDate());
        return true;
    }



    public Transaction findTransactionById(int transactionId) {
        return transactions.findById(transactionId);
    }

    public String getPendingRequestsFailureReason(User staff) {
        return policy.canManageInventory(staff) ? null : "Not allowed.";
    }

    public List<Transaction> getAllPendingRequests(User staff) {
        if (getPendingRequestsFailureReason(staff) != null) return new java.util.ArrayList<>();
        return findPendingRequests();
    }

    public List<Transaction> getReservedRequestsForPickup(User staff) {
        List<Transaction> result = new java.util.ArrayList<>();
        for (Transaction transaction : getAllPendingRequests(staff)) {
            if (transaction.getStatus() == TransactionStatus.RESERVED) result.add(transaction);
        }
        return result;
    }

    public List<Transaction> getReadyForPickupRequests(User staff) {
        List<Transaction> result = new java.util.ArrayList<>();
        for (Transaction transaction : getAllPendingRequests(staff)) {
            if (transaction.getStatus() == TransactionStatus.READY_FOR_PICKUP) result.add(transaction);
        }
        return result;
    }

    public Transaction findUniqueIssuedLoanForBook(String phone, int bookId) {
        if (phone == null || phone.isBlank()) {
            return null;
        }
        Transaction match = null;
        for (Transaction transaction : transactions.findByUserPhone(phone.trim())) {
            if (transaction.getBookId() == bookId && transaction.getStatus() == TransactionStatus.ISSUED) {

                match = transaction;
                break;
            }
        }
        return match;
    }


    private List<Transaction> findPendingRequests() {
        java.util.List<Transaction> result = new java.util.ArrayList<>();
        java.util.List<Transaction> requested = new java.util.ArrayList<>();
        java.util.List<Transaction> other = new java.util.ArrayList<>();
        for (Transaction transaction : transactions.findAll()) {
            if (transaction.getStatus() == TransactionStatus.REQUESTED) {
                requested.add(transaction);
            } else if (transaction.getStatus() == TransactionStatus.RESERVED
                    || transaction.getStatus() == TransactionStatus.READY_FOR_PICKUP) {
                other.add(transaction);
            }
        }
        requested.sort(getRequestPriorityComparator());
        result.addAll(requested);
        result.addAll(other);
        return result;
    }

    public List<Transaction> getCurrentlyBorrowedBooks(String phone) {
        if (phone == null || phone.isBlank()) return new java.util.ArrayList<>();
        return findCurrentlyBorrowedBooks(phone.trim());
    }






    private java.util.List<Transaction> findCurrentlyBorrowedBooks(String phone) {
        java.util.List<Transaction> result = new java.util.ArrayList<>();
        for (Transaction transaction : transactions.findByUserPhone(phone)) {
            if (transaction.getStatus() == TransactionStatus.ISSUED) result.add(transaction);
        }
        return result;
    }

    public java.util.List<Transaction> getBorrowingHistory(String phone) {
        if (phone == null || phone.isBlank()) return new java.util.ArrayList<>();
        return transactions.findByUserPhone(phone.trim());
    }






    public Transaction getNextEligibleRequest(int bookId) {
        java.util.List<Transaction> candidates = new java.util.ArrayList<>();
        for (Transaction t : transactions.findQueuedRequestsByBookId(bookId)) {
            if (t.getStatus() == TransactionStatus.REQUESTED
                    && policy.getBorrowingEligibilityFailureReasons(t.getUserPhone()).isEmpty()) {
                candidates.add(t);
            }
        }
        if (candidates.isEmpty()) {
            return null;
        }
        candidates.sort(getRequestPriorityComparator());
        return candidates.get(0);
    }

    public Transaction getNextEligibleRequest(int bookId, User staff) {
        if (!policy.canManageInventory(staff)) return null;
        return getNextEligibleRequest(bookId);
    }

    private java.util.Comparator<Transaction> getRequestPriorityComparator() {
        return (t1, t2) -> {
            int p1 = policy != null ? policy.getRequestQueuePriority(t1.getUserPhone()) : 2;
            int p2 = policy != null ? policy.getRequestQueuePriority(t2.getUserPhone()) : 2;
            if (p1 != p2) {
                return Integer.compare(p1, p2);
            }
            if (t1.getRequestDate() != null && t2.getRequestDate() != null) {
                int dateCmp = t1.getRequestDate().compareTo(t2.getRequestDate());
                if (dateCmp != 0) {
                    return dateCmp;
                }
            }
            return Integer.compare(t1.getTransactionId(), t2.getTransactionId());
        };
    }

    private void autoReserveAvailableCopies(int bookId) {
        Book book = books.findById(bookId);
        if (book == null || book.getStatus() == BookStatus.REMOVED) return;
        while (true) {
            BookCopy copy = copies.findAvailableCopy(bookId);
            if (copy == null) return;

            Transaction next = getNextEligibleRequest(bookId);
            if (next == null) return;
            if (transactions.findActiveByCopyId(copy.getBookCopyId()) != null) return;
            try {
                copy.reserve();
                next.reserve(copy.getBookCopyId());
                copies.save(copy);
                transactions.save(next);
                record("SYSTEM", "BOOK_COPY_AUTO_RESERVED", next, "Copy ID " + copy.getBookCopyId());
                sendUserNotification(next.getUserPhone(), "Your book is reserved for pickup.");
            } catch (RuntimeException ex) {
                return;
            }
        }
    }

    public String getMarkReadyFailureReason(int transactionId, User staff) {
        if (!policy.canManageInventory(staff)) {
            return "Not allowed.";
        }

        Transaction t = transactions.findById(transactionId);
        if (t == null) {
            return "Transaction not found.";
        }
        if (t.getStatus() != TransactionStatus.RESERVED) {
            return "Request is not reserved.";
        }
        BookCopy copy = copies.findById(t.getBookCopyId());
        if (copy == null) {
            return "Reserved copy not found.";
        }
        if (copy.getStatus() != BookCopyStatus.RESERVED) {
            return "Copy is not reserved.";
        }
        if (copy.getBookId() != t.getBookId()) {
            return "Copy does not match request.";
        }
        Transaction copyRequest = transactions.findActiveByCopyId(copy.getBookCopyId());
        if (copyRequest == null || copyRequest.getTransactionId() != t.getTransactionId()) {
            return "Reserved copy is not allocated to this request.";
        }
        return null;
    }


    public Transaction findIssuedLoansForReturn(String memberPhone, String isbn, User staff) {
        java.util.List<Transaction> result = new java.util.ArrayList<>();
        if (!policy.canManageInventory(staff) || memberPhone == null || memberPhone.isBlank()
                || isbn == null || isbn.isBlank()) {
            return null;
        }
        Book book = books.findByIsbn(isbn.trim());
        if (book == null) return null;
        String normalizedPhone = memberPhone.trim();
        for (Transaction transaction : transactions.findByUserPhone(normalizedPhone)) {
            if (transaction.getBookId() == book.getBookId()
                    && transaction.getStatus() == TransactionStatus.ISSUED) {
                BookCopy copy = copies.findById(transaction.getBookCopyId());
                if (copy != null && copy.getStatus() == BookCopyStatus.ISSUED
                        && copy.getBookId() == transaction.getBookId()) {
                    return transaction;
                }
            }
        }
        return  null;
    }

    public String getReturnFailureReason(int transactionId, User staff) {
        if (!policy.canManageInventory(staff)) {
            return "Not allowed.";
        }
        Transaction t = transactions.findById(transactionId);
        if (t == null) {
            return "Transaction not found.";
        }
        if (t.getStatus() != TransactionStatus.ISSUED) {
            return "Loan is not issued.";
        }
        BookCopy copy = copies.findById(t.getBookCopyId());
        if (copy == null) {
            return "Book copy not found.";
        }
        if (copy.getStatus() != BookCopyStatus.ISSUED) {
            return "Copy is not issued.";
        }
        if (copy.getBookId() != t.getBookId()) {
            return "Copy does not match loan.";
        }
        LocalDate asOfDate = overdueFineSchedulerService != null ? overdueFineSchedulerService.getCurrentDate() : LocalDate.now();
        if (t.getDueDate() != null && asOfDate.isAfter(t.getDueDate()) && fineService == null) {
            return "Fine service unavailable.";
        }
        return null;
    }

    public String processCopyIncidentWithResult(int bookCopyId, String memberPhone, boolean lost, boolean borrowerConfirmed, User caller) {
        try {
            if (!policy.canManageInventory(caller)) return "Not allowed.";
            BookCopy copy = copies.findById(bookCopyId);
            if (copy == null) return "Copy not found.";
            if (copy.getStatus() == BookCopyStatus.LOST) return "Copy already marked lost.";
            if (copy.getStatus() == BookCopyStatus.DAMAGED) return "Copy already marked damaged.";

            Transaction transaction = transactions.findActiveByCopyId(bookCopyId);
            boolean identified = memberPhone != null;
            if (identified) {
                if (memberPhone.isBlank()) return "Member phone number is required.";
                User member = userRepository == null ? null : userRepository.findByPhone(memberPhone.trim());
                if (member == null || member.getRole() != UserRole.MEMBER) return "Member not found.";
                if (borrowerConfirmed) {
                    String validation = getBorrowerCopyIncidentFailureReason(bookCopyId, memberPhone);
                    if (validation != null) return validation;
                }
            }

            applyCopyCondition(copy, transaction, caller, lost, identified ? memberPhone.trim() : null);
            return null;
        } catch (RuntimeException e) {
            return "Unable to process copy incident. Please check the copy status and try again.";
        }
    }

    public String getBorrowerCopyIncidentFailureReason(int bookCopyId, String memberPhone) {
        if (memberPhone == null || memberPhone.isBlank()) {
            return "Member phone number is required.";
        }
        User member = userRepository == null ? null : userRepository.findByPhone(memberPhone.trim());
        if (member == null || member.getRole() != UserRole.MEMBER) {
            return "Member not found.";
        }
        for (Transaction transaction : transactions.findAll()) {
            if (transaction.getBookCopyId() == bookCopyId
                    && memberPhone.trim().equals(transaction.getUserPhone())
                    && (transaction.getStatus() == TransactionStatus.ISSUED
                    || transaction.getStatus() == TransactionStatus.RETURNED
                    || transaction.getStatus() == TransactionStatus.LOST
                    || transaction.getStatus() == TransactionStatus.DAMAGED)) {
                return null;
            }
        }
        return "No borrowing transaction for this copy was found for the identified member.";
    }

    public String getIdentifiedCopyIncidentFailureReason(int bookCopyId, String memberPhone) {
        if (memberPhone == null || memberPhone.isBlank()) {
            return "Member phone number is required.";
        }
        User member = userRepository == null ? null : userRepository.findByPhone(memberPhone.trim());
        if (member == null || member.getRole() != enums.UserRole.MEMBER) {
            return "Member not found.";
        }
        Transaction active = transactions.findActiveByCopyId(bookCopyId);
        if (active == null || active.getStatus() != TransactionStatus.ISSUED
                || !memberPhone.trim().equals(active.getUserPhone())) {
            return "No matching issued loan.";
        }
        return null;
    }

    public String getMarkConditionFailureReason(int bookCopyId, User librarian, boolean lost) {
        if (!policy.canManageInventory(librarian)) {
            return "Not allowed.";
        }
        BookCopy copy = copies.findById(bookCopyId);
        if (copy == null) {
            return "Copy not found.";
        }
        if (copy.getStatus() == BookCopyStatus.LOST) {
            return "Copy already marked lost.";
        }
        if (copy.getStatus() == BookCopyStatus.DAMAGED) {
            return "Copy already marked damaged.";
        }
        Transaction transaction = transactions.findActiveByCopyId(bookCopyId);
        boolean wasIssued = transaction != null && transaction.getStatus() == TransactionStatus.ISSUED;
        if (wasIssued && fineService == null) {
            return "Fine service unavailable.";
        }
        if (copy.getStatus() == BookCopyStatus.RESERVED && transaction == null) {
            return "Reservation record missing.";
        }
        if (transaction != null && transaction.getStatus() == TransactionStatus.ISSUED && copy.getStatus() != BookCopyStatus.ISSUED) {
            return "Copy status does not match loan.";
        }
        if (transaction != null && (transaction.getStatus() == TransactionStatus.RESERVED || transaction.getStatus() == TransactionStatus.READY_FOR_PICKUP) && copy.getStatus() != BookCopyStatus.RESERVED) {
            return "Copy status does not match reservation.";
        }
        return null;
    }
}
