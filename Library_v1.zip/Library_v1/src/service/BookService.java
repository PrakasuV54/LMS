package service;

import model.Book;
import model.BookCopy;
import model.User;
import model.Author;
import model.Genre;
import enums.BookCopyStatus;
import enums.BookStatus;
import repository.AuthorRepository;
import repository.BookCopyRepository;
import repository.BookRepository;
import repository.DataStore;
import repository.GenreRepository;
import repository.TransactionRepository;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class BookService {
    private final BookRepository books;
    private final BookCopyRepository copies;
    private final AuditService auditService;
    private final AuthorRepository authorRepository;
    private final GenreRepository genreRepository;

    public BookService(BookRepository books, BookCopyRepository copies, TransactionRepository transactions,
                       AuditService auditService, AuthorRepository authorRepository, GenreRepository genreRepository) {
        this.books = books;
        this.copies = copies;
        this.auditService = auditService;
        this.authorRepository = authorRepository;
        this.genreRepository = genreRepository;
    }


    public List<Book> getAllBooks() {
        return books.findAll();
    }

    public Book getBookById(int bookId) {
        return books.findById(bookId);
    }

    public Book getBookByIsbn(String isbn) {
        return books.findByIsbn(isbn);
    }

    public List<Book> searchBooks(String query) {
        return books.search(query);
    }

    public List<Book> searchById(int bookId) {
        Book book = books.findById(bookId);
        List<Book> result = new ArrayList<>();
        if (book != null && book.getStatus() == BookStatus.ACTIVE) {
            result.add(book);
        }
        return result;
    }

    public List<Book> searchByIsbn(String isbn) {
        if (isbn == null || isbn.isBlank()) return new ArrayList<>();
        Book book = books.findByIsbn(isbn.trim());
        List<Book> result = new ArrayList<>();
        if (book != null && book.getStatus() == BookStatus.ACTIVE) {
            result.add(book);
        }
        return result;
    }

    public List<Book> searchByTitle(String title) {
        return books.findByTitle(title);
    }

    public List<Book> searchByAuthor(String author) {
        return books.findByAuthor(author);
    }

    public List<Book> searchByGenre(String genre) {
        return books.findByGenre(genre);
    }

    public List<Book> searchByPublisher(String publisher) {
        return books.findByPublisher(publisher);
    }

    public List<Book> searchByDescription(String description) {
        return books.findByDescription(description);
    }

    public List<Book> searchByPublicationYear(int year) {
        return books.findByPublicationYear(year);
    }

    public List<Book> searchByField(String field, String query) {
        if (query == null || field == null) return new ArrayList<>();
        String q = query.trim();
        if (q.isEmpty()) return new ArrayList<>();
        String f = field.trim().toLowerCase();
        if (f.equals("id") ) {
            try {
                int id = Integer.parseInt(q);
                return searchById(id);
            } catch (NumberFormatException e) {
                return new ArrayList<>();
            }
        }
        if (f.equals("isbn")) {
            return searchByIsbn(q);
        }
        if (f.equals("title")) {
            return searchByTitle(q);
        }
        if (f.equals("author") ) {
            return searchByAuthor(q);
        }
        if (f.equals("genre") ) {
            return searchByGenre(q);
        }
        if (f.equals("publisher")) {
            return searchByPublisher(q);
        }
        if (f.equals("description")) {
            return searchByDescription(q);
        }
        if (f.equals("year")) {
            try {
                int year = Integer.parseInt(q);
                return searchByPublicationYear(year);
            } catch (NumberFormatException e) {
                return new ArrayList<>();
            }
        }
        return new ArrayList<>();
    }

    
    public String getFormattedBookDetails(int bookId) {
        Book book = books.findById(bookId);
        if (book == null || book.getStatus() == BookStatus.REMOVED) return null;

        StringBuilder sb = new StringBuilder();
        sb.append("----------------------------------------\n");
        sb.append("Book Details\n");
        sb.append("----------------------------------------\n");
        sb.append("Book ID: ").append(book.getBookId()).append("\n");
        sb.append("ISBN: ").append(book.getIsbn()).append("\n");
        sb.append("Title: ").append(book.getTitle()).append("\n");
        sb.append("Status: ").append(book.getStatus()).append("\n");
        String authorsStr = book.getAuthorsString();
        sb.append("Authors: ").append(authorsStr.isEmpty() ? "N/A" : authorsStr).append("\n");
        String genresStr = book.getGenresString();
        sb.append("Genres: ").append(genresStr.isEmpty() ? "N/A" : genresStr).append("\n");

        sb.append("Publisher: ").append(book.getPublisher() != null && !book.getPublisher().isBlank() ? book.getPublisher() : "N/A").append("\n");
        sb.append("Publication Year: ").append(book.getPublicationYear()).append("\n");
        if (book.getDescription() != null && !book.getDescription().isBlank()) {
            sb.append("Description: ").append(book.getDescription()).append("\n");
        }

        List<BookCopy> copyList = copies.findByBookId(bookId);
        sb.append("\nPhysical Copy Availability:\n");
        sb.append("Total Copies: ").append(copyList.size()).append("\n");
        int available = 0, reserved = 0, issued = 0, lost = 0, damaged = 0;
        for (BookCopy c : copyList) {
            if (c.getStatus() == BookCopyStatus.AVAILABLE) available++;
            else if (c.getStatus() == BookCopyStatus.RESERVED) reserved++;
            else if (c.getStatus() == BookCopyStatus.ISSUED) issued++;
            else if (c.getStatus() == BookCopyStatus.LOST) lost++;
            else if (c.getStatus() == BookCopyStatus.DAMAGED) damaged++;
        }
        sb.append("  - Available: ").append(available).append("\n");
        sb.append("  - Reserved: ").append(reserved).append("\n");
        sb.append("  - Issued: ").append(issued).append("\n");
        sb.append("  - Lost: ").append(lost).append("\n");
        sb.append("  - Damaged: ").append(damaged).append("\n");
        sb.append("----------------------------------------");
        return sb.toString();
    }

    public static List<String> parseNames(String input) {
        List<String> result = new ArrayList<>();
        if (input == null || input.isBlank()) {
            return result;
        }
        Set<String> seen = new java.util.HashSet<>();
        for (String token : input.split(",")) {
            String trimmed = token.trim();
            if (!trimmed.isEmpty() && seen.add(trimmed.toLowerCase())) {
                result.add(trimmed);
            }
        }
        return result;
    }

    public Author getOrCreateAuthor(String name) {
        if (name == null || name.isBlank()) return null;
        String trimmed = name.trim();
        Author existing = authorRepository.findByName(trimmed);
        if (existing != null) return existing;
        Author created = new Author(DataStore.getAuthorId(), trimmed);
        authorRepository.save(created);
        return created;
    }

    public Genre getOrCreateGenre(String name) {
        if (name == null || name.isBlank()) return null;
        String trimmed = name.trim();
        Genre existing = genreRepository.findByName(trimmed);
        if (existing != null) return existing;
        Genre created = new Genre(DataStore.getGenreId(), trimmed);
        genreRepository.save(created);
        return created;
    }

    private String normalizeIsbn(String isbn) {
        if (isbn == null) return null;
        String value = isbn.replace("-", "").replace(" ", "").trim().toUpperCase();
        if (value.length() == 10) {
            int sum = 0;
            for (int i = 0; i < 9; i++) {
                char c = value.charAt(i);
                if (c < '0' || c > '9') return null;
                sum += (c - '0') * (10 - i);
            }
            char check = value.charAt(9);
            int checkValue;
            if (check == 'X') checkValue = 10;
            else if (check >= '0' && check <= '9') checkValue = check - '0';
            else return null;
            sum += checkValue;
            return sum % 11 == 0 ? value : null;
        }
        if (value.length() == 13) {
            int sum = 0;
            for (int i = 0; i < 13; i++) {
                char c = value.charAt(i);
                if (c < '0' || c > '9') return null;
                int digit = c - '0';
                sum += digit * (i % 2 == 0 ? 1 : 3);
            }
            return sum % 10 == 0 ? value : null;
        }
        return null;
    }

    public String addBookFromDetails(String isbn, String title, String authorInput,
                                     String genreInput, String publisher, int year,
                                     String description, int numberOfCopies, User librarian) {
        List<String> errors = new ArrayList<>();
        if (!canManageCatalogue(librarian)) {
            errors.add("Insufficient permissions. Staff authorization required.");
        }
        String normalizedIsbn = normalizeIsbn(isbn);
        if (isbn == null || isbn.isBlank()) {
            errors.add("ISBN cannot be empty.");
        } else if (normalizedIsbn == null) {
            errors.add("Invalid ISBN. Enter a valid ISBN-10 or ISBN-13 with a correct check digit.");
        } else if (books.findByIsbn(normalizedIsbn) != null) {
            errors.add("A book with ISBN '" + normalizedIsbn + "' already exists in the catalogue.");
        }
        if (title == null || title.isBlank()) {
            errors.add("Title cannot be empty.");
        }
        if (publisher == null || publisher.isBlank()) {
            errors.add("Publisher cannot be empty.");
        }
        if (year < 1 || year > java.time.Year.now().getValue() + 1) {
            errors.add("Publication year is invalid.");
        }
        List<String> authors = parseNames(authorInput);
        if (authors.isEmpty()) {
            errors.add("At least one author is required.");
        }
        if (numberOfCopies < 1) {
            errors.add("Number of copies must be at least 1.");
        }

        if (!errors.isEmpty()) {
            StringBuilder sb = new StringBuilder("Unable to add book:");
            for (String err : errors) {
                sb.append("\n- ").append(err);
            }
            return sb.toString();
        }

        Book book;
        try {
            book = new Book(normalizeIsbn(isbn), title.trim(), publisher.trim(), year,
                             description.trim());
        } catch (IllegalArgumentException ex) {
            return "Unable to add book:\n- " + ex.getMessage();
        }

        for (String authorName : authors) {
            book.addAuthor(getOrCreateAuthor(authorName));
        }

        for (String genreName : parseNames(genreInput)) {
            book.addGenre(getOrCreateGenre(genreName));
        }

        saveBookAndCopies(book, numberOfCopies, librarian);
        return "Book added successfully";
    }

    public String addCopiesToExistingBook(int bookId, int numberOfCopies, User librarian) {
        if (!canManageCatalogue(librarian)) {
            return "Unable to add copies: Insufficient permissions. Staff authorization required.";
        }
        if (numberOfCopies < 1) {
            return "Unable to add copies: Number of copies must be at least 1.";
        }
        Book book = books.findById(bookId);
        if (book == null || book.getStatus() == BookStatus.REMOVED) {
            return "Unable to add copies: No active book found with ID " + bookId + ".";
        }

        for (int i = 0; i < numberOfCopies; i++) {
            BookCopy copy = new BookCopy(DataStore.getBookCopyId(), book.getBookId());
            copies.save(copy);
        }
        record(librarian.getPhone(), "BOOK_COPIES_ADDED", book, "Copies added: " + numberOfCopies);
        return "Successfully added " + numberOfCopies + " copy/copies to Book ID " + bookId + ".";
    }

    public boolean addBook(Book book, int numberOfCopies, User librarian) {
        if (!canManageCatalogue(librarian) || book == null || numberOfCopies < 1) {
            return false;
        }
        if (book.getIsbn() == null || book.getIsbn().isBlank() || books.findByIsbn(book.getIsbn().trim()) != null) {
            return false;
        }
        if (book.getTitle() == null || book.getTitle().isBlank() || book.getPublisher() == null || book.getPublisher().isBlank()) {
            return false;
        }
        if (book.getPublicationYear() < 1 || book.getPublicationYear() > java.time.Year.now().getValue() + 1) {
            return false;
        }
        if (book.getAuthors().isEmpty()) {
            return false;
        }

        for (Author a : book.getAuthors()) {
            if (a != null && authorRepository.findByName(a.getName()) == null && authorRepository.findById(a.getAuthorId()) == null) {
                authorRepository.save(a);
            }
        }

        for (Genre g : book.getGenres()) {
            if (g != null && genreRepository.findByName(g.getName()) == null && genreRepository.findById(g.getGenreId()) == null) {
                genreRepository.save(g);
            }
        }

        saveBookAndCopies(book, numberOfCopies, librarian);
        return true;
    }

    private void saveBookAndCopies(Book book, int numberOfCopies, User librarian) {
        books.save(book);
        for (int i = 0; i < numberOfCopies; i++) {
            BookCopy copy = new BookCopy(DataStore.getBookCopyId(), book.getBookId());
            copies.save(copy);
        }
        record(librarian.getPhone(), "BOOK_ADDED", book, "Copies added: " + numberOfCopies);
    }

    public String removeBookCopy(int copyId, User librarian) {
        if (!canManageCatalogue(librarian)) {
            return "Unable to remove copy: Insufficient permissions. Staff authorization required.";
        }
        BookCopy copy = copies.findById(copyId);
        if (copy == null) {
            return "Unable to remove copy: Copy not found with ID: " + copyId;
        }
        if (copy.getStatus() == BookCopyStatus.ISSUED) {
            return "Unable to remove copy: Copy is currently issued and cannot be removed.";
        }
        if (copy.getStatus() == BookCopyStatus.RESERVED) {
            return "Unable to remove copy: Copy is currently reserved and cannot be removed.";
        }
        if (copy.getStatus() != BookCopyStatus.AVAILABLE) {
            return "Unable to remove copy: Only available copies can be removed (current status: " + copy.getStatus() + ").";
        }
        copies.deleteById(copyId);
        Book book = books.findById(copy.getBookId());
        boolean lastCopyRemoved = book != null && copies.findByBookId(copy.getBookId()).isEmpty();
        if (lastCopyRemoved) {
            book.setStatus(BookStatus.REMOVED);
            books.save(book);
        }
        record(librarian.getPhone(), "BOOK_COPY_REMOVED", book, "Removed copy ID: " + copyId);
        if (lastCopyRemoved) {
            return "Book copy removed successfully. Book status changed to REMOVED because no copies remain.";
        }
        return "Book copy removed successfully";
    }

    private boolean canManageCatalogue(User librarian) {
        return librarian != null && librarian.getStatus() == enums.UserStatus.ACTIVE
                && (librarian.getRole() == enums.UserRole.LIBRARIAN
                    || librarian.getRole() == enums.UserRole.ADMIN);
    }

    private void record(String phone, String action, Book book, String details) {
        if (auditService != null) {
            auditService.record(phone, action, "BOOK", book != null ? String.valueOf(book.getBookId()) : "-", details);
        }
    }
}
