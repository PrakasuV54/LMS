package service;

import enums.PaymentMethod;
import model.Fine;
import model.Payment;
import paymentStrategy.PaymentStrategy;
import repository.DataStore;
import repository.*;
import repository.PaymentRepository;

public class PaymentService {
    private final PaymentRepository payments;
    private final FineRepository fines;
    private final PaymentStrategy strategy;
    private final AuditService auditService;
    private final MembershipRepository memberships;
    private final TransactionRepository transactions;

    public PaymentService(PaymentRepository payments,FineRepository fines,PaymentStrategy strategy,AuditService auditService,
    repository.MembershipRepository memberships,repository.TransactionRepository transactions) {
        this.payments=payments;
        this.fines=fines;
        this.strategy=strategy;
        this.auditService=auditService;
        this.memberships=memberships;
        this.transactions=transactions;
    }

    public Payment payFine(String phone,int fineId,double amount,PaymentMethod method) {
        if (phone == null || phone.isBlank() || amount <= 0 || !Double.isFinite(amount) || method == null)
            return null;
        String normalizedPhone = phone.trim();
        Fine fine = fines.findById(fineId);
        if (fine == null || fine.getUserPhone() == null
                || !fine.isPending() || amount > fine.getRemainingAmount())
            return null;
        Payment payment = new Payment(DataStore.getPaymentId(), fineId, normalizedPhone, amount, method);
        payments.save(payment);
        int gatewayReference = strategy.pay(amount);
        String reference = String.valueOf(gatewayReference);
        payment.markSuccess(reference);
        fine.applyPayment(amount);
        payments.save(payment);
        fines.save(fine);
        auditService.record(normalizedPhone, "FINE_PAYMENT_SUCCEEDED", "PAYMENT", String.valueOf(payment.getPaymentId()), "Fine ID " + fineId + ", amount " + amount);
        return payment;
    }

    public String manageRefund(int paymentId, model.User staff) {
        try {
            if (staff == null || staff.getStatus() != enums.UserStatus.ACTIVE
                    || (staff.getRole() != enums.UserRole.LIBRARIAN
                    && staff.getRole() != enums.UserRole.ADMIN)) {
                return "Insufficient permissions. Staff authorization required.";
            }

            Payment payment = payments.findById(paymentId);
            if (payment == null) {
                return "Payment with ID " + paymentId + " not found.";
            }
            if (payment.isMembershipPayment()) {
                return "Membership payment refunds are not supported.";
            }
            if (payment.getStatus() == enums.PaymentStatus.REFUNDED) {
                return "Payment has already been refunded.";
            }
            if (!payment.isSuccessful()) {
                return "Only successful payments can be refunded (Current status: "
                        + payment.getStatus() + ").";
            }


            String reference = payment.getTransactionReference();
            if (reference == null) {
                return "Payment transaction reference is missing.";
            }

            int gatewayReference = Integer.parseInt(reference);
            strategy.refund(gatewayReference);
            payment.refund();
            payments.save(payment);


                auditService.record(staff.getPhone(), "PAYMENT_REFUNDED", "PAYMENT",
                        String.valueOf(paymentId), "Payment target ID "
                                + (payment.getFineId() > 0 ? payment.getFineId() : payment.getMembershipId()));
            return null;
        } catch (RuntimeException ex) {
            return "Unable to process refund. Please try again." + ex.getMessage();
        }
    }

    public Payment findById(int paymentId) {
        return payments.findById(paymentId);
    }

    public String getPayFineFailureReason(String phone, int fineId, double amount, PaymentMethod method) {
        if (phone == null || phone.isBlank()) {
            return "Phone number is required.";
        }
        if (!Double.isFinite(amount) || amount <= 0) {
            return "Payment amount must be greater than zero.";
        }
        if (method == null) {
            return "Payment method is required.";
        }
        Fine fine = fines.findById(fineId);
        if (fine == null) {
            return "Fine not found with ID " + fineId + ".";
        }
        if (fine.getUserPhone() == null || !fine.getUserPhone().equals(phone.trim())) {
            return "Unauthorized: Fine does not belong to the specified phone number.";
        }
        if (fine.getStatus() == enums.FineStatus.PAID) {
            return "Fine is already fully paid.";
        }
        if (fine.getStatus() == enums.FineStatus.WAIVED) {
            return "Fine has been waived and cannot be paid.";
        }
        if (amount > fine.getRemainingAmount()) {
            return "Payment amount (Rs." + String.format("%.2f", amount)
                    + ") exceeds outstanding balance of Rs."
                    + String.format("%.2f", fine.getRemainingAmount()) + ".";
        }
        return null;
    }

    public java.util.List<Payment> getAllPayments() {
        return payments.findAll();
    }
}
