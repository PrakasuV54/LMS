package repository;

import model.Book;
import model.Author;
import model.Genre;
import java.util.ArrayList;
import java.util.List;

public class InMemoryBookRepository implements BookRepository {
    private final DataStore dataStore;
    public InMemoryBookRepository(DataStore dataStore) {
        this.dataStore = dataStore;
    }

    @Override
    public void save(Book book) {
        if (book == null) throw new IllegalArgumentException("Book is required");
        Book isbnOwner = dataStore.bookByIsbn.get(book.getIsbn());
        if (isbnOwner != null && isbnOwner.getBookId() != book.getBookId()) {
            throw new IllegalArgumentException("ISBN already exists");
        }
        Book old = dataStore.books.get(book.getBookId());
        if (old != null && old != book) throw new IllegalArgumentException("Book ID already exists; update the stored book instance");
        dataStore.books.put(book.getBookId(), book);
        if (old != null && !old.getIsbn().equals(book.getIsbn())) {
            dataStore.bookByIsbn.remove(old.getIsbn());
        }
        dataStore.bookByIsbn.put(book.getIsbn(), book);
    }

    @Override
    public Book findById(int bookId) {
        return dataStore.books.get(bookId);
    }

    @Override
    public Book findByIsbn(String isbn) {
        if (isbn == null) return null;
        return dataStore.bookByIsbn.get(isbn.trim());
    }

    @Override
    public List<Book> findAll() {
        List<Book> result = new ArrayList<>();
        for (Book book : dataStore.books.values()) {
            if (isActive(book)) result.add(book);
        }
        return result;
    }

    @Override
    public List<Book> search(String query) {
        List<Book> result = new ArrayList<>();
        if (query == null || query.isBlank()) return result;
        String text = query.trim().toLowerCase();
        for (Book book : dataStore.books.values()) {
            if (!isActive(book)) continue;
            if (contains(book.getIsbn(), text) || contains(book.getTitle(), text)
            || contains(book.getPublisher(), text) || contains(book.getDescription(), text)
            || String.valueOf(book.getPublicationYear()).equals(text)
            || String.valueOf(book.getBookId()).equals(text)
            || matchesAuthor(book, text) || matchesGenre(book, text)) {
                result.add(book);
            }
        }
        return result;
    }

    @Override
    public List<Book> findByTitle(String title) {
        List<Book> result = new ArrayList<>();
        if (title == null || title.isBlank()) return result;
        String text = title.trim().toLowerCase();
        for (Book book : dataStore.books.values()) {
            if (!isActive(book)) continue;
            if (contains(book.getTitle(), text)) {
                result.add(book);
            }
        }
        return result;
    }

    @Override
    public List<Book> findByAuthor(String author) {
        List<Book> result = new ArrayList<>();
        if (author == null || author.isBlank()) return result;
        String text = author.trim().toLowerCase();
        for (Book book : dataStore.books.values()) {
            if (!isActive(book)) continue;
            if (matchesAuthor(book, text)) {
                result.add(book);
            }
        }
        return result;
    }

    @Override
    public List<Book> findByGenre(String genre) {
        List<Book> result = new ArrayList<>();
        if (genre == null || genre.isBlank()) return result;
        String text = genre.trim().toLowerCase();
        for (Book book : dataStore.books.values()) {
            if (!isActive(book)) continue;
            if (matchesGenre(book, text)) {
                result.add(book);
            }
        }
        return result;
    }

    @Override
    public List<Book> findByPublisher(String publisher) {
        List<Book> result = new ArrayList<>();
        if (publisher == null || publisher.isBlank()) return result;
        String text = publisher.trim().toLowerCase();
        for (Book book : dataStore.books.values()) {
            if (!isActive(book)) continue;
            if (contains(book.getPublisher(), text)) {
                result.add(book);
            }
        }
        return result;
    }

    @Override
    public List<Book> findByDescription(String description) {
        List<Book> result = new ArrayList<>();
        if (description == null || description.isBlank()) return result;
        String text = description.trim().toLowerCase();
        for (Book book : dataStore.books.values()) {
            if (!isActive(book)) continue;
            if (contains(book.getDescription(), text)) {
                result.add(book);
            }
        }
        return result;
    }

    @Override
    public List<Book> findByPublicationYear(int year) {
        List<Book> result = new ArrayList<>();
        if (year <= 0) return result;
        for (Book book : dataStore.books.values()) {
            if (!isActive(book)) continue;
            if (book.getPublicationYear() == year) {
                result.add(book);
            }
        }
        return result;
    }

    private boolean isActive(Book book) {
        return book != null && book.getStatus() == enums.BookStatus.ACTIVE;
    }

    private boolean contains(String value, String query) {
        return value != null && value.toLowerCase().contains(query);
    }

    private boolean matchesAuthor(Book book, String query) {
        if (book == null || query == null) return false;
        for (Author a : book.getAuthors()) {
            if (a != null && contains(a.getName(), query)) {
                return true;
            }
        }
        return false;
    }

    private boolean matchesGenre(Book book, String query) {
        if (book == null || query == null) return false;
        for (Genre g : book.getGenres()) {
            if (g != null && contains(g.getName(), query)) {
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean existsById(int bookId) {
        return dataStore.books.containsKey(bookId);
    }

    @Override
    public boolean existsByIsbn(String isbn) {
        return dataStore.bookByIsbn.containsKey(isbn);
    }

    @Override
    public void deleteById(int bookId) {
        Book book = dataStore.books.remove(bookId);
        if (book != null) {
            dataStore.bookByIsbn.remove(book.getIsbn());
        }
    }

    @Override
    public void deleteByIsbn(String isbn) {
        Book book = dataStore.bookByIsbn.get(isbn);
        if (book != null) deleteById(book.getBookId());
    }
}
