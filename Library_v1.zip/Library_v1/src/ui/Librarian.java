package ui;

import enums.*;
import model.*;

import java.util.List;
import java.util.NoSuchElementException;

public class Librarian extends Main {

    public static void librarian() {
        if (currentUser == null || currentUser.getStatus() != UserStatus.ACTIVE
                || !authService.hasRole(currentUser, UserRole.LIBRARIAN)) {
            System.out.println("Please log in as Librarian or Admin");
            return;
        }
        while (true) {
            System.out.println("\nLibrarian Menu");
            System.out.println("1.View All Books");
            System.out.println("2.Search Books");
            System.out.println("3.Request Book");
            System.out.println("4.Cancel Request");
            System.out.println("5.Renew Book");
            System.out.println("6.Activate Membership");
            System.out.println("7.Renew Membership");
            System.out.println("8.View Currently Rented Books");
            System.out.println("9.View Borrowing History");
            System.out.println("10.Fine Management");
            System.out.println("11.Update My Profile");
            System.out.println("12.Add Book");
            System.out.println("13.Remove Book Copy");
            System.out.println("14.Transaction Management");
            System.out.println("15.View Defaulters");
            System.out.println("16.Manage Membership Status");
            System.out.println("17.Manage Payments");
            System.out.println("18.View Audit Logs");
            System.out.println("19.Logout");
            System.out.println("Enter choice");
            int choice = readInt();
            try {
                switch (choice) {
                    case 1: Member.handleViewAllBooks(); break;
                    case 2: Member.handleSearchBooks(); break;
                    case 3: Member.runForTargetMember(Member::handleRequestBook); break;
                    case 4: Member.runForTargetMember(Member::handleCancelRequest); break;
                    case 5: Member.runForTargetMember(Member::handleRenewBook); break;
                    case 6: Member.runForTargetMember(Member::handleActivateMembership); break;
                    case 7: Member.runForTargetMember(Member::handleRenewMembership); break;
                    case 8: Member.runForTargetMember(Member::handleViewCurrentlyRentedBooks); break;
                    case 9: Member.runForTargetMember(Member::handleViewBorrowingHistory); break;
                    case 10: handleFineManagementMenu(); break;
                    case 11: Member.handleUpdateProfile(); break;
                    case 12: handleAddBook(); break;
                    case 13: handleRemoveBookCopy(); break;
                    case 14: handleTransactionManagement(); break;
                    case 15: handleViewDefaulters(); break;
                    case 16: handleManageMembershipStatus(); break;
                    case 17: handleManagePayments(); break;
                    case 18: handleViewAuditLogs(); break;
                    case 19:
                        currentUser = null;
                        System.out.println("Logged out");
                        return;
                    default:
                        System.out.println("Invalid choice");
                }
            } catch (RuntimeException e) {
                if(e!=GO_HOME)throw e;
            }
        }
    }

    public static void handleAddBook() {
        System.out.println("Enter ISBN (0 to go back)");
        String isbn = readAddBookField();
        if (isbn == null) { System.out.println("Add book cancelled."); return; }

        System.out.println("Enter title (0 to go back)");
        String title = readAddBookField();
        if (title == null) { System.out.println("Add book cancelled."); return; }

        System.out.println("\nExisting authors:");
        List<Author> existingAuthors = authorRepository.findAll();
        if (existingAuthors.isEmpty()) System.out.println("No authors available yet.");
        else for (Author author : existingAuthors) System.out.println("- " + author.getName());
        System.out.println("Enter author name(s), comma-separated (0 to go back)");
        String authorInput = readAddBookField();
        if (authorInput == null) { System.out.println("Add book cancelled."); return; }

        System.out.println("Existing genres:");
        List<Genre> existingGenres = genreRepository.findAll();
        if (existingGenres.isEmpty()) System.out.println("No genres available yet.");
        else for (Genre genre : existingGenres) System.out.println("- " + genre.getName());
        System.out.println("Enter genre(s), comma-separated (0 to go back)");
        String genreInput = readAddBookField();
        if (genreInput == null) { System.out.println("Add book cancelled."); return; }

        System.out.println("Enter publisher (0 to go back)");
        String publisher = readAddBookField();
        if (publisher == null) { System.out.println("Add book cancelled."); return; }

        System.out.println("Enter publication year (0 to go back)");
        Integer year = readAddBookNumber();
        if (year == null) { System.out.println("Add book cancelled."); return; }

        System.out.println("Enter description (0 to go back)");
        String description = readAddBookField();
        if (description == null) { System.out.println("Add book cancelled."); return; }

        System.out.println("Enter number of copies (0 to go back)");
        Integer copies = readAddBookNumber();
        if (copies == null) { System.out.println("Add book cancelled."); return; }

        String result = bookService.addBookFromDetails(
                isbn, title, authorInput, genreInput, publisher, year, description, copies, currentUser);
        for (String line : result.split("\\R")) {
            System.out.println(line);
        }
    }

    private static String readAddBookField() {
        String value = sc.nextLine().trim();
        return value.equals("0") ? null : value;
    }

    private static Integer readAddBookNumber() {
        while (true) {
            String input = sc.nextLine().trim();
            if (input.equals("0")) return null;
            try {
                return Integer.parseInt(input);
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Enter a valid number or 0 to go back:");
            }
        }
    }

    public static void handleRemoveBookCopy() {
        while (true) {
            System.out.println("------Available Books------");
            List<Book> bookList = bookService.getAllBooks();
            for(Book books : bookList){
                if(books.getStatus()!=BookStatus.REMOVED)
                    System.out.println(books);
            }
            System.out.println("Enter ISBN (0 to go to Home):");
            String isbn = sc.nextLine().trim();
            if (isbn.equals("0")) goHome();
            if (isbn.isBlank()) {
                System.out.println("ISBN cannot be empty.");
                continue;
            }

            Book book = bookService.getBookByIsbn(isbn);
            if (book == null) {
                System.out.println("No book found with ISBN: " + isbn);
                continue;
            }

            List<BookCopy> copies = bookCopyRepository.findByBookId(book.getBookId());
            if (copies.isEmpty()) {
                System.out.println("No copies found for ISBN: " + isbn);
                continue;
            }

            System.out.println("\nCopies for ISBN: " + isbn);
            System.out.printf("%-12s %-16s%n", "Copy ID", "Status");
            for (BookCopy copy : copies) {
                System.out.printf("%-12d %-16s%n", copy.getBookCopyId(), copy.getStatus());
            }

            System.out.println("\nEnter book copy ID to remove (-1 to go back, 0 to go to Home):");
            String input = sc.nextLine().trim();
            if (input.equals("-1")) return;
            if (input.equals("0")) goHome();

            int copyId;
            try {
                copyId = Integer.parseInt(input);
            } catch (NumberFormatException e) {
                System.out.println("Invalid copy ID. Please enter a number.");
                continue;
            }

            BookCopy selectedCopy = bookCopyRepository.findById(copyId);
            if (selectedCopy == null || selectedCopy.getBookId() != book.getBookId()) {
                System.out.println("Copy ID does not belong to the selected ISBN.");
                continue;
            }

            System.out.println(bookService.removeBookCopy(copyId, currentUser));
        }
    }


    public static void handleTransactionManagement() {
        while (true) {
            String accessFailure = bookTransactionService.getPendingRequestsFailureReason(currentUser);
            if (accessFailure != null) {
                System.out.println("Unable to view transaction management: " + accessFailure);
                return;
            }

            List<Transaction> currentTransactions = new java.util.ArrayList<>();
            for (Transaction transaction : transactionRepository.findAll()) {
                TransactionStatus status = transaction.getStatus();
                if (status == TransactionStatus.REQUESTED
                        || status == TransactionStatus.RESERVED
                        || status == TransactionStatus.READY_FOR_PICKUP
                        || status == TransactionStatus.ISSUED) {
                    currentTransactions.add(transaction);
                }
            }

            System.out.println("\n========== Transaction Management ==========");
            if (currentTransactions.isEmpty()) {
                System.out.println("No current transactions.");
            } else {
                System.out.printf("%-8s %-22s %-16s %-22s %-10s%n",
                        "Txn ID", "Member", "ISBN", "Status", "Copy ID");
                for (Transaction transaction : currentTransactions) {
                    Book book = bookService.getBookById(transaction.getBookId());
                    User member = userService.findByPhone(transaction.getUserPhone());
                    String memberName = member == null ? transaction.getUserPhone() : member.getName();
                    String isbn = book == null ? "Unknown" : book.getIsbn();
                    String copyId = transaction.getBookCopyId() > 0
                            ? String.valueOf(transaction.getBookCopyId()) : "N/A";
                    System.out.printf("%-8d %-22s %-16s %-22s %-10s%n",
                            transaction.getTransactionId(), truncate(memberName, 21), isbn,
                            transaction.getStatus(), copyId);
                }
            }

            System.out.println("\n1. Mark Ready for Pickup");
            System.out.println("2. Issue Book");
            System.out.println("3. Return Book");
            System.out.println("-1. Back to previous menu");
            System.out.println("Enter choice:");
            String choice = sc.nextLine().trim();

            if (choice.equals("-1")) {
                return;
            }

            switch (choice) {
                case "1":
                    handleMarkReadyForPickup();
                    break;
                case "2":
                    handleIssueBook();
                    break;
                case "3":
                    handleProcessReturn();
                    break;
                default:
                    System.out.println("Invalid choice. Enter 1, 2, 3, or -1.");
            }
        }
    }

    public static void handleViewPendingRequests() {
        while (true) {
            String accessFailure = bookTransactionService.getPendingRequestsFailureReason(currentUser);
            if (accessFailure != null) {
                System.out.println("Unable to view open requests: " + accessFailure);
                return;
            }

            List<Transaction> pending = bookTransactionService.getAllPendingRequests(currentUser);
            if (pending.isEmpty()) {
                System.out.println("No open requests.");
            } else {
                System.out.println("\nOpen Requests");
                System.out.printf("%-8s %-22s %-16s %-20s %-10s%n", "Req ID", "Member", "ISBN", "Status", "Copy ID");
                for (Transaction t : pending) {
                    Book book = bookService.getBookById(t.getBookId());
                    User member = userService.findByPhone(t.getUserPhone());
                    String name = member == null ? t.getUserPhone() : member.getName();
                    String isbn = book == null ? "Unknown" : book.getIsbn();
                    String copy = String.valueOf(t.getBookCopyId());
                    System.out.printf("%-8d %-22s %-16s %-20s %-10s%n",
                            t.getTransactionId(), truncate(name, 21), isbn, t.getStatus(), copy);
                }
            }

            System.out.println("\n1. Mark Ready for Pickup");
            System.out.println("0. Go to Home");
            System.out.println("Enter choice:");
            int choice = readInt();
            if (choice == 0) {
                goHome();
            } else if (choice == 1) {
                handleMarkReadyForPickup();
            } else {
                System.out.println("Invalid choice.");
            }
        }
    }

    public static void handleMarkReadyForPickup() {
        while (true) {
            String accessFailure = bookTransactionService.getPendingRequestsFailureReason(currentUser);
            if (accessFailure != null) {
                System.out.println("Unable to load pickup queue: " + accessFailure);
                return;
            }

            List<Transaction> reserved = bookTransactionService.getReservedRequestsForPickup(currentUser);
            if (reserved.isEmpty()) {
                System.out.println("No copies awaiting preparation.");
                System.out.println("1. Back to Open Requests");
                System.out.println("0. Go to Home");
                System.out.println("Enter choice:");
                int choice = readInt();
                if (choice == 0) {
                    goHome();
                } else if (choice == 1) {
                    return;
                } else {
                    System.out.println("Invalid choice.");
                }
                continue;
            }

            System.out.println("\nCopies to prepare:");
            for (Transaction t : reserved) {
                Book requestedBook = bookService.getBookById(t.getBookId());
                User member = userService.findByPhone(t.getUserPhone());
                System.out.println("Request #" + t.getTransactionId() + " | "
                        + (member == null ? t.getUserPhone() : member.getName()) + " | "
                        + (requestedBook == null ? "Unknown book" : requestedBook.getTitle())
                        + " | Copy #" + t.getBookCopyId());
            }

            System.out.println("Enter request ID ( -1 to go back, 0 to go to Home):");
            int requestId = readInt();
            if (requestId == 0) {
                goHome();
            }
            if (requestId == -1) {
                return;
            }

            boolean listed = false;
            for (Transaction transaction : reserved) {
                if (transaction.getTransactionId() == requestId) {
                    listed = true;
                    break;
                }
            }
            if (!listed) {
                System.out.println("Choose a request ID from the allocated list.");
                continue;
            }

            try {
                String reason = bookTransactionService.getMarkReadyFailureReason(requestId, currentUser);
                if (reason != null) {
                    System.out.println("Unable to mark ready: " + reason);
                } else if (bookTransactionService.markReadyForPickup(requestId, currentUser)) {
                    System.out.println("Ready for pickup.");
                } else {
                    System.out.println("Unable to complete the operation. Check the request status before retrying.");
                }
            } catch (IllegalStateException e) {
                System.out.println("Unable to complete the operation. Check the request status before retrying.");
            }
        }
    }

    private static String truncate(String value, int maxLength) {
        if (value == null) return "Unknown";
        return value.length() <= maxLength ? value : value.substring(0, maxLength - 1) + "…";
    }

    public static void handleIssueBook() {
        try {
            List<Transaction> ready = bookTransactionService.getReadyForPickupRequests(currentUser);
            if (ready.isEmpty()) {
                System.out.println("No books ready for pickup.");
                return;
            }
            System.out.println("Ready to issue:");
            for (Transaction t : ready) {
                Book book = bookService.getBookById(t.getBookId());
                User member = userService.findByPhone(t.getUserPhone());
                System.out.println("Request #" + t.getTransactionId() + " | "
                        + (member == null ? t.getUserPhone() : member.getName()) + " | "
                        + (book == null ? "Unknown book" : book.getTitle()) + " | Copy #" + t.getBookCopyId());
            }
            System.out.println("Enter request ID to issue (0 to go back):");
            int issueId = readInt();
            if (issueId == 0) return;
            boolean listed = false;
            for (Transaction transaction : ready) {
                if (transaction.getTransactionId() == issueId) {
                    listed = true;
                    break;
                }
            }
            if (!listed) {
                System.out.println("Choose a request ID from the ready-for-pickup list.");
                return;
            }
            String issueResult = bookTransactionService.issueBookWithResult(issueId, currentUser);
            if (issueResult == null) {
                System.out.println("Book issued.");
            } else {
                System.out.println("Unable to issue book: " + issueResult);
            }
        } catch (RuntimeException e) {
            System.out.println("Unable to issue book. Check the request status before retrying.");
        }
    }

    public static void handleProcessReturn() {
        List<Transaction> issuedTransactions = new java.util.ArrayList<>();
        for (Transaction transaction : transactionRepository.findAll()) {
            if (transaction.getStatus() == TransactionStatus.ISSUED) {
                issuedTransactions.add(transaction);
            }
        }

        System.out.println("\nCurrently issued transactions:");
        if (issuedTransactions.isEmpty()) {
            System.out.println("No issued transactions are available to return.");
            System.out.println("Press Enter to return to the Librarian menu, or enter 0 to go to Home:");
            String input = sc.nextLine().trim();
            if (input.equals("0")) goHome();
            return;
        }

        System.out.printf("%-12s %-24s %-16s %-16s %-10s %-12s%n",
                "Transaction", "Book", "ISBN", "Member Phone", "Copy ID", "Due Date");
        for (Transaction transaction : issuedTransactions) {
            Book listedBook = bookService.getBookById(transaction.getBookId());
            String title = listedBook == null ? "Unknown" : listedBook.getTitle();
            String listedIsbn = listedBook == null ? "Unknown" : listedBook.getIsbn();
            System.out.printf("%-12d %-24s %-16s %-16s %-10d %-12s%n",
                    transaction.getTransactionId(), truncate(title, 23), listedIsbn,
                    transaction.getUserPhone(), transaction.getBookCopyId(),
                    transaction.getDueDate() == null ? "N/A" : transaction.getDueDate().toString());
        }

        Transaction selectedLoan = null;
        while (selectedLoan == null) {
            System.out.println("\nSelect issued transaction using:");
            System.out.println("1. Transaction ID");
            System.out.println("2. ISBN and member phone number");
            System.out.println("-1. Back to Librarian menu");
            System.out.println("0. Go to Home");
            System.out.println("Enter choice:");
            String choiceInput = sc.nextLine().trim();
            if (choiceInput.equals("0")) goHome();
            if (choiceInput.equals("-1")) return;

            if (choiceInput.equals("1")) {
                while (true) {
                    System.out.println("Enter transaction ID (-1 to go back, 0 to go to Home):");
                    String idInput = sc.nextLine().trim();
                    if (idInput.equals("0")) goHome();
                    if (idInput.equals("-1")) break;
                    int transactionId;
                    try {
                        transactionId = Integer.parseInt(idInput);
                    } catch (NumberFormatException e) {
                        System.out.println("Invalid transaction ID. Try again.");
                        continue;
                    }
                    Transaction candidate = null;
                    for (Transaction transaction : issuedTransactions) {
                        if (transaction.getTransactionId() == transactionId) {
                            candidate = transaction;
                            break;
                        }
                    }
                    if (candidate == null) {
                        System.out.println("That transaction is not in the issued-transactions list. Try again.");
                        continue;
                    }
                    selectedLoan = candidate;
                    break;
                }
            } else if (choiceInput.equals("2")) {
                boolean chooseAnotherMethod = false;
                while (selectedLoan == null && !chooseAnotherMethod) {
                    String isbn;
                    while (true) {
                        System.out.println("Enter book ISBN (-1 to go back to selection, 0 to go to Home):");
                        isbn = sc.nextLine().trim();
                        if (isbn.equals("0")) goHome();
                        if (isbn.equals("-1")) { chooseAnotherMethod = true; break; }
                        if (isbn.isEmpty()) {
                            System.out.println("ISBN cannot be empty. Try again.");
                            continue;
                        }
                        if (bookService.getBookByIsbn(isbn) == null) {
                            System.out.println("Book not found. Enter an existing ISBN.");
                            continue;
                        }
                        break;
                    }
                    if (chooseAnotherMethod) break;

                    while (true) {
                        System.out.println("Enter member phone number (-1 to go back to ISBN, 0 to go to Home):");
                        String memberPhone = sc.nextLine().trim();
                        if (memberPhone.equals("0")) goHome();
                        if (memberPhone.equals("-1")) break;
                        if (memberPhone.isEmpty()) {
                            System.out.println("Member phone number cannot be empty. Try again.");
                            continue;
                        }
                        User member = userService.findByPhone(memberPhone);
                        if (member == null || member.getRole() != UserRole.MEMBER) {
                            System.out.println("Member not found. Enter a valid member phone number.");
                            continue;
                        }
                        selectedLoan = bookTransactionService.findIssuedLoansForReturn(memberPhone, isbn, currentUser);
                        if (selectedLoan == null) {
                            System.out.println("No issued transaction matches this ISBN and member. Try again.");
                            continue;
                        }
                        break;
                    }
                }
            } else {
                System.out.println("Invalid choice. Select 1, 2, -1, or 0.");
            }
        }

        Book book = bookService.getBookById(selectedLoan.getBookId());
        User member = userService.findByPhone(selectedLoan.getUserPhone());
        while (true) {
            System.out.println("Condition: 1. Normal  2. Damaged  3. Lost");
            System.out.println("Enter choice (-1 to choose another transaction, 0 to go to Home):");
            String conditionInput = sc.nextLine().trim();
            if (conditionInput.equals("0")) goHome();
            if (conditionInput.equals("-1")) {
                handleProcessReturn();
                return;
            }
            int condition;
            try {
                condition = Integer.parseInt(conditionInput);
            } catch (NumberFormatException e) {
                System.out.println("Invalid choice. Enter 1, 2, 3, or -1.");
                continue;
            }
            if (condition < 1 || condition > 3) {
                System.out.println("Invalid choice. Enter 1, 2, or 3.");
                continue;
            }
            String conditionText = condition == 1 ? "normal" : condition == 2 ? "damaged" : "lost";
            while (true) {
                System.out.println("Confirm " + conditionText + " processing for "
                        + (book == null ? "Unknown book" : book.getTitle()) + " | "
                        + (member == null ? selectedLoan.getUserPhone() : member.getName())
                        + " | Transaction #" + selectedLoan.getTransactionId()
                        + " | Copy #" + selectedLoan.getBookCopyId() + " (y/n)");
                System.out.println("Enter y to confirm, n to cancel, -1 to change condition, or 0 to go to Home:");
                String confirm = sc.nextLine().trim();
                if (confirm.equals("0")) goHome();
                if (confirm.equals("-1")) break;
                if (confirm.equalsIgnoreCase("n") || confirm.equalsIgnoreCase("no")) {
                    System.out.println("Return processing cancelled.");
                    return;
                }
                if (!confirm.equalsIgnoreCase("y") && !confirm.equalsIgnoreCase("yes")) {
                    System.out.println("Enter y, n, -1, or 0.");
                    continue;
                }

                String result = bookTransactionService.processReturnWithResult(
                        selectedLoan.getTransactionId(), condition, currentUser);
                if (result != null) {
                    System.out.println("Unable to process " + conditionText + " book: " + result);
                    System.out.println("You can retry, enter -1 to change condition, or 0 to go to Home.");
                    continue;
                } else if (condition == 1) {
                    System.out.println("Return processed.");
                } else {
                    System.out.println("Book marked " + conditionText.toUpperCase() + ". Fine created.");
                }
                return;
            }
        }
    }

    public static void handleCopyIncident() {
        copyIncidentWorkflow:
        while (true) {
            System.out.println("\nMark Copy Lost/Damaged");
            System.out.println("Is the borrower identified? (y/n,0 to go to Home)");
            String identified = sc.nextLine().trim();
            if (identified.equals("0")) goHome();
            boolean borrowerIdentified;
            if (identified.equalsIgnoreCase("y") || identified.equalsIgnoreCase("yes")) {
                borrowerIdentified = true;
            } else if (identified.equalsIgnoreCase("n") || identified.equalsIgnoreCase("no")) {
                borrowerIdentified = false;
            } else {
                System.out.println("Enter y or n.");
                continue;
            }

            String phone = null;
            boolean borrowedByIdentifiedMember = false;
            if (borrowerIdentified) {
                while (true) {
                    System.out.println("Was this book borrowed by the identified member? (y/n, -1 to go back, 0 to go to Home)");
                    String borrowed = sc.nextLine().trim();
                    if (borrowed.equals("0")) goHome();
                    if (borrowed.equals("-1")) continue copyIncidentWorkflow;
                    if (borrowed.equalsIgnoreCase("y") || borrowed.equalsIgnoreCase("yes") || borrowed.equalsIgnoreCase("n") || borrowed.equalsIgnoreCase("no")) {
                        borrowedByIdentifiedMember = borrowed.equalsIgnoreCase("y") || borrowed.equalsIgnoreCase("yes");
                        while (true) {
                            System.out.println("Enter borrower member phone (-1 to go back, 0 to go to Home):");
                            String phoneInput = sc.nextLine().trim();
                            if (phoneInput.equals("0")) goHome();
                            if (phoneInput.equals("-1")) continue copyIncidentWorkflow;
                            if (phoneInput.isEmpty()) {
                                System.out.println("Member phone cannot be empty.");
                                continue;
                            }
                            User member = userService.findByPhone(phoneInput);
                            if (member == null || member.getRole() != UserRole.MEMBER) {
                                System.out.println("Member not found. Try again.");
                                continue;
                            }
                            phone = phoneInput;
                            break;
                        }
                        break;
                    }
                    System.out.println("Enter y or n.");
                }
            }

            while (true) {
                System.out.println("1. Mark copy lost  2. Mark copy damaged  -1. Back  0. Go to Home");
                String choiceInput = sc.nextLine().trim();
                if (choiceInput.equals("0")) goHome();
                if (choiceInput.equals("-1")) continue copyIncidentWorkflow;
                if (!choiceInput.equals("1") && !choiceInput.equals("2")) {
                    System.out.println("Invalid choice. Enter 1 or 2.");
                    continue;
                }
                boolean lost = choiceInput.equals("1");
                while (true) {
                    System.out.println("Enter copy ID (-1 to change lost/damaged choice, 0 to go to Home):");
                    String copyInput = sc.nextLine().trim();
                    if (copyInput.equals("0")) goHome();
                    if (copyInput.equals("-1")) break;
                    int copyId;
                    try {
                        copyId = Integer.parseInt(copyInput);
                    } catch (NumberFormatException e) {
                        System.out.println("Invalid copy ID. Try again.");
                        continue;
                    }
                    String result = bookTransactionService.processCopyIncidentWithResult(
                            copyId, phone, lost, borrowedByIdentifiedMember, currentUser);
                    if (result != null) {
                        System.out.println("Unable to update copy: " + result);
                        System.out.println("Please retry the operation.");
                        continue;
                    }
                    if (phone != null) {
                        System.out.println("Copy marked " + (lost ? "LOST" : "DAMAGED") + ". Fine processed.");
                    } else if (borrowerIdentified) {
                        System.out.println("Copy marked " + (lost ? "LOST" : "DAMAGED")
                                + ". No member fine was assigned because the book was not borrowed.");
                    } else {
                        System.out.println("Copy marked " + (lost ? "LOST" : "DAMAGED")
                                + ". No member fine was assigned because the borrower is unidentified.");
                    }
                    continue copyIncidentWorkflow;
                }
            }
        }
    }

    public static void handleViewDefaulters() {
        List<User> defaulters = policyService.getDefaulters(currentUser);
        if (defaulters.isEmpty()) System.out.println("No defaulters found");
        for (User user : defaulters) System.out.println(user.getName() + " | Phone: " + user.getPhone() + " | Email: " + user.getEmail());
    }

    public static void handleManageMembershipStatus() {
        System.out.println("Enter member phone number");
        String memberPhone = sc.nextLine().trim();
        System.out.println("1.Suspend membership  2.Reactivate membership");
        int membershipChoice = readInt();
        if (membershipChoice != 1 && membershipChoice != 2) {
            System.out.println("Invalid choice");
            return;
        }

        String result = membershipService.manageMembershipStatus(currentUser, memberPhone, membershipChoice == 1);
        if (result != null) System.out.println("Unable to update membership status: " + result);
        else System.out.println("Membership status updated");
    }

    public static void handleManagePayments() {
        for (Payment payment : paymentService.getAllPayments()) {
            System.out.println("Payment ID: " + payment.getPaymentId() + ", Phone: " + payment.getUserPhone()
                    + ", Amount: Rs." + payment.getAmount() + ", Status: " + payment.getStatus());
        }
        System.out.println("Enter payment ID to refund, or 0 to return");
        int paymentId = readInt();
        if (paymentId != 0) {
            String result = paymentService.manageRefund(paymentId, currentUser);
            if (result == null) System.out.println("Refund processed");
            else System.out.println("Refund failed: " + result);
        }
    }

    public static void handleFineManagementMenu() {
        while (true) {
            System.out.println("\n--- Fine Management ---");
            System.out.println("1. View Fines (all/status/member/transaction filters)");
            System.out.println("2. Manage Member Fines (pay or waive)");
            System.out.println("0. Back to previous menu");
            System.out.println("Enter choice:");
            int choice = readInt();
            switch (choice) {
                case 1:
                    viewCurrentFines();
                    break;
                case 2:
                    manageCurrentFines();
                    break;

                case 0:
                    return;
                default:
                    System.out.println("Invalid choice. Please select 0, 1, 2, or 3.");
            }
        }
    }

    public static void viewCurrentFines() {
        while (true) {
            System.out.println("\n--- View Current Fines ---");
            System.out.println("1.All Fines");
            System.out.println("2.Pending Fines");
            System.out.println("3.Partially Paid Fines");
            System.out.println("4.Paid Fines");
            System.out.println("5.Waived Fines");
            System.out.println("6.Filter by Member Phone");
            System.out.println("7.Filter by Transaction ID");
            System.out.println("8.Back");
            System.out.println("Enter choice:");

            int filterChoice = readInt();
            if (filterChoice == 8) {
                return;
            }

            List<Fine> finesToDisplay;
            switch (filterChoice) {
                case 1:
                    finesToDisplay = fineService.getAllFines(currentUser);
                    break;
                case 2:
                    finesToDisplay = fineService.getFinesByStatus(FineStatus.PENDING, currentUser);
                    break;
                case 3:
                    finesToDisplay = fineService.getFinesByStatus(FineStatus.PARTIALLY_PAID, currentUser);
                    break;
                case 4:
                    finesToDisplay = fineService.getFinesByStatus(FineStatus.PAID, currentUser);
                    break;
                case 5:
                    finesToDisplay = fineService.getFinesByStatus(FineStatus.WAIVED, currentUser);
                    break;
                case 6:
                    System.out.println("Member phone:");
                    String phone = sc.nextLine().trim();
                    finesToDisplay = fineService.findByUserPhone(phone, currentUser);
                    break;
                case 7:
                    System.out.println("Enter transaction ID:");
                    int txId = readInt();
                    finesToDisplay = fineService.findByTransactionId(txId, currentUser);
                    break;
                default:
                    System.out.println("Invalid choice");
                    continue;
            }

            if (finesToDisplay.isEmpty()) {
                System.out.println("No fines found");
            } else {
                System.out.println("\n--- Fines List (" + finesToDisplay.size() + ") ---");
                for (Fine fine : finesToDisplay) {
                    printFineSummary(fine);
                }
            }
        }
    }

    static void printFineSummary(Fine fine) {
        int memberId = fine.getUserId();
        String memberIdDisplay =String.valueOf(memberId);
        System.out.println("Fine ID: " + fine.getFineId()
                + " | Member ID: " + memberIdDisplay
                + " | Phone: " + fine.getUserPhone()
                + " | Transaction ID: " + fine.getTransactionId()
                + " | Type: " + fine.getType()
                + " | Original Amount: Rs." + String.format("%.2f", fine.getAmount())
                + " | Paid: Rs." + String.format("%.2f", fine.getAmountPaid())
                + " | Outstanding Balance: Rs." + String.format("%.2f", fine.getRemainingAmount())
                + " | Status: " + fine.getStatus());
    }

    public static void manageCurrentFines() {
        System.out.println("\n--- Manage Current Fines ---");
        System.out.println("Member phone: (-1 to go back, 0 to go to Home)");

        String phone = sc.nextLine().trim();
        if(phone.equals("0")){
            Main.goHome();
        }
        if(phone.equals("-1")){
            return;
        }
        if (phone.isEmpty()) {
            System.out.println("Phone number cannot be empty.");
            return;
        }

        User member = userService.findByPhone(phone);
        if (member == null || member.getRole() != UserRole.MEMBER) {
            System.out.println("Member not found with phone: " + phone);
            return;
        }

        while (true) {
            List<Fine> fines = fineService.findByUserPhone(phone, currentUser);
            if (fines == null || fines.isEmpty()) {
                System.out.println("No fines found for member: " + phone);
                return;
            }

            System.out.println("\n--- Fines for Member " + phone + " ---");
            for (int i = 0; i < fines.size(); i++) {
                Fine f = fines.get(i);
                System.out.println((i + 1) + ". Fine ID: " + f.getFineId()
                        + " | Transaction ID: " + f.getTransactionId()
                        + " | Fine Amount: Rs." + String.format("%.2f", f.getAmount())
                        + " | Amount Paid: Rs." + String.format("%.2f", f.getAmountPaid())
                        + " | Remaining Amount: Rs." + String.format("%.2f", f.getRemainingAmount())
                        + " | Status: " + f.getStatus());
            }

            System.out.println("Enter the fine number to manage, or 0 to go back:");
            int selection = readInt();
            if (selection == 0) {
                return;
            }
            if (selection < 1 || selection > fines.size()) {
                System.out.println("Invalid selection. Selection outside the displayed list.");
                continue;
            }

            Fine selectedFine = fines.get(selection - 1);
            int fineId = selectedFine.getFineId();

            manageSelectedFine(fineId);
        }
    }

    private static void manageSelectedFine(int fineId) {
        while (true) {
            Fine fine = fineService.findById(fineId, currentUser);
            if (fine == null) {
                System.out.println("Fine not found with ID: " + fineId);
                return;
            }

            System.out.println("\n--- Fine Details ---");
            System.out.println("Fine ID: " + fine.getFineId()
                    + " | Transaction ID: " + fine.getTransactionId()
                    + " | Fine Amount: Rs." + String.format("%.2f", fine.getAmount())
                    + " | Amount Paid: Rs." + String.format("%.2f", fine.getAmountPaid())
                    + " | Remaining Amount: Rs." + String.format("%.2f", fine.getRemainingAmount())
                    + " | Status: " + fine.getStatus());

            System.out.println("\nActions for Fine ID: " + fineId);
            System.out.println("1.Pay Fine");
            System.out.println("2.Waive Fine");
            System.out.println("3.Back");
            System.out.println("Enter choice:");

            int action = readInt();
            switch (action) {
                case 1:
                    paySelectedFine(fineId);
                    return;
                case 2:
                    waiveSelectedFine(fineId);
                    return;
                case 3:
                    return;
                default:
                    System.out.println("Invalid choice. Please select 1, 2, or 3.");
            }
        }
    }

    private static void paySelectedFine(int fineId) {
        Fine fine = fineService.findById(fineId, currentUser);
        if (fine == null) {
            System.out.println("Fine not found with ID: " + fineId);
            return;
        }

        System.out.println("Remaining Balance: Rs." + String.format("%.2f", fine.getRemainingAmount()));
        System.out.println("Enter payment amount:");
        double amount = readDouble();
        PaymentMethod method = UiHelpers.choosePaymentMethod();
        if (method == null) {
            System.out.println("Payment cancelled: Payment method not found");
            return;
        }

        Payment payment = paymentService.payFine(fine.getUserPhone(), fineId, amount, method);
        if (payment != null && payment.isSuccessful()) {
            System.out.println("Payment recorded successfully (Payment ID: " + payment.getPaymentId()
                    + ", Reference: " + payment.getTransactionReference() + ")");
            Fine updatedFine = fineService.findById(fineId, currentUser);
            if (updatedFine != null) {
                System.out.println("\n--- Updated Fine Details ---");
                System.out.println("Fine ID: " + updatedFine.getFineId()
                        + " | Transaction ID: " + updatedFine.getTransactionId()
                        + " | Fine Amount: Rs." + String.format("%.2f", updatedFine.getAmount())
                        + " | Amount Paid: Rs." + String.format("%.2f", updatedFine.getAmountPaid())
                        + " | Remaining Amount: Rs." + String.format("%.2f", updatedFine.getRemainingAmount())
                        + " | Status: " + updatedFine.getStatus());
            }
        } else {
            String payReason = paymentService.getPayFineFailureReason(fine.getUserPhone(), fineId, amount, method);
            System.out.println("Payment failed: " + (payReason != null ? payReason : "Payment gateway was unable to process the transaction."));
        }
    }

    private static void waiveSelectedFine(int fineId) {
        Fine fine = fineService.findById(fineId, currentUser);
        if (fine == null) {
            System.out.println("Fine not found with ID: " + fineId);
            return;
        }
        if (fineService.waiveFine(fineId, currentUser)) {
            System.out.println("Fine waived successfully");
            Fine updated = fineService.findById(fineId, currentUser);
            if (updated != null) {
                System.out.println("\n--- Updated Fine Details ---");
                System.out.println("Fine ID: " + updated.getFineId()
                        + " | Transaction ID: " + updated.getTransactionId()
                        + " | Fine Amount: Rs." + String.format("%.2f", updated.getAmount())
                        + " | Amount Paid: Rs." + String.format("%.2f", updated.getAmountPaid())
                        + " | Remaining Amount: Rs." + String.format("%.2f", updated.getRemainingAmount())
                        + " | Status: " + updated.getStatus());
            }
        } else {
            String waiveReason = fineService.getWaiveFineFailureReason(fineId, currentUser);
            System.out.println("Unable to waive fine: " + (waiveReason != null ? waiveReason : "Fine status could not be changed to waived."));
        }
    }
}
