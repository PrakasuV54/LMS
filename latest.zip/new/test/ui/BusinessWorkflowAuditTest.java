package ui;

import authentication.PasswordAuthentication;
import enums.*;
import model.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mindrot.jbcrypt.BCrypt;
import paymentStrategy.PaymentStrategy;
import repository.DataStore;
import service.AuthService;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.PrintStream;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Scanner;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Comprehensive business-workflow audit tests covering workflows A through I.
 */
public class BusinessWorkflowAuditTest {

    private final InputStream originalIn = System.in;
    private final PrintStream originalOut = System.out;
    private ByteArrayOutputStream outContent;

    @BeforeEach
    void setUp() {
        outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));
        Main.resetData();
    }

    @AfterEach
    void tearDown() {
        System.setIn(originalIn);
        System.setOut(originalOut);
        Main.currentUser = null;
        Main.sc = new Scanner(System.in);
        Main.resetData();
    }

    private void provideInput(String input) {
        System.setIn(new ByteArrayInputStream(input.getBytes(StandardCharsets.UTF_8)));
        Main.sc = new Scanner(System.in);
    }

    // =========================================================================
    // SECTION A: Registration, Authentication, and Accounts
    // =========================================================================

    @Test
    void testA1_RegisterValidMember_PersistsAllFieldsAndHashedPassword() {
        String phone = "9112223344";
        String email = "arthur.dent@galaxy.com";
        String rawPass = "DontPanic42!";

        Main.authService.register(
                "Arthur Dent", email, phone, rawPass, 42, "MALE"
        );

        User registered = Main.userRepository.findByPhone(phone);
        assertNotNull(registered);
        assertEquals(phone, registered.getPhone());
        assertEquals("Arthur Dent", registered.getName());
        assertEquals(email, registered.getEmail());
        assertEquals(42, registered.getAge());
        assertEquals("MALE", registered.getGender());
        assertEquals(UserRole.MEMBER, registered.getRole());
        assertEquals(UserStatus.ACTIVE, registered.getStatus());

        // Password must be hashed with BCrypt, not stored in plain text
        assertNotEquals(rawPass, registered.getPasswordHash());
        assertTrue(BCrypt.checkpw(rawPass, registered.getPasswordHash()));
    }

    @Test
    void testA2_LoginValidCredentialsAndRejectWrongPassword() {
        // Valid login
        User loggedIn = Main.authService.login("9870000001", "MemberPass123!");
        assertNotNull(loggedIn);
        assertEquals("9870000001", loggedIn.getPhone());

        // Incorrect password rejected
        User wrongPass = Main.authService.login("9870000001", "WrongPassword999!");
        assertNull(wrongPass);

        // Non-existent user rejected
        User noUser = Main.authService.login("0000000000", "MemberPass123!");
        assertNull(noUser);
    }

    @Test
    void testA3_RejectDuplicatePhoneOrEmail() {
        int initialCount = Main.userRepository.findAll().size();

        // Duplicate phone
        assertThrows(IllegalArgumentException.class, () -> {
            Main.authService.register("Duplicate Phone", "newunique@email.com", "9870000001", "Pass12345!", 25, "FEMALE");
        });

        // Duplicate email
        assertThrows(IllegalArgumentException.class, () -> {
            Main.authService.register("Duplicate Email", "member01@library.com", "9119998888", "Pass12345!", 25, "FEMALE");
        });

        // Verify no extra user created
        assertEquals(initialCount, Main.userRepository.findAll().size());
    }

    @Test
    void testA4_RejectInvalidRegistrationData() {
        int initialCount = Main.userRepository.findAll().size();

        // Empty phone
        assertThrows(IllegalArgumentException.class, () -> {
            Main.authService.register("Valid Name", "valid@email.com", "", "Pass12345!", 25, "MALE");
        });

        // Empty name
        assertThrows(IllegalArgumentException.class, () -> {
            Main.authService.register("", "valid@email.com", "9871112223", "Pass12345!", 25, "MALE");
        });

        // Empty email
        assertThrows(IllegalArgumentException.class, () -> {
            Main.authService.register("Valid Name", "", "9871112223", "Pass12345!", 25, "MALE");
        });

        // Invalid age
        assertThrows(IllegalArgumentException.class, () -> {
            Main.authService.register("Valid Name", "valid@email.com", "9871112223", "Pass12345!", -5, "MALE");
        });

        assertEquals(initialCount, Main.userRepository.findAll().size());
    }

    @Test
    void testA5_InactiveOrDeletedUserCannotAuthenticate() {
        User user = Main.userRepository.findByPhone("9870000001");
        assertNotNull(user);
        user.setStatus(UserStatus.INACTIVE);
        Main.userRepository.save(user);

        User loginResult = Main.authService.login("9870000001", "MemberPass123!");
        assertNull(loginResult, "Inactive user must not be allowed to log in");
    }

    @Test
    void testA6_LogoutAndSubsequentAuthentication() {
        User user = Main.authService.login("9870000001", "MemberPass123!");
        assertNotNull(user);
        Main.currentUser = user;
        assertEquals(user, Main.currentUser);

        // Logout
        Main.currentUser = null;
        assertNull(Main.currentUser);

        // Re-authenticate
        User reLogin = Main.authService.login("9870000001", "MemberPass123!");
        assertNotNull(reLogin);
        Main.currentUser = reLogin;
        assertEquals(reLogin, Main.currentUser);
    }

    // =========================================================================
    // SECTION B: Membership Purchase, Activation, and Renewal
    // =========================================================================

    @Test
    void testB1_PurchaseStandardMembership_Charges399_Limits3_NormalPriority() {
        Main.authService.register(
                "Standard User", "std@test.com", "9870000011", "StdPass123!", 28, "MALE"
        );

        // Plan 1 = Standard (₹399, max 3 books, loan 14 days)
        Main.membershipService.purchaseMembership("9870000011", 1, 1, PaymentMethod.UPI);

        Membership active = Main.membershipRepository.findActiveByUserPhone("9870000011");
        assertNotNull(active);
        assertEquals(1, active.getPlanId());
        assertEquals(MembershipStatus.ACTIVE, active.getStatus());
        assertEquals(LocalDate.now(), active.getStartDate());
        assertEquals(LocalDate.now().plusMonths(1), active.getEndDate());

        Payment payment = Main.paymentRepository.findById(active.getPaymentId());
        assertNotNull(payment);
        assertEquals(399.0, payment.getAmount());
        assertEquals(PaymentStatus.SUCCESS, payment.getStatus());

        // Policy checks
        assertEquals(3, Main.policyService.getMaxBooksForUser("9870000011"));
        assertEquals(2, Main.policyService.getRequestQueuePriority("9870000011")); // Normal
    }

    @Test
    void testB2_PurchasePremiumMembership_Charges599_Limits5_QueuePriority() {
        Main.authService.register(
                "Premium User", "prem@test.com", "9870000012", "PremPass123!", 32, "FEMALE"
        );

        // Plan 2 = Premium (₹599, max 5 books, priority queue)
        Main.membershipService.purchaseMembership("9870000012", 2, 1, PaymentMethod.CARD);

        Membership active = Main.membershipRepository.findActiveByUserPhone("9870000012");
        assertNotNull(active);
        assertEquals(2, active.getPlanId());
        assertEquals(MembershipStatus.ACTIVE, active.getStatus());

        Payment payment = Main.paymentRepository.findById(active.getPaymentId());
        assertNotNull(payment);
        assertEquals(599.0, payment.getAmount());
        assertEquals(PaymentStatus.SUCCESS, payment.getStatus());

        // Policy checks
        assertEquals(5, Main.policyService.getMaxBooksForUser("9870000012"));
        assertEquals(1, Main.policyService.getRequestQueuePriority("9870000012")); // Priority
    }

    @Test
    void testB3_DuplicatePurchaseAttemptRejected() {
        // 9870000001 already has active membership in SyntheticData
        Membership activeBefore = Main.membershipRepository.findActiveByUserPhone("9870000001");
        assertNotNull(activeBefore);

        assertThrows(IllegalArgumentException.class, () -> {
            Main.membershipService.purchaseMembership("9870000001", 1, 1, PaymentMethod.UPI);
        });

        // Membership count should remain unchanged
        List<Membership> memberships = Main.membershipRepository.findByUserPhone("9870000001");
        assertEquals(1, memberships.size());
    }

    @Test
    void testB4_RenewalExtendsMembershipAndUpdatesPlan() {
        // Member 9870000001 currently has Standard plan
        Membership current = Main.membershipRepository.findActiveByUserPhone("9870000001");
        assertNotNull(current);
        LocalDate oldEnd = current.getEndDate();

        // Renew with Premium Plan (2) for 2 months
        boolean success = Main.membershipService.renewMembership("9870000001", 2, 2, PaymentMethod.UPI);
        assertTrue(success);

        Membership renewed = Main.membershipRepository.findActiveByUserPhone("9870000001");
        assertEquals(2, renewed.getPlanId()); // Updated to Premium
        assertEquals(oldEnd.plusMonths(2), renewed.getEndDate());

        // Policy limits must immediately reflect Premium plan
        assertEquals(5, Main.policyService.getMaxBooksForUser("9870000001"));
        assertEquals(1, Main.policyService.getRequestQueuePriority("9870000001"));
    }

    @Test
    void testB5_PaymentGatewayRejection_LeavesNoActiveMembership() {
        Main.authService.register("Fail User", "fail@test.com", "9870000099", "Pass123!", 25, "MALE");

        PaymentStrategy rejectingStrategy = new PaymentStrategy() {
            @Override
            public int pay(double amount) {
                return 0; // gateway rejected
            }
            @Override
            public void refund(int gatewayReference) {}
        };

        service.MembershipService svc = new service.MembershipService(
                Main.userRepository, Main.membershipRepository, Main.membershipPlanService,
                Main.paymentRepository, rejectingStrategy, Main.auditService, Main.notificationService
        );

        assertThrows(IllegalStateException.class, () -> {
            svc.purchaseMembership("9870000099", 1, 1, PaymentMethod.UPI);
        });

        assertNull(Main.membershipRepository.findActiveByUserPhone("9870000099"));
    }

    @Test
    void testB6_PaymentGatewayException_LeavesNoActiveMembership() {
        Main.authService.register("Ex User", "ex@test.com", "9870000098", "Pass123!", 25, "MALE");

        PaymentStrategy crashingStrategy = new PaymentStrategy() {
            @Override
            public int pay(double amount) {
                throw new RuntimeException("Network timeout to bank");
            }
            @Override
            public void refund(int gatewayReference) {}
        };

        service.MembershipService svc = new service.MembershipService(
                Main.userRepository, Main.membershipRepository, Main.membershipPlanService,
                Main.paymentRepository, crashingStrategy, Main.auditService, Main.notificationService
        );

        assertThrows(IllegalStateException.class, () -> {
            svc.purchaseMembership("9870000098", 1, 1, PaymentMethod.CARD);
        });

        assertNull(Main.membershipRepository.findActiveByUserPhone("9870000098"));
    }

    @Test
    void testB7_ExpiredOrSuspendedMembershipIneligibleForBorrowing() {
        // Expired membership user
        Main.authService.register("Expired User", "exp@test.com", "9870000097", "Pass123!", 30, "FEMALE");
        Membership expired = new Membership(DataStore.getMembershipId(), "9870000097", 1,
                LocalDate.now().minusMonths(2), LocalDate.now().minusDays(1), MembershipStatus.EXPIRED, 1);
        Main.membershipRepository.save(expired);

        assertFalse(Main.policyService.hasActiveMembership("9870000097"));
        assertFalse(Main.policyService.canRequestBook("9870000097"));
    }

    // =========================================================================
    // SECTION C: Book Catalogue and Inventory
    // =========================================================================

    @Test
    void testC1_SearchBooksSupportedFields() {
        // Search by ISBN
        List<Book> byIsbn = Main.bookService.searchByIsbn("978-0132350884");
        assertFalse(byIsbn.isEmpty());

        // Search by Title
        List<Book> byTitle = Main.bookService.searchByTitle("Clean Code");
        assertFalse(byTitle.isEmpty());

        // Search by Author
        List<Book> byAuthor = Main.bookService.searchByAuthor("Robert C. Martin");
        assertFalse(byAuthor.isEmpty());

        // Search by Publisher
        List<Book> byPub = Main.bookService.searchByPublisher("Prentice Hall");
        assertFalse(byPub.isEmpty());

        // Search by Year
        List<Book> byYear = Main.bookService.searchByPublicationYear(2008);
        assertFalse(byYear.isEmpty());

        // Search by Field dispatcher
        List<Book> dispatched = Main.bookService.searchByField("title", "Clean");
        assertFalse(dispatched.isEmpty());
    }

    @Test
    void testC2_SearchNonExistentIsbn_ReturnsEmpty() {
        List<Book> result = Main.bookService.searchByIsbn("999-9999999999");
        assertTrue(result.isEmpty());
    }

    @Test
    void testC3_AddBookAndCopies_ByStaff() {
        User librarian = Main.userRepository.findByPhone("8888888888");

        String result = Main.bookService.addBookFromDetails(
                "978-0321356680", "Effective Java", "Joshua Bloch",
                "Technology", "Addison-Wesley", 2018,
                "Best practices for Java", 3, librarian
        );

        assertEquals("Book added successfully", result);

        Book saved = Main.bookService.getBookByIsbn("978-0321356680");
        assertNotNull(saved);
        assertEquals("Effective Java", saved.getTitle());

        List<BookCopy> copies = Main.bookCopyRepository.findByBookId(saved.getBookId());
        assertEquals(3, copies.size());
        for (BookCopy c : copies) {
            assertEquals(BookCopyStatus.AVAILABLE, c.getStatus());
        }
    }

    @Test
    void testC4_UpdateBookDetails_ByStaff() {
        User librarian = Main.userRepository.findByPhone("8888888888");
        User member = Main.userRepository.findByPhone("9870000001");
        Book book = Main.bookService.getBookByIsbn("978-0132350884");
        assertNotNull(book);

        // Member cannot update
        String fail = Main.bookService.updateBookDetails(book.getBookId(), "Updated Title", "New Pub", 2020, "Desc", member);
        assertTrue(fail.contains("Insufficient permissions"));

        // Librarian updates successfully
        String success = Main.bookService.updateBookDetails(book.getBookId(), "Clean Code 2nd Ed", "Prentice Hall", 2021, "Refined clean code", librarian);
        assertEquals("Book updated successfully", success);

        Book updated = Main.bookService.getBookById(book.getBookId());
        assertEquals("Clean Code 2nd Ed", updated.getTitle());
        assertEquals(2021, updated.getPublicationYear());
    }

    @Test
    void testC5_RemoveEligibleCopy_ByStaff() {
        User librarian = Main.userRepository.findByPhone("8888888888");

        // Add a single-copy book to test removal
        Main.bookService.addBookFromDetails(
                "978-1111111111", "Removable Book", "Author One",
                "Fiction", "Publisher X", 2020, "Desc", 1, librarian
        );

        Book book = Main.bookService.getBookByIsbn("978-1111111111");
        assertNotNull(book);
        List<BookCopy> copies = Main.bookCopyRepository.findByBookId(book.getBookId());
        assertEquals(1, copies.size());
        int copyId = copies.get(0).getBookCopyId();

        // Remove the copy
        String result = Main.bookService.removeBookCopy(copyId, librarian);
        assertTrue(result.contains("Book copy removed successfully"));

        // Copy is deleted
        assertNull(Main.bookCopyRepository.findById(copyId));

        // Book is marked REMOVED since last copy removed
        Book removedBook = Main.bookService.getBookById(book.getBookId());
        assertEquals(BookStatus.REMOVED, removedBook.getStatus());
    }

    @Test
    void testC6_CannotRemoveCopy_WithActiveLoanOrReservation() {
        User librarian = Main.userRepository.findByPhone("8888888888");
        Book book = Main.bookService.getBookByIsbn("978-0132350884");
        assertNotNull(book);

        // Copy is issued in SyntheticData
        Transaction loan = Main.bookTransactionService.findUniqueIssuedLoanForBook("9870000001", book.getBookId());
        assertNotNull(loan);
        int issuedCopyId = loan.getBookCopyId();

        String result = Main.bookService.removeBookCopy(issuedCopyId, librarian);
        assertTrue(result.contains("Unable to remove copy") || result.contains("cannot be removed"));
        assertNotNull(Main.bookCopyRepository.findById(issuedCopyId));
    }

    @Test
    void testC7_InvalidCatalogueOperations_LeaveCatalogueUnchanged() {
        User librarian = Main.userRepository.findByPhone("8888888888");
        int initialCount = Main.bookService.getAllBooks().size();

        // Invalid publication year
        String err1 = Main.bookService.addBookFromDetails("978-9999999991", "Title", "Author", "Tech", "Pub", 3000, "Desc", 1, librarian);
        assertTrue(err1.contains("Unable to add book"));

        // 0 copies
        String err2 = Main.bookService.addBookFromDetails("978-9999999992", "Title", "Author", "Tech", "Pub", 2020, "Desc", 0, librarian);
        assertTrue(err2.contains("Unable to add book"));

        // Member attempting to add book
        User member = Main.userRepository.findByPhone("9870000001");
        String err3 = Main.bookService.addBookFromDetails("978-9999999993", "Title", "Author", "Tech", "Pub", 2020, "Desc", 1, member);
        assertTrue(err3.contains("Insufficient permissions"));

        assertEquals(initialCount, Main.bookService.getAllBooks().size());
    }

    // =========================================================================
    // SECTION D: Book Request and Queue Processing
    // =========================================================================

    @Test
    void testD1_RequestAvailableCopy_AutoReservesCopy() {
        // Clear pending fine for member2 so they can borrow
        Main.paymentService.payFine("9870000002", 3, 30.0, PaymentMethod.UPI);

        User member = Main.userRepository.findByPhone("9870000002");
        Book book = Main.bookService.getBookByIsbn("978-0134494166");
        assertNotNull(book);

        Transaction tx = Main.bookTransactionService.requestBookByIsbn(member.getPhone(), book.getIsbn(), member);
        assertNotNull(tx);
        assertEquals(TransactionStatus.RESERVED, tx.getStatus());
        assertTrue(tx.getBookCopyId() > 0);

        BookCopy copy = Main.bookCopyRepository.findById(tx.getBookCopyId());
        assertEquals(BookCopyStatus.RESERVED, copy.getStatus());
    }

    @Test
    void testD2_RequestWhenAllCopiesUnavailable_QueuedAsRequested() {
        // Clear pending fine for member2
        Main.paymentService.payFine("9870000002", 3, 30.0, PaymentMethod.UPI);

        // Add book with 1 copy
        User librarian = Main.userRepository.findByPhone("8888888888");
        Main.bookService.addBookFromDetails("978-5555555555", "Single Copy Book", "Author", "Tech", "Pub", 2020, "Desc", 1, librarian);

        Book book = Main.bookService.getBookByIsbn("978-5555555555");
        assertNotNull(book);
        User m1 = Main.userRepository.findByPhone("9870000001");
        User m2 = Main.userRepository.findByPhone("9870000002");

        // m1 requests and gets it auto-reserved
        Transaction tx1 = Main.bookTransactionService.requestBookByIsbn(m1.getPhone(), book.getIsbn(), m1);
        assertEquals(TransactionStatus.RESERVED, tx1.getStatus());

        // m2 requests, now all copies are unavailable -> must be queued in REQUESTED status
        Transaction tx2 = Main.bookTransactionService.requestBookByIsbn(m2.getPhone(), book.getIsbn(), m2);
        assertEquals(TransactionStatus.REQUESTED, tx2.getStatus());
        assertEquals(0, tx2.getBookCopyId());
    }

    @Test
    void testD3_IneligibleMemberCannotRequestBook() {
        // Register member with no membership
        Main.authService.register("No Sub", "nosub@test.com", "9870000033", "Pass123!", 22, "MALE");
        User noSubUser = Main.userRepository.findByPhone("9870000033");
        Book book = Main.bookService.getBookByIsbn("978-0134494166");
        assertNotNull(book);

        assertThrows(IllegalStateException.class, () -> {
            Main.bookTransactionService.requestBookByIsbn(noSubUser.getPhone(), book.getIsbn(), noSubUser);
        });
    }

    @Test
    void testD4_MemberCannotExceedBorrowingLimit() {
        // Member 9870000001 has max 3 books on Standard plan
        User member = Main.userRepository.findByPhone("9870000001");

        // Simulate reaching limit by creating active transactions
        for (int i = 0; i < 3; i++) {
            Transaction t = new Transaction(DataStore.getTransactionId(), member.getPhone(), 100 + i, 200 + i,
                    TransactionStatus.ISSUED, LocalDateTime.now().minusDays(5), LocalDateTime.now().minusDays(5),
                    LocalDate.now().plusDays(10), null);
            Main.transactionRepository.save(t);
        }

        Book book = Main.bookService.getBookByIsbn("978-0134494166");
        assertNotNull(book);
        assertThrows(IllegalStateException.class, () -> {
            Main.bookTransactionService.requestBookByIsbn(member.getPhone(), book.getIsbn(), member);
        });
    }

    @Test
    void testD5_CancelRequest_FreesReservedCopy() {
        Main.paymentService.payFine("9870000002", 3, 30.0, PaymentMethod.UPI);
        User member = Main.userRepository.findByPhone("9870000002");
        Book book = Main.bookService.getBookByIsbn("978-0134494166");
        assertNotNull(book);

        Transaction tx = Main.bookTransactionService.requestBookByIsbn(member.getPhone(), book.getIsbn(), member);
        assertEquals(TransactionStatus.RESERVED, tx.getStatus());
        int reservedCopyId = tx.getBookCopyId();

        // Member cancels request
        Main.bookTransactionService.cancelRequest(member.getPhone(), book.getIsbn(), member);

        Transaction cancelledTx = Main.transactionRepository.findById(tx.getTransactionId());
        assertEquals(TransactionStatus.CANCELLED, cancelledTx.getStatus());

        BookCopy copy = Main.bookCopyRepository.findById(reservedCopyId);
        // Copy returned to AVAILABLE
        assertEquals(BookCopyStatus.AVAILABLE, copy.getStatus());
    }

    @Test
    void testD6_QueuePriority_PremiumBeforeStandard() {
        User librarian = Main.userRepository.findByPhone("8888888888");
        Main.bookService.addBookFromDetails("978-7777777777", "High Demand Book", "Author", "Tech", "Pub", 2020, "Desc", 1, librarian);
        Book book = Main.bookService.getBookByIsbn("978-7777777777");
        assertNotNull(book);

        User mHolder = Main.userRepository.findByPhone("9870000001");
        Transaction txHolder = Main.bookTransactionService.requestBookByIsbn(mHolder.getPhone(), book.getIsbn(), mHolder);
        assertEquals(TransactionStatus.RESERVED, txHolder.getStatus());

        // Create standard member mStd
        Main.authService.register("Std Queuer", "stdq@test.com", "9870000041", "Pass123!", 25, "MALE");
        User mStd = Main.userRepository.findByPhone("9870000041");
        Main.membershipService.purchaseMembership(mStd.getPhone(), 1, 1, PaymentMethod.UPI);

        // Create premium member mPrem
        Main.authService.register("Prem Queuer", "premq@test.com", "9870000042", "Pass123!", 25, "FEMALE");
        User mPrem = Main.userRepository.findByPhone("9870000042");
        Main.membershipService.purchaseMembership(mPrem.getPhone(), 2, 1, PaymentMethod.UPI);

        // Standard requests first
        Transaction txStd = Main.bookTransactionService.requestBookByIsbn(mStd.getPhone(), book.getIsbn(), mStd);
        assertEquals(TransactionStatus.REQUESTED, txStd.getStatus());

        // Premium requests second
        Transaction txPrem = Main.bookTransactionService.requestBookByIsbn(mPrem.getPhone(), book.getIsbn(), mPrem);
        assertEquals(TransactionStatus.REQUESTED, txPrem.getStatus());

        // Check next eligible request: Premium must have priority over Standard
        Transaction next = Main.bookTransactionService.getNextEligibleRequest(book.getBookId());
        assertNotNull(next);
        assertEquals(txPrem.getTransactionId(), next.getTransactionId(), "Premium member should have queue priority");
    }

    @Test
    void testD7_EqualPriorityTieBreaking_FCFS() {
        User librarian = Main.userRepository.findByPhone("8888888888");
        Main.bookService.addBookFromDetails("978-6666666666", "Tie Break Book", "Author", "Tech", "Pub", 2020, "Desc", 1, librarian);
        Book book = Main.bookService.getBookByIsbn("978-6666666666");
        assertNotNull(book);

        User mHolder = Main.userRepository.findByPhone("9870000001");
        Main.bookTransactionService.requestBookByIsbn(mHolder.getPhone(), book.getIsbn(), mHolder);

        // Two standard members
        Main.authService.register("Std 1", "std1@test.com", "9870000043", "Pass123!", 25, "MALE");
        User mStd1 = Main.userRepository.findByPhone("9870000043");
        Main.membershipService.purchaseMembership(mStd1.getPhone(), 1, 1, PaymentMethod.UPI);

        Main.authService.register("Std 2", "std2@test.com", "9870000044", "Pass123!", 25, "MALE");
        User mStd2 = Main.userRepository.findByPhone("9870000044");
        Main.membershipService.purchaseMembership(mStd2.getPhone(), 1, 1, PaymentMethod.UPI);

        Transaction tx1 = Main.bookTransactionService.requestBookByIsbn(mStd1.getPhone(), book.getIsbn(), mStd1);
        Transaction tx2 = Main.bookTransactionService.requestBookByIsbn(mStd2.getPhone(), book.getIsbn(), mStd2);

        Transaction next = Main.bookTransactionService.getNextEligibleRequest(book.getBookId());
        assertNotNull(next);
        assertEquals(tx1.getTransactionId(), next.getTransactionId(), "First requester should win tie-break");
    }

    // =========================================================================
    // SECTION E: Issue, Return, and Renewal
    // =========================================================================

    @Test
    void testE1_FullLifecycle_RequestedReservedReadyIssuedReturned() {
        Main.paymentService.payFine("9870000002", 3, 30.0, PaymentMethod.UPI);
        User librarian = Main.userRepository.findByPhone("8888888888");
        User member = Main.userRepository.findByPhone("9870000002");
        Book book = Main.bookService.getBookByIsbn("978-0134494166");
        assertNotNull(book);

        // 1. Request -> RESERVED
        Transaction tx = Main.bookTransactionService.requestBookByIsbn(member.getPhone(), book.getIsbn(), member);
        assertEquals(TransactionStatus.RESERVED, tx.getStatus());

        // 2. Mark ready for pickup -> READY_FOR_PICKUP
        boolean ready = Main.bookTransactionService.markReadyForPickup(tx.getTransactionId(), librarian);
        assertTrue(ready);
        Transaction txReady = Main.transactionRepository.findById(tx.getTransactionId());
        assertEquals(TransactionStatus.READY_FOR_PICKUP, txReady.getStatus());

        // 3. Issue -> ISSUED
        String issueErr = Main.bookTransactionService.issueBookWithResult(tx.getTransactionId(), librarian);
        assertNull(issueErr);
        Transaction txIssued = Main.transactionRepository.findById(tx.getTransactionId());
        assertEquals(TransactionStatus.ISSUED, txIssued.getStatus());
        assertEquals(BookCopyStatus.ISSUED, Main.bookCopyRepository.findById(txIssued.getBookCopyId()).getStatus());

        // 4. Return on-time in good condition (1) -> RETURNED
        String returnErr = Main.bookTransactionService.processReturnWithResult(tx.getTransactionId(), 1, librarian);
        assertNull(returnErr);
        Transaction txReturned = Main.transactionRepository.findById(tx.getTransactionId());
        assertEquals(TransactionStatus.RETURNED, txReturned.getStatus());
        assertEquals(BookCopyStatus.AVAILABLE, Main.bookCopyRepository.findById(txReturned.getBookCopyId()).getStatus());
    }

    @Test
    void testE2_CannotIssueUnavailableOrNotReadyCopy() {
        Main.paymentService.payFine("9870000002", 3, 30.0, PaymentMethod.UPI);
        User librarian = Main.userRepository.findByPhone("8888888888");
        User member = Main.userRepository.findByPhone("9870000002");
        Book book = Main.bookService.getBookByIsbn("978-0134494166");
        assertNotNull(book);

        Transaction tx = Main.bookTransactionService.requestBookByIsbn(member.getPhone(), book.getIsbn(), member);
        assertEquals(TransactionStatus.RESERVED, tx.getStatus());

        // Cannot issue while in RESERVED state (must be READY_FOR_PICKUP)
        String issueErr = Main.bookTransactionService.issueBookWithResult(tx.getTransactionId(), librarian);
        assertEquals("Book is not ready for pickup.", issueErr);

        // Member cannot issue book
        String permErr = Main.bookTransactionService.issueBookWithResult(tx.getTransactionId(), member);
        assertEquals("Not allowed.", permErr);
    }

    @Test
    void testE3_CannotReturnBookNotCheckedOut() {
        User librarian = Main.userRepository.findByPhone("8888888888");

        // Non-existent transaction
        String err1 = Main.bookTransactionService.processReturnWithResult(999999, 1, librarian);
        assertEquals("Transaction not found.", err1);

        // Member cannot process return
        User member = Main.userRepository.findByPhone("9870000001");
        String err2 = Main.bookTransactionService.processReturnWithResult(1, 1, member);
        assertEquals("Not allowed.", err2);
    }

    @Test
    void testE4_DamagedOrLostCopy_MarkedAppropriatelyAndNotAvailable() {
        User librarian = Main.userRepository.findByPhone("8888888888");
        Book book = Main.bookService.getBookByIsbn("978-0132350884");
        assertNotNull(book);

        // Loan is issued in SyntheticData
        Transaction loan = Main.bookTransactionService.findUniqueIssuedLoanForBook("9870000001", book.getBookId());
        assertNotNull(loan);
        int copyId = loan.getBookCopyId();

        // Process return as condition 3 (LOST)
        String returnErr = Main.bookTransactionService.processReturnWithResult(loan.getTransactionId(), 3, librarian);
        assertNull(returnErr);

        Transaction updatedTx = Main.transactionRepository.findById(loan.getTransactionId());
        assertEquals(TransactionStatus.LOST, updatedTx.getStatus());

        BookCopy copy = Main.bookCopyRepository.findById(copyId);
        assertEquals(BookCopyStatus.LOST, copy.getStatus());

        // Verify incident fine generated
        List<Fine> fines = Main.fineRepository.findByUserPhone("9870000001");
        boolean hasLostFine = fines.stream().anyMatch(f -> f.getType() == FineType.LOST_BOOK);
        assertTrue(hasLostFine, "Lost book fine must be generated");
    }

    @Test
    void testE5_RenewLoan_EligibleVsOverdue() {
        User member = Main.userRepository.findByPhone("9870000001");
        Book book = Main.bookService.getBookByIsbn("978-0132350884");
        assertNotNull(book);

        Transaction loan = Main.bookTransactionService.findUniqueIssuedLoanForBook("9870000001", book.getBookId());
        assertNotNull(loan);

        LocalDate oldDue = loan.getDueDate();
        boolean renewed = Main.bookTransactionService.renewBook("9870000001", "978-0132350884", member);
        assertTrue(renewed);

        Transaction renewedTx = Main.transactionRepository.findById(loan.getTransactionId());
        assertTrue(renewedTx.getDueDate().isAfter(oldDue));
    }

    // =========================================================================
    // SECTION F: Fine Generation, Payment, and Refunds
    // =========================================================================

    @Test
    void testF1_OverdueReturnGeneratesFine_OnTimeDoesNot() {
        User librarian = Main.userRepository.findByPhone("8888888888");
        Book book = Main.bookService.getBookByIsbn("978-0134494166");
        assertNotNull(book);

        BookCopy copy = Main.bookCopyRepository.findAvailableCopy(book.getBookId());
        assertNotNull(copy);
        copy.reserve();
        copy.issue();
        Main.bookCopyRepository.save(copy);

        Transaction overdueLoan = new Transaction(DataStore.getTransactionId(), "9870000002", book.getBookId(), copy.getBookCopyId(),
                TransactionStatus.ISSUED, LocalDateTime.now().minusDays(20), LocalDateTime.now().minusDays(20),
                LocalDate.now().minusDays(5), null);
        Main.transactionRepository.save(overdueLoan);

        Main.bookTransactionService.processReturnWithResult(overdueLoan.getTransactionId(), 1, librarian);

        List<Fine> fines = Main.fineRepository.findByUserPhone("9870000002");
        assertFalse(fines.isEmpty());
        Fine overdueFine = fines.get(fines.size() - 1);
        assertEquals(FineType.OVERDUE, overdueFine.getType());
        assertTrue(overdueFine.getAmount() > 0);
    }

    @Test
    void testF2_FineCannotBeGeneratedTwiceForSameIncident() {
        Fine f1 = Main.fineService.createOverdueFine(1, LocalDate.now().plusDays(3));
        Fine f2 = Main.fineService.createOverdueFine(1, LocalDate.now().plusDays(3));

        if (f1 != null && f2 != null) {
            assertEquals(f1.getFineId(), f2.getFineId(), "Duplicate fine must not be created");
        }
    }

    @Test
    void testF3_PayFineInFullAndPartial() {
        int fineId = DataStore.getFineId();
        Fine fine = new Fine(fineId, "9870000001", 1, 100.0, FineType.OVERDUE);
        Main.fineRepository.save(fine);

        // Partial payment: ₹40
        Payment p1 = Main.paymentService.payFine("9870000001", fineId, 40.0, PaymentMethod.UPI);
        assertNotNull(p1);
        assertEquals(PaymentStatus.SUCCESS, p1.getStatus());

        Fine afterP1 = Main.fineRepository.findById(fineId);
        assertEquals(FineStatus.PARTIALLY_PAID, afterP1.getStatus());
        assertEquals(60.0, afterP1.getRemainingAmount());

        // Full payment of remaining: ₹60
        Payment p2 = Main.paymentService.payFine("9870000001", fineId, 60.0, PaymentMethod.CARD);
        assertNotNull(p2);
        assertEquals(PaymentStatus.SUCCESS, p2.getStatus());

        Fine afterP2 = Main.fineRepository.findById(fineId);
        assertEquals(FineStatus.PAID, afterP2.getStatus());
        assertEquals(0.0, afterP2.getRemainingAmount());
    }

    @Test
    void testF4_RejectPaymentForNonExistentOrAlreadyPaidFine() {
        // Non-existent fine
        Payment p1 = Main.paymentService.payFine("9870000001", 999999, 50.0, PaymentMethod.UPI);
        assertNull(p1);

        // Already paid fine
        int fineId = DataStore.getFineId();
        Fine fine = new Fine(fineId, "9870000001", 1, 50.0, FineType.OVERDUE);
        Main.fineRepository.save(fine);
        Main.paymentService.payFine("9870000001", fineId, 50.0, PaymentMethod.UPI);

        Payment p2 = Main.paymentService.payFine("9870000001", fineId, 50.0, PaymentMethod.UPI);
        assertNull(p2, "Payment on already paid fine must be rejected");
    }

    @Test
    void testF5_SimulateFailedFinePayment_LeavesBalanceUnchanged() {
        int fineId = DataStore.getFineId();
        Fine fine = new Fine(fineId, "9870000001", 1, 100.0, FineType.OVERDUE);
        Main.fineRepository.save(fine);

        PaymentStrategy rejectingStrategy = new PaymentStrategy() {
            @Override
            public int pay(double amount) {
                return 0; // rejected
            }
            @Override
            public void refund(int gatewayReference) {}
        };

        service.PaymentService svc = new service.PaymentService(
                Main.paymentRepository, Main.fineRepository, rejectingStrategy,
                Main.auditService, Main.membershipRepository, Main.transactionRepository
        );

        Payment payment = svc.payFine("9870000001", fineId, 50.0, PaymentMethod.UPI);
        assertNotNull(payment);
        assertEquals(PaymentStatus.FAILED, payment.getStatus());

        Fine stored = Main.fineRepository.findById(fineId);
        assertEquals(100.0, stored.getRemainingAmount(), "Failed payment must not decrease fine balance");
        assertEquals(FineStatus.PENDING, stored.getStatus());
    }

    // =========================================================================
    // SECTION G: Staff Operations and Authorization
    // =========================================================================

    @Test
    void testG1_RolePermissionsEnforcedAtServiceLayer() {
        User member = Main.userRepository.findByPhone("9870000001");
        User librarian = Main.userRepository.findByPhone("8888888888");

        // Member cannot manage catalogue
        assertFalse(Main.bookService.addBook(new Book("111", "T", "P", 2020, "D"), 1, member));

        // Librarian cannot create membership plans (admin only)
        assertThrows(SecurityException.class, () -> {
            Main.membershipPlanService.createPlan(librarian, "Librarian Plan", 100.0, 3, 14, 5.0, 100.0, 50.0);
        });

        // Librarian cannot activate/deactivate accounts (admin only)
        assertThrows(SecurityException.class, () -> {
            Main.userService.deactivateAccount(librarian, 1);
        });
    }

    @Test
    void testG2_InactiveStaffCannotPerformStaffActions() {
        User librarian = Main.userRepository.findByPhone("8888888888");
        librarian.setStatus(UserStatus.INACTIVE);
        Main.userRepository.save(librarian);

        // Inactive librarian cannot manage catalogue
        assertFalse(Main.bookService.addBook(new Book("111", "T", "P", 2020, "D"), 1, librarian));

        // Inactive librarian cannot manage inventory in policy
        assertFalse(Main.policyService.canManageInventory(librarian));
    }

    @Test
    void testG3_StaffActingOnTargetMemberWithinPermittedScope() {
        Main.paymentService.payFine("9870000002", 3, 30.0, PaymentMethod.UPI);
        User librarian = Main.userRepository.findByPhone("8888888888");
        User member = Main.userRepository.findByPhone("9870000002");
        Book book = Main.bookService.getBookByIsbn("978-0134494166");
        assertNotNull(book);

        // Librarian requests book on behalf of member
        Transaction tx = Main.bookTransactionService.requestBookByIsbn(member.getPhone(), book.getIsbn(), librarian);
        assertNotNull(tx);
        assertEquals(member.getPhone(), tx.getUserPhone());
    }

    // =========================================================================
    // SECTION H: Payment and Transaction Consistency
    // =========================================================================

    @Test
    void testH1_MultiStepFailureDoesNotLeaveCorruptState() {
        // Multi-step check 1: Payment failure leaves no orphaned membership
        Main.authService.register("Consistency User", "con@test.com", "9870000088", "Pass123!", 24, "MALE");
        User fresh = Main.userRepository.findByPhone("9870000088");
        PaymentStrategy failing = new PaymentStrategy() {
            @Override
            public int pay(double amount) { return -1; }
            @Override
            public void refund(int ref) {}
        };
        service.MembershipService memSvc = new service.MembershipService(
                Main.userRepository, Main.membershipRepository, Main.membershipPlanService,
                Main.paymentRepository, failing, Main.auditService, Main.notificationService
        );

        assertThrows(IllegalStateException.class, () -> {
            memSvc.purchaseMembership(fresh.getPhone(), 1, 1, PaymentMethod.UPI);
        });
        assertNull(Main.membershipRepository.findActiveByUserPhone(fresh.getPhone()));

        // Multi-step check 2: Refund on already refunded fine is blocked
        User admin = Main.userRepository.findByPhone("9999999999");
        int fineId = DataStore.getFineId();
        Fine fine = new Fine(fineId, fresh.getPhone(), 1, 50.0, FineType.OVERDUE);
        Main.fineRepository.save(fine);
        Payment p = Main.paymentService.payFine(fresh.getPhone(), fineId, 50.0, PaymentMethod.CARD);
        assertNotNull(p);

        String r1 = Main.paymentService.manageRefund(p.getPaymentId(), admin);
        assertNull(r1);

        String r2 = Main.paymentService.manageRefund(p.getPaymentId(), admin);
        assertEquals("Payment has already been refunded.", r2);
    }

    // =========================================================================
    // SECTION I: UI, Menus, Validation, and Navigation
    // =========================================================================

    @Test
    void testI1_MenuValidationAndRetry() {
        provideInput("abc\n\n42\n");
        int val = Main.readInt();
        assertEquals(42, val);
        String output = outContent.toString();
        assertTrue(output.contains("Invalid input. Please enter a valid number:"));
    }

    @Test
    void testI2_GoHomeAndBackNavigation() {
        // Test goHome() throws GoHomeException cleanly
        assertThrows(GoHomeException.class, Main::goHome);

        // Test helper commands
        assertTrue(Main.isBackCommand("back"));
        assertTrue(Main.isBackCommand("  BACK "));
        assertFalse(Main.isBackCommand("exit"));

        assertTrue(Main.isHomeCommand("home"));
        assertTrue(Main.isHomeCommand(" HOME  "));
        assertFalse(Main.isHomeCommand("menu"));
    }
}
