package ui;

import enums.*;
import model.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import paymentStrategy.PaymentStrategy;
import repository.DataStore;
import repository.SyntheticData;
import service.AuthService;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.PrintStream;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class AuditVerificationTest {

    private final InputStream originalIn = System.in;
    private final PrintStream originalOut = System.out;
    private ByteArrayOutputStream outContent;

    @BeforeEach
    void setUp() {
        outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));
        Main.resetData();
    }

    @AfterEach
    void tearDown() {
        System.setIn(originalIn);
        System.setOut(originalOut);
        Main.currentUser = null;
    }

    private void provideInput(String data) {
        System.setIn(new ByteArrayInputStream(data.getBytes(StandardCharsets.UTF_8)));
        Main.sc = new java.util.Scanner(System.in);
    }

    @Test
    void test1_MemberCannotPayOtherMemberFine() {
        // Create a fine for member 9870000001
        int fineId = DataStore.getFineId();
        Fine fine = new Fine(fineId, "9870000001", 1, 100.0, FineType.OVERDUE);
        Main.fineRepository.save(fine);

        // Try paying with another member's phone number "9870000002"
        Payment payment = Main.paymentService.payFine("9870000002", fineId, 50.0, PaymentMethod.UPI);
        assertNull(payment, "PaymentService must reject paying another member's fine");

        // The fine balance must remain intact
        Fine stored = Main.fineRepository.findById(fineId);
        assertEquals(100.0, stored.getRemainingAmount());
        assertEquals(FineStatus.PENDING, stored.getStatus());
    }

    @Test
    void test2_RefundFinePaymentRevertsFineStatusAndAmount() {
        // Create fine and pay it
        int fineId = DataStore.getFineId();
        Fine fine = new Fine(fineId, "9870000001", 1, 50.0, FineType.OVERDUE);
        Main.fineRepository.save(fine);

        Payment payment = Main.paymentService.payFine("9870000001", fineId, 50.0, PaymentMethod.CARD);
        assertNotNull(payment);
        assertTrue(payment.isSuccessful());

        Fine paidFine = Main.fineRepository.findById(fineId);
        assertEquals(FineStatus.PAID, paidFine.getStatus());
        assertEquals(0.0, paidFine.getRemainingAmount());

        // Process refund by Admin
        User admin = Main.userService.findByPhone("9999999999");
        String refundErr = Main.paymentService.manageRefund(payment.getPaymentId(), admin);
        assertNull(refundErr, "Refund should succeed: " + refundErr);

        Payment refundedPayment = Main.paymentService.findById(payment.getPaymentId());
        assertEquals(PaymentStatus.REFUNDED, refundedPayment.getStatus());

        // Fine must be reverted back to pending with restored balance
        Fine revertedFine = Main.fineRepository.findById(fineId);
        assertEquals(FineStatus.PENDING, revertedFine.getStatus());
        assertEquals(50.0, revertedFine.getRemainingAmount());

        // Attempting to refund again must be rejected
        String secondRefundErr = Main.paymentService.manageRefund(payment.getPaymentId(), admin);
        assertEquals("Payment has already been refunded.", secondRefundErr);
    }

    @Test
    void test3_FailedPaymentDoesNotActivateMembership() {
        // Create a new member without membership
        User freshUser = new User("Payment Fail User", "payfail@test.com", "9870000055",
                AuthService.hashPassword("MemberPass123!"), UserRole.MEMBER, UserStatus.ACTIVE);
        Main.userRepository.save(freshUser);

        // MembershipService using custom failing strategy
        PaymentStrategy failingStrategy = new PaymentStrategy() {
            @Override
            public int pay(double amount) {
                return 0; // rejected by gateway
            }

            @Override
            public void refund(int gatewayReference) {
            }
        };

        service.MembershipService testMembershipService = new service.MembershipService(
                Main.userRepository, Main.membershipRepository, Main.membershipPlanService,
                Main.paymentRepository, failingStrategy, Main.auditService, Main.notificationService);

        // Activating membership must fail
        assertThrows(IllegalStateException.class, () -> {
            testMembershipService.purchaseMembership("9870000055", 1, 1, PaymentMethod.UPI);
        });

        // Verify member has NO active membership
        assertNull(Main.membershipRepository.findActiveByUserPhone("9870000055"));
    }

    @Test
    void test4_MemberRegistrationPreservesAgeAndGender() {
        // Choice 2: Register
        // Name, Phone, Email, Age: 29, Gender: FEMALE, Password, Confirm
        String input = String.join("\n",
                "2",
                "Clara Oswald",
                "9876543210",
                "clara@example.com",
                "29",
                "FEMALE",
                "DoctorWho123!",
                "DoctorWho123!"
        ) + "\n";

        provideInput(input);
        Member.member();

        User created = Main.userService.findByPhone("9876543210");
        assertNotNull(created);
        assertEquals("Clara Oswald", created.getName());
        assertEquals(29, created.getAge(), "User age must be preserved on registration");
        assertEquals("FEMALE", created.getGender(), "User gender must be preserved on registration");
    }

    @Test
    void test5_CannotRemoveCopyLinkedToActiveTransaction() {
        User librarian = Main.userService.findByPhone("8888888888");

        // Book 978-0132350884 has issued loan copy in SyntheticData
        Transaction loan = Main.bookTransactionService.findUniqueIssuedLoanForBook("9870000001", 1);
        if (loan != null && loan.getBookCopyId() > 0) {
            String result = Main.bookService.removeBookCopy(loan.getBookCopyId(), librarian);
            assertTrue(result.contains("Unable to remove copy") || result.contains("cannot be removed"),
                    "Cannot remove copy linked to active transaction: " + result);
        }
    }

    @Test
    void test6_MemberCannotRequestCancelOrRenewForAnotherMember() {
        User member1 = Main.userService.findByPhone("9870000001");

        // Member1 trying to request book for Member2 ("9870000002")
        assertThrows(IllegalStateException.class, () -> {
            Main.bookTransactionService.requestBookByIsbn("9870000002", "978-0132350884", member1);
        }, "Member cannot request book on behalf of another member");

        // Member1 trying to cancel request for Member2
        assertThrows(IllegalStateException.class, () -> {
            Main.bookTransactionService.cancelRequest("9870000002", "978-0132350884", member1);
        }, "Member cannot cancel request on behalf of another member");

        // Member1 trying to renew book for Member2
        assertThrows(IllegalStateException.class, () -> {
            Main.bookTransactionService.renewBook("9870000002", "978-0132350884", member1);
        }, "Member cannot renew book on behalf of another member");
    }

    @Test
    void test7_AdminPrivilegeEnforcedAgainstRepository() {
        // Fake/inactive admin object
        User fakeAdmin = new User("Fake Admin", "fake@admin.com", "9999999999",
                AuthService.hashPassword("admin123"), UserRole.ADMIN, UserStatus.INACTIVE);

        // Service layer must reject inactive admin
        assertThrows(SecurityException.class, () -> {
            Main.userService.activateAccount(fakeAdmin, 1);
        });

        assertThrows(SecurityException.class, () -> {
            Main.membershipPlanService.createPlan(fakeAdmin, "Hacker Plan", 10.0, 5, 14, 5.0, 100.0, 50.0);
        });
    }

    @Test
    void test8_FineCalculationsAreFiniteAndDeduplicated() {
        // Creating overdue fine on transaction 1
        Fine f1 = Main.fineService.createOverdueFine(1, LocalDate.now().plusDays(5));
        if (f1 != null) {
            assertTrue(Double.isFinite(f1.getAmount()));
            assertTrue(f1.getAmount() > 0);

            // Re-evaluating with same or lesser date does not duplicate fine
            Fine f2 = Main.fineService.createOverdueFine(1, LocalDate.now().plusDays(5));
            assertEquals(f1.getFineId(), f2.getFineId(), "Duplicate fine must not be created");
        }
    }

    @Test
    void test9_ChoosePaymentMethodRetriesOnInvalidInput() {
        // Invalid input "9", then valid "1" (UPI)
        provideInput("9\n1\n");
        PaymentMethod method = UiHelpers.choosePaymentMethod();
        assertEquals(PaymentMethod.UPI, method, "Should return UPI after retry");
        String output = outContent.toString();
        assertTrue(output.contains("Invalid payment method"), "Should notify invalid payment method and retry");
    }
}
