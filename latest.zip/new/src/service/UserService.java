package service;

import enums.UserRole;
import enums.UserStatus;
import model.User;
import repository.UserRepository;

public class UserService {
    private final UserRepository inMemoryUserRepository;
    private final AuditService auditService;


    public UserService(UserRepository inMemoryUserRepository, AuditService auditService) {
        this.inMemoryUserRepository=inMemoryUserRepository;
        this.auditService=auditService;
    }

    public boolean phoneExists(String phone) {
        return phone != null && !phone.isBlank() && inMemoryUserRepository.findByPhone(phone.trim()) != null;
    }

    public boolean emailExists(String email) {
        return email != null && !email.isBlank() && inMemoryUserRepository.findByEmail(email.trim()) != null;
    }


    public User findByPhone(String phone) {
        if (phone == null || phone.isBlank()) return null;
        return inMemoryUserRepository.findByPhone(phone.trim());
    }

    public User findByEmail(String email) {
        if (email == null || email.isBlank()) return null;
        return inMemoryUserRepository.findByEmail(email.trim());
    }

    private void record(String phone, String action, String details) {
        if (auditService != null) auditService.record(phone, action, "USER", phone, details);
    }


    public void createUser(String name, String email, String phone, String password, UserRole role, int age, String gender) {
        if (phoneExists(phone)) {
            throw new IllegalArgumentException("Phone number already registered.");
        }
        if (emailExists(email)) {
            throw new IllegalArgumentException("Email address already registered.");
        }
        User user = new User(name, email, phone, AuthService.hashPassword(password), role, UserStatus.ACTIVE, age, gender);
        inMemoryUserRepository.save(user);
        record(phone, "USER_CREATED", "User account created");
    }

    public void createUser(String name, String email, String phone, String password, UserRole role) {
        createUser(name, email, phone, password, role, 0, "UNSPECIFIED");
    }

    public void addLibrarian(User admin, String name, String email, String phone, String password) {
        validateStaffCreation(admin, name, email, phone, password);
        User librarian = new User(name.trim(), email.trim(), phone.trim(), AuthService.hashPassword(password), UserRole.LIBRARIAN, UserStatus.ACTIVE);
        inMemoryUserRepository.save(librarian);
        record(admin.getPhone(), "LIBRARIAN_CREATED", "Created librarian account for " + phone);
    }

    public void addAdmin(User currentAdmin, String name, String email, String phone, String password) {
        validateStaffCreation(currentAdmin, name, email, phone, password);
        User admin = new User(name.trim(), email.trim(), phone.trim(), AuthService.hashPassword(password), UserRole.ADMIN, UserStatus.ACTIVE);
        inMemoryUserRepository.save(admin);
        record(currentAdmin.getPhone(), "ADMIN_CREATED", "Created admin account for " + phone);
    }

    public void activateAccount(User admin, int userId) {
        if (isCurrentAdmin(admin)) {
            throw new SecurityException("Active administrator privileges required.");
        }
        User target = inMemoryUserRepository.findById(userId);
        if (target == null) {
            throw new IllegalArgumentException("User with ID " + userId + " not found.");
        }
        if (target.getStatus() == UserStatus.ACTIVE) {
            throw new IllegalStateException("User account is already active.");
        }
        target.setStatus(UserStatus.ACTIVE);
        inMemoryUserRepository.save(target);
        record(admin.getPhone(), "USER_ACTIVATED", "User ID " + userId + " activated");
    }

    public void deactivateAccount(User admin, int userId) {
        if (isCurrentAdmin(admin)) {
            throw new SecurityException("Active administrator privileges required.");
        }
        User target = inMemoryUserRepository.findById(userId);
        if (target == null) {
            throw new IllegalArgumentException("User with ID " + userId + " not found.");
        }
        if (target.getUserId() == admin.getUserId()) {
            throw new SecurityException("Administrators cannot deactivate their own account.");
        }
        if (target.getStatus() == UserStatus.INACTIVE) {
            throw new IllegalStateException("User account is already inactive.");
        }
        target.setStatus(UserStatus.INACTIVE);
        inMemoryUserRepository.save(target);
        record(admin.getPhone(), "USER_DEACTIVATED", "User ID " + userId + " deactivated");
    }

    public java.util.List<User> getAllUsers(User admin) {
        if (isCurrentAdmin(admin)) throw new SecurityException("Active administrator privileges required.");
        return inMemoryUserRepository.findAll();
    }

    private void validateStaffCreation(User admin, String name, String email, String phone, String password) {
        if (isCurrentAdmin(admin)) {
            throw new SecurityException("Active administrator privileges required.");
        }
        if (name == null || name.isBlank()) {
            throw new IllegalArgumentException("Name cannot be empty.");
        }
        if (phone == null || !phone.trim().matches("\\d{10}")) {
            throw new IllegalArgumentException("Phone number must be a valid 10-digit number.");
        }
        if (inMemoryUserRepository.findByPhone(phone.trim()) != null) {
            throw new IllegalArgumentException("Phone number is already registered.");
        }
        if (email == null || !email.trim().matches("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$")) {
            throw new IllegalArgumentException("Invalid email format.");
        }
        if (inMemoryUserRepository.findByEmail(email.trim()) != null) {
            throw new IllegalArgumentException("Email address is already registered.");
        }
        if (password == null || password.isBlank()) {
            throw new IllegalArgumentException("Password cannot be blank.");
        }
        if (password.length() < 8) {
            throw new IllegalArgumentException("Password must be at least 8 characters long.");
        }
    }

    private boolean isCurrentAdmin(User admin) {
        if (admin == null || admin.getStatus() != UserStatus.ACTIVE || admin.getRole() != UserRole.ADMIN) {
            return true;
        }
        User stored = inMemoryUserRepository.findByPhone(admin.getPhone());
        return stored == null || stored.getUserId() != admin.getUserId()
                || stored.getStatus() != UserStatus.ACTIVE || stored.getRole() != UserRole.ADMIN;
    }

    public void deleteUser(User admin, int userId) {
        if (isCurrentAdmin(admin)) {
            throw new SecurityException("Active administrator privileges required.");
        }
        User target = inMemoryUserRepository.findById(userId);
        if (target == null) {
            throw new IllegalArgumentException("User with ID " + userId + " not found.");
        }
        if (target.getUserId() == admin.getUserId()) {
            throw new SecurityException("Administrators cannot delete their own account.");
        }
        if (inMemoryUserRepository.hasDependentRecords(target.getPhone())) {
            throw new IllegalStateException("Cannot delete user with existing borrowing records, active loans, fines, or memberships.");
        }
        String phone = target.getPhone();
        inMemoryUserRepository.deleteById(phone);
        record(admin.getPhone(), "USER_DELETED", "User ID " + userId + " deleted");
    }



    public boolean updateNameForPhone(String name, String phone) {
        if (name == null || name.isBlank()) return false;
        User result = inMemoryUserRepository.findByPhone(phone);
        if(result != null) {
            if(!(result.getName().equals(name))) {
                result.setName(name);
                inMemoryUserRepository.save(result);
                record(phone, "USER_NAME_CHANGED", "Name updated");
                return true;
            }
            return false;
        }
        return false;
    }







    public boolean changePasswordForPhone(String phone, String oldPassword, String newPassword) {
        if (oldPassword == null || isValidMemberPassword(newPassword)) return false;
        User result = inMemoryUserRepository.findByPhone(phone);
        if (result == null) {
            return false;
        }
        User user = result;
        if (!AuthService.verifyPassword(oldPassword, user.getPasswordHash())) {
            return false;
        }
        if (AuthService.verifyPassword(newPassword, user.getPasswordHash())) {
            return false;
        }
        user.setPasswordHash(AuthService.hashPassword(newPassword));
        inMemoryUserRepository.save(user);
        record(phone, "PASSWORD_CHANGED", "Password changed");
        return true;
    }


    public boolean changePhoneForPhone(String oldPhone, String newPhone) {
        if (newPhone == null || newPhone.isBlank()) return false;
        boolean changed = inMemoryUserRepository.changePhone(oldPhone, newPhone);
        if (changed) record(oldPhone, "PHONE_CHANGED", "Phone changed to " + newPhone);
        return changed;
    }




    public boolean changeEmailForPhone(String email, String phone) {
        if (email == null || email.isBlank() || !email.contains("@")) return false;
        User result = inMemoryUserRepository.findByPhone(phone);
        if(result != null) {
            User user = result;
            if(!inMemoryUserRepository.existsByEmail(email)) {
                user.setEmail(email);
                inMemoryUserRepository.save(user);
                record(phone, "EMAIL_CHANGED", "Email address updated");
                return true;
            }
            return false;
        }
        return false;
    }





    public User findById(int userId) {
        return inMemoryUserRepository.findById(userId);
    }

    public String validateName(String name) {
        if (name == null || name.isBlank()) {
            return "Name cannot be empty.";
        }
        return null;
    }

    public String validateRegistrationPhone(String phone) {
        if (phone == null || phone.isBlank()) {
            return "Phone number cannot be empty.";
        }
        if (!phone.trim().matches("\\d{10}")) {
            return "Phone number must be a valid 10-digit number.";
        }
        if (inMemoryUserRepository.findByPhone(phone.trim()) != null) {
            return "An account with phone number " + phone.trim() + " already exists. Please log in or use a different phone number.";
        }
        return null;
    }

    public String validateRegistrationEmail(String email) {
        if (email == null || email.isBlank() || !email.trim().matches("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$")) {
            return "Invalid email format. Please provide a valid email address (e.g. user@example.com).";
        }
        if (inMemoryUserRepository.findByEmail(email.trim()) != null) {
            return "An account with email address " + email.trim() + " already exists. Please log in or use a different email address.";
        }
        return null;
    }

    public String validateAge(int age) {
        if (age < 1 || age > 120) {
            return "Age must be between 1 and 120.";
        }
        return null;
    }

    public String validateGender(String gender) {
        if (gender == null || !java.util.Set.of("MALE", "FEMALE", "NON_BINARY", "OTHER", "PREFER_NOT_TO_SAY").contains(gender.trim().toUpperCase())) {
            return "Choose one of the listed gender options.";
        }
        return null;
    }

    public String validateMemberPassword(String password) {
        if (password == null || password.isBlank()) {
            return "Password cannot be blank.";
        }
        if (isValidMemberPassword(password)) {
            return "Password must be at least 8 characters and include an uppercase letter, a number, and a special character.";
        }
        return null;
    }

    public String validateStaffName(String name) {
        if (name == null || name.isBlank()) {
            return "Name cannot be empty.";
        }
        return null;
    }

    public String validateStaffEmail(String email) {
        if (email == null || !email.trim().matches("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$")) {
            return "Invalid email format.";
        }
        if (inMemoryUserRepository.findByEmail(email.trim()) != null) {
            return "Email address is already registered.";
        }
        return null;
    }

    public String validateStaffPhone(String phone) {
        if (phone == null || !phone.trim().matches("\\d{10}")) {
            return "Phone number must be a valid 10-digit number.";
        }
        if (inMemoryUserRepository.findByPhone(phone.trim()) != null) {
            return "Phone number is already registered.";
        }
        return null;
    }

    public String validateStaffPassword(String password) {
        if (password == null || password.isBlank()) {
            return "Password cannot be blank.";
        }
        if (password.length() < 8) {
            return "Password must be at least 8 characters long.";
        }
        return null;
    }

    public String validateUpdateName(String newName, String currentName) {
        if (newName == null || newName.isBlank()) {
            return "Name cannot be empty";
        }
        if (newName.equals(currentName)) {
            return "Unable to update name: New name is identical to your current name.";
        }
        return null;
    }

    public String validateUpdateEmail(String newEmail, String currentEmail) {
        if (newEmail == null || !newEmail.matches("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$")) {
            return "Invalid email format. Please enter a valid email address (e.g., user@example.com).";
        }
        if (newEmail.equalsIgnoreCase(currentEmail)) {
            return "Unable to update email: New email is identical to your current email.";
        }
        if (inMemoryUserRepository.findByEmail(newEmail) != null) {
            return "Unable to update email: The email address '" + newEmail + "' is already registered to another account.";
        }
        return null;
    }

    public String validateUpdatePhone(String newPhone, String currentPhone) {
        if (newPhone == null || !newPhone.matches("\\d{10}")) {
            return "Enter a valid 10-digit phone number";
        }
        if (newPhone.equals(currentPhone)) {
            return "Unable to update phone: New phone number is identical to your current phone number.";
        }
        if (inMemoryUserRepository.findByPhone(newPhone) != null) {
            return "Unable to update phone: The phone number '" + newPhone + "' is already registered to another account.";
        }
        return null;
    }

    public String validateChangePassword(String oldPassword, String newPassword, String currentHash) {
        if (newPassword == null || newPassword.length() < 8
                || !newPassword.matches(".*[A-Z].*")
                || !newPassword.matches(".*\\d.*")
                || !newPassword.matches(".*[^A-Za-z0-9].*")) {
            return "Password must be at least 8 characters and include an uppercase letter, a number, and a special character.";
        }
        if (!AuthService.verifyPassword(oldPassword, currentHash)) {
            return "Password change failed: Current password is incorrect.";
        }
        if (AuthService.verifyPassword(newPassword, currentHash)) {
            return "Password change failed: New password cannot be the same as your current password.";
        }
        return null;
    }

    public String getRegistrationFailureReason(String name, String email, String phone, String password) {
        if (name == null || name.isBlank()) {
            return "Name cannot be empty.";
        }
        if (phone == null || phone.isBlank()) {
            return "Phone number cannot be empty.";
        }
        if (!phone.matches("\\d{10}")) {
            return "Phone number must be a valid 10-digit number.";
        }
        if (inMemoryUserRepository.findByPhone(phone.trim()) != null) {
            return "An account with phone number " + phone + " already exists. Please log in or use a different phone number.";
        }
        if (email == null || email.isBlank() || !email.matches("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$")) {
            return "Invalid email format. Please provide a valid email address (e.g. name@example.com).";
        }
        if (inMemoryUserRepository.findByEmail(email) != null) {
            return "An account with email address " + email + " already exists. Please log in or use a different email address.";
        }
        if (password == null || password.isBlank()) {
            return "Password cannot be blank.";
        }
        if (isValidMemberPassword(password)) {
            return "Password must be at least 8 characters and include an uppercase letter, a number, and a special character.";
        }
        return null;
    }

    private boolean isValidMemberPassword(String password) {
        return password == null
                || !password.matches("^(?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#$%^&*]).{8,}$");
    }

    public String validateAge(String ageStr) {
        if (ageStr == null || ageStr.isBlank()) {
            return "Enter a valid age.";
        }
        try {
            int age = Integer.parseInt(ageStr.trim());
            return validateAge(age);
        } catch (NumberFormatException e) {
            return "Enter a valid age.";
        }
    }
}
