package ui;

public class GoHomeException extends RuntimeException {
    public GoHomeException() {
        super("Go to Home");
    }
}
