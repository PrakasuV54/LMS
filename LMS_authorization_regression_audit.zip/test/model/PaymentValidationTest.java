package model;

import enums.PaymentMethod;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertThrows;

class PaymentValidationTest {
    @Test
    void rejectsNonFinitePaymentAmounts() {
        assertThrows(IllegalArgumentException.class,
                () -> new Payment(1, 1, "9998887771", Double.NaN, PaymentMethod.UPI));
        assertThrows(IllegalArgumentException.class,
                () -> new Payment(2, 1, "9998887771", Double.POSITIVE_INFINITY, PaymentMethod.UPI));
        assertThrows(IllegalArgumentException.class,
                () -> Payment.forMembership(3, 1, "9998887771", Double.NEGATIVE_INFINITY, PaymentMethod.UPI));
    }

    @Test
    void acceptsFinitePositivePaymentAmount() {
        assertDoesNotThrow(() -> new Payment(4, 1, "9998887771", 100.0, PaymentMethod.UPI));
    }
}
