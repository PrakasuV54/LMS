package ui;

import enums.TransactionStatus;
import enums.UserRole;
import enums.UserStatus;
import model.Book;
import model.Transaction;
import model.User;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.PrintStream;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Scanner;

import static org.junit.jupiter.api.Assertions.*;

public class MemberUiFixTest {

    private final InputStream originalIn = System.in;
    private final PrintStream originalOut = System.out;
    private ByteArrayOutputStream outContent;

    @BeforeEach
    void setUp() {
        outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));
        Main.currentUser = null;
    }

    @AfterEach
    void tearDown() {
        System.setIn(originalIn);
        System.setOut(originalOut);
        Main.currentUser = null;
    }

    private void provideInput(String data) {
        System.setIn(new ByteArrayInputStream(data.getBytes()));
        Main.sc = new Scanner(System.in);
    }

    @Test
    void testSuccessfulPhoneUpdate() {
        String oldPhone = "9876543210";
        String newPhone = "9876543211";

        User member = new User("Phone Test User", "phonetest@example.com", oldPhone, "Password@123", UserRole.MEMBER, UserStatus.ACTIVE);
        Main.userRepository.save(member);
        Main.currentUser = member;

        provideInput("3\n" + newPhone + "\n5\n");
        Member.handleUpdateProfile();

        String output = outContent.toString();
        assertTrue(output.contains("Phone updated successfully"), "Expected success message on valid phone update");
        assertNotNull(Main.userRepository.findByPhone(newPhone), "User should be found by new phone");
        assertEquals(newPhone, member.getPhone(), "Member phone should be updated to new phone");
    }

    @Test
    void testFailedPhoneUpdateFormatValidation() {
        String phone = "9876543220";
        User member = new User("Format Test User", "formattest@example.com", phone, "Password@123", UserRole.MEMBER, UserStatus.ACTIVE);
        Main.userRepository.save(member);
        Main.currentUser = member;

        provideInput("3\n12345\n5\n");
        Member.handleUpdateProfile();

        String output = outContent.toString();
        assertTrue(output.contains("Enter a valid 10-digit phone number"), "Expected format failure message");
        assertFalse(output.contains("Phone updated successfully"), "Should not display success on invalid format");
        assertEquals(phone, member.getPhone(), "Phone should not have changed");
    }

    @Test
    void testFailedPhoneUpdateIdenticalPhone() {
        String phone = "9876543230";
        User member = new User("Identical Test User", "identicaltest@example.com", phone, "Password@123", UserRole.MEMBER, UserStatus.ACTIVE);
        Main.userRepository.save(member);
        Main.currentUser = member;

        provideInput("3\n" + phone + "\n5\n");
        Member.handleUpdateProfile();

        String output = outContent.toString();
        assertTrue(output.contains("Unable to update phone: New phone number is identical to your current phone number."));
        assertFalse(output.contains("Phone updated successfully"), "Should not display success on identical phone");
    }

    @Test
    void testFailedPhoneUpdateDuplicatePhone() {
        String phone1 = "9876543241";
        String phone2 = "9876543242";

        User member1 = new User("User 1", "u1@example.com", phone1, "Password@123", UserRole.MEMBER, UserStatus.ACTIVE);
        User member2 = new User("User 2", "u2@example.com", phone2, "Password@123", UserRole.MEMBER, UserStatus.ACTIVE);
        Main.userRepository.save(member1);
        Main.userRepository.save(member2);
        Main.currentUser = member1;

        provideInput("3\n" + phone2 + "\n5\n");
        Member.handleUpdateProfile();

        String output = outContent.toString();
        assertTrue(output.contains("already registered to another account"));
        assertFalse(output.contains("Phone updated successfully"), "Should not display success on duplicate phone");
    }

    @Test
    void testSuccessfulCancelRequest() {
        String phone = "9876543250";
        String isbn = "978-0134685991";

        User member = new User("Cancel Member", "cancelmem@example.com", phone, "Password@123", UserRole.MEMBER, UserStatus.ACTIVE);
        Main.userRepository.save(member);
        Main.currentUser = member;

        Book book = new Book("978-0134685991", "Effective Java", "Addison-Wesley", 2018, "A programming book");
        Main.bookRepository.save(book);

        Transaction transaction = new Transaction(9999, phone, book.getBookId());
        Main.transactionRepository.save(transaction);

        provideInput(isbn + "\n");
        Member.handleCancelRequest();

        String output = outContent.toString();
        assertTrue(output.contains("Request cancelled successfully"), "Should show success message on cancellation");
        assertFalse(output.contains("Cancellation failed:"), "Should not show failure message on successful cancellation");
        assertEquals(TransactionStatus.CANCELLED, transaction.getStatus());
    }

    @Test
    void testFailedCancelRequestDoesNotPrintSuccess() {
        String phone = "9876543260";
        String nonExistentIsbn = "999-9999999999";

        User member = new User("Fail Cancel Member", "failcancel@example.com", phone, "Password@123", UserRole.MEMBER, UserStatus.ACTIVE);
        Main.userRepository.save(member);
        Main.currentUser = member;

        provideInput(nonExistentIsbn + "\n");
        Member.handleCancelRequest();

        String output = outContent.toString();
        assertTrue(output.contains("Cancellation failed:"), "Should show cancellation failure message");
        assertFalse(output.contains("Request cancelled successfully"), "Should NOT print success message on failure");
    }
}
