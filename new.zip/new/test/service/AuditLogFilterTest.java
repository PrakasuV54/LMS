package service;

import enums.UserRole;
import enums.UserStatus;
import model.Audit;
import model.User;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import repository.AuditLogRepository;
import repository.DataStore;
import repository.InMemoryAuditLogRepository;
import repository.InMemoryUserRepository;
import repository.UserRepository;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.YearMonth;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class AuditLogFilterTest {

    private DataStore dataStore;
    private AuditLogRepository auditLogRepository;
    private UserRepository userRepository;
    private AuditService auditService;

    @BeforeEach
    void setUp() {
        dataStore = new DataStore();
        auditLogRepository = new InMemoryAuditLogRepository(dataStore);
        userRepository = new InMemoryUserRepository(dataStore);
        auditService = new AuditService(auditLogRepository, userRepository);

        User member = new User("Member User", "member@test.com", "9000000001", "hash", UserRole.MEMBER, UserStatus.ACTIVE);
        User librarian = new User("Librarian User", "librarian@test.com", "9000000002", "hash", UserRole.LIBRARIAN, UserStatus.ACTIVE);
        User admin = new User("Admin User", "admin@test.com", "9000000003", "hash", UserRole.ADMIN, UserStatus.ACTIVE);
        userRepository.save(member);
        userRepository.save(librarian);
        userRepository.save(admin);

        Audit a1 = new Audit(1, "9000000001", "BOOK_REQUESTED", "BOOK", "101", "Request queued", LocalDateTime.of(2025, 5, 10, 10, 0));
        Audit a2 = new Audit(2, "9000000002", "BOOK_ISSUED", "BOOK", "101", "Issued book", LocalDateTime.of(2026, 5, 15, 11, 0));
        Audit a3 = new Audit(3, "9000000001", "FINE_PAID", "FINE", "201", "Paid fine", LocalDateTime.of(2026, 5, 20, 12, 0));
        Audit a4 = new Audit(4, "9000000003", "POLICY_UPDATED", "POLICY", "1", "Updated limit", LocalDateTime.of(2026, 8, 1, 9, 30));
        Audit a5 = new Audit(5, "9000000002", "BOOK_ADDED", "BOOK", "102", "Added new title", LocalDateTime.of(2026, 12, 31, 23, 59));

        auditLogRepository.save(a1);
        auditLogRepository.save(a2);
        auditLogRepository.save(a3);
        auditLogRepository.save(a4);
        auditLogRepository.save(a5);
    }

    private List<Audit> filterLogs(Integer year, Integer month, UserRole role) {
        LocalDateTime start = null;
        LocalDateTime end = null;
        if (year != null) {
            if (month != null) {
                start = LocalDate.of(year, month, 1).atStartOfDay();
                end = YearMonth.of(year, month).plusMonths(1).atDay(1).atStartOfDay();
            } else {
                start = LocalDate.of(year, 1, 1).atStartOfDay();
                end = LocalDate.of(year + 1, 1, 1).atStartOfDay();
            }
        }
        return auditService.findFiltered(start, end, role);
    }

    @Test
    void testFilterAllUnfiltered() {
        List<Audit> all = filterLogs(null, null, null);
        assertEquals(5, all.size());
    }

    @Test
    void testFilterByRoleOnly() {
        List<Audit> memberLogs = filterLogs(null, null, UserRole.MEMBER);
        assertEquals(2, memberLogs.size());
        for (Audit a : memberLogs) {
            assertEquals("9000000001", a.getUserPhone());
        }

        List<Audit> adminLogs = filterLogs(null, null, UserRole.ADMIN);
        assertEquals(1, adminLogs.size());
        assertEquals("9000000003", adminLogs.get(0).getUserPhone());
    }

    @Test
    void testFilterByYearOnly() {
        List<Audit> logs2025 = filterLogs(2025, null, null);
        assertEquals(1, logs2025.size());
        assertEquals(1, logs2025.get(0).getAuditId());

        List<Audit> logs2026 = filterLogs(2026, null, null);
        assertEquals(4, logs2026.size());
    }

    @Test
    void testFilterByYearAndMonth() {
        List<Audit> may2026 = filterLogs(2026, 5, null);
        assertEquals(2, may2026.size());
        for (Audit a : may2026) {
            assertEquals(2026, a.getTimestamp().getYear());
            assertEquals(5, a.getTimestamp().getMonthValue());
        }

        List<Audit> may2025 = filterLogs(2025, 5, null);
        assertEquals(1, may2025.size());
        assertEquals(1, may2025.get(0).getAuditId());

        List<Audit> august2026 = filterLogs(2026, 8, null);
        assertEquals(1, august2026.size());
        assertEquals(4, august2026.get(0).getAuditId());

        List<Audit> december2026 = filterLogs(2026, 12, null);
        assertEquals(1, december2026.size());
        assertEquals(5, december2026.get(0).getAuditId());
    }

    @Test
    void testFilterByYearAndRole() {
        List<Audit> logs = filterLogs(2026, null, UserRole.LIBRARIAN);
        assertEquals(2, logs.size());
        for (Audit a : logs) {
            assertEquals("9000000002", a.getUserPhone());
            assertEquals(2026, a.getTimestamp().getYear());
        }
    }

    @Test
    void testFilterByYearMonthAndRole() {
        List<Audit> logs = filterLogs(2026, 5, UserRole.MEMBER);
        assertEquals(1, logs.size());
        assertEquals(3, logs.get(0).getAuditId());
    }

    @Test
    void testYearChangeResetsMonth() {
        Integer selectedYear = 2026;
        Integer selectedMonth = 5;
        assertEquals(2, filterLogs(selectedYear, selectedMonth, null).size());

        selectedYear = 2025;
        selectedMonth = null;
        assertEquals(1, filterLogs(selectedYear, selectedMonth, null).size());
    }

    @Test
    void testClearFiltersReturnsAll() {
        Integer selectedYear = 2026;
        Integer selectedMonth = 5;
        UserRole selectedRole = UserRole.MEMBER;
        assertEquals(1, filterLogs(selectedYear, selectedMonth, selectedRole).size());

        selectedYear = null;
        selectedMonth = null;
        selectedRole = null;
        assertEquals(5, filterLogs(selectedYear, selectedMonth, selectedRole).size());
    }
}
