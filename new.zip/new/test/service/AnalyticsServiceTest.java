package service;

import enums.*;
import model.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import repository.*;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.time.LocalDate;
import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.*;

public class AnalyticsServiceTest {

    private DataStore dataStore;
    private UserRepository userRepository;
    private BookRepository bookRepository;
    private BookCopyRepository bookCopyRepository;
    private TransactionRepository transactionRepository;
    private MembershipRepository membershipRepository;
    private MembershipPlanRepository membershipPlanRepository;
    private FineRepository fineRepository;
    private PaymentRepository paymentRepository;
    private AnalyticsService analyticsService;

    @BeforeEach
    void setUp() {
        dataStore = new DataStore();
        userRepository = new InMemoryUserRepository(dataStore);
        bookRepository = new InMemoryBookRepository(dataStore);
        bookCopyRepository = new InMemoryBookCopyRepository(dataStore);
        transactionRepository = new InMemoryTransactionRepository(dataStore);
        membershipRepository = new InMemoryMembershipRepository(dataStore);
        membershipPlanRepository = new InMemoryMembershipPlanRepository(dataStore);
        fineRepository = new InMemoryFineRepository(dataStore);
        paymentRepository = new InMemoryPaymentRepository(dataStore);

        analyticsService = new AnalyticsService(
                bookRepository,
                transactionRepository,
                userRepository,
                paymentRepository,
                bookCopyRepository,
                membershipRepository,
                fineRepository,
                membershipPlanRepository
        );
    }

    @Test
    void testZeroActivityYear() {
        AnalyticsDashboard dashboard = analyticsService.getDashboardForYear(2020);

        assertEquals(2020, dashboard.getYear());
        assertEquals(0, dashboard.getTotalRegistrationsInYear());
        assertEquals(12, dashboard.getMonthlyRegistrations().length);
        for (int i = 0; i < 12; i++) {
            assertEquals(0, dashboard.getMonthlyRegistrations()[i]);
            assertEquals(0, dashboard.getMonthlyBorrowings()[i]);
        }
    }

    @Test
    void testUserRegistrationAnalytics() {
        User u1 = new User("Alice", "alice@test.com", "9000000001", "hash", UserRole.MEMBER, UserStatus.ACTIVE, 22, "FEMALE");
        User u2 = new User("Bob", "bob@test.com", "9000000002", "hash", UserRole.MEMBER, UserStatus.ACTIVE, 35, "MALE");
        userRepository.save(u1);
        userRepository.save(u2);

        int currentYear = LocalDateTime.now().getYear();
        int currentMonth = LocalDateTime.now().getMonthValue();

        AnalyticsDashboard dashboard = analyticsService.getDashboardForYear(currentYear);
        assertEquals(2, dashboard.getTotalRegistrationsInYear());
        assertEquals(2, dashboard.getTotalUsersInSystem());
        assertEquals(2, dashboard.getMonthlyRegistrations()[currentMonth - 1]);

        int monthlySum = 0;
        for (int count : dashboard.getMonthlyRegistrations()) {
            monthlySum += count;
        }
        assertEquals(dashboard.getTotalRegistrationsInYear(), monthlySum);

        assertEquals(1, dashboard.getRegistrationsByAgeGroup().get("18-25"));
        assertEquals(1, dashboard.getRegistrationsByAgeGroup().get("26-35"));
        assertEquals(1, dashboard.getRegistrationsByGender().get("FEMALE"));
        assertEquals(1, dashboard.getRegistrationsByGender().get("MALE"));
    }

    @Test
    void testBookBorrowingOnlyCountsIssued() {
        Book book1 = new Book("978-1111111111", "Book One", "Pub A", 2022, "Desc A");
        Book book2 = new Book("978-2222222222", "Book Two", "Pub B", 2023, "Desc B");
        bookRepository.save(book1);
        bookRepository.save(book2);

        LocalDateTime now = LocalDateTime.now();
        int year = now.getYear();
        int month = now.getMonthValue();

        Transaction tReq = new Transaction(1, "9000000001", book1.getBookId());
        transactionRepository.save(tReq);

        Transaction tRes = new Transaction(2, "9000000002", book1.getBookId(), 10,
                TransactionStatus.RESERVED, now.minusDays(5), null, null, null);
        transactionRepository.save(tRes);

        Transaction tIss1 = new Transaction(3, "9000000001", book1.getBookId(), 11,
                TransactionStatus.ISSUED, now.minusDays(5), now.minusDays(4),
                LocalDate.now().plusDays(10), null);
        transactionRepository.save(tIss1);

        Transaction tIss2 = new Transaction(4, "9000000002", book2.getBookId(), 12,
                TransactionStatus.RETURNED, now.minusDays(10), now.minusDays(9),
                LocalDate.now().plusDays(5), now.minusDays(1));
        transactionRepository.save(tIss2);

        AnalyticsDashboard dashboard = analyticsService.getDashboardForYear(year);
        assertEquals(2, dashboard.getTotalBorrowingsInYear());
        assertEquals(2, dashboard.getMonthlyBorrowings()[month - 1]);

        int monthlySum = 0;
        for (int b : dashboard.getMonthlyBorrowings()) {
            monthlySum += b;
        }
        assertEquals(dashboard.getTotalBorrowingsInYear(), monthlySum);

        assertEquals(2, dashboard.getBorrowedBookRankings().size());
        assertEquals(1, dashboard.getBorrowedBookRankings().get(0).getCount());
        assertEquals(1, dashboard.getBorrowedBookRankings().get(1).getCount());
    }

    @Test
    void testDisplayMethodProducesOnlyRequestedSections() {
        AnalyticsDashboard dashboard = analyticsService.getDashboardForYear(2026);

        ByteArrayOutputStream out = new ByteArrayOutputStream();
        PrintStream originalOut = System.out;
        System.setOut(new PrintStream(out));
        try {
            dashboard.display();
        } finally {
            System.setOut(originalOut);
        }

        String output = out.toString();
        assertTrue(output.contains("1. USER REGISTRATION ANALYTICS"));
        assertTrue(output.contains("2. BOOK BORROWING ANALYTICS"));
        assertFalse(output.contains("3. MEMBERSHIP ANALYTICS"));
        assertFalse(output.contains("4. PAYMENT ANALYTICS"));
        assertFalse(output.contains("5. FINE ANALYTICS"));
        assertFalse(output.contains("6. BOOK INVENTORY ANALYTICS"));
        assertFalse(output.contains("7. BOOK REQUEST AND LOAN ANALYTICS"));

        for (String month : AnalyticsDashboard.MONTH_NAMES) {
            assertTrue(output.contains(month), "Output should contain " + month);
        }
        assertTrue(output.contains("Total"), "Output should contain Total");
    }

    @Test
    void testDashboardWithSyntheticData() {
        AuthorRepository authorRepository = new InMemoryAuthorRepository(dataStore);
        GenreRepository genreRepository = new InMemoryGenreRepository(dataStore);
        CategoryRepository categoryRepository = new InMemoryCategoryRepository(dataStore);
        AuditLogRepository auditLogRepository = new InMemoryAuditLogRepository(dataStore);
        AuditService auditService = new AuditService(auditLogRepository, userRepository);
        BookService bookService = new BookService(bookRepository, bookCopyRepository, transactionRepository,
                auditService, authorRepository, genreRepository);

        SyntheticData syntheticData = new SyntheticData(
                userRepository, membershipPlanRepository, bookService,
                authorRepository, genreRepository, membershipRepository,
                transactionRepository, fineRepository, paymentRepository,
                auditLogRepository, categoryRepository, bookCopyRepository
        );
        syntheticData.syntheticData();

        int currentYear = LocalDate.now().getYear();
        AnalyticsDashboard dashboard = analyticsService.getDashboardForYear(currentYear);

        assertTrue(dashboard.getTotalUsersInSystem() > 0);
        assertTrue(dashboard.getTotalRegistrationsInYear() > 0);
        assertTrue(dashboard.getTotalBorrowingsInYear() > 0);

        int regSum = 0;
        for (int c : dashboard.getMonthlyRegistrations()) regSum += c;
        assertEquals(dashboard.getTotalRegistrationsInYear(), regSum);

        int borrowSum = 0;
        for (int c : dashboard.getMonthlyBorrowings()) borrowSum += c;
        assertEquals(dashboard.getTotalBorrowingsInYear(), borrowSum);

        assertDoesNotThrow(dashboard::display);
    }
}
