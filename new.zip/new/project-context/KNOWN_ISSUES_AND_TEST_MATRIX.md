# Known Issues Register & Prioritized Test Matrix

This document records all confirmed defects, technical debt, security and architectural limitations, as well as the test verification status and proposed regression test matrix for the Library Management System (`d:/Library_v3`).

---

## Part 1: Prioritized Issue Register

| ID | Severity | Category | Description | Evidence | Affected Workflow | Possible Impact | Suggested Verification |
|---|---|---|---|---|---|---|---|
| **ISS-01** | High | Thread Safety / Concurrency | Non-thread-safe repository maps accessed concurrently by background daemon and UI threads. | `DataStore.java` uses unsynchronized `HashMap` and `ArrayList` for `transactions`, `books`, `fines`. `OverdueFineSchedulerService.java:65` schedules a background daemon executing every 6 hours modifying fines and transactions concurrently with user actions. | Overdue fine calculation, book returns, book issues. | `ConcurrentModificationException`, corrupted collection state, or race conditions during fine creation. | Run a multithreaded test where `OverdueFineSchedulerService.processOverdueTransactions()` runs concurrently with 50 book return and issue operations. |
| **ISS-02** | High | Exception Handling | Swallowed exceptions with hardcoded stdout strings in background scheduler. | `OverdueFineSchedulerService.java:164-168`: `catch (Exception notifEx) { System.out.println("Notification exception"); } catch (Exception txEx) { System.out.println("Transaction exception"); }`. | Overdue fine calculation and automated notifications. | Exceptions during background batch processing are silenced without stack traces, diagnostic context, or alerting. | Inject a mock failing transaction or null pointer and verify background batch log captures full context. |
| **ISS-03** | Medium | Data Consistency | Dangling foreign keys in historical transaction records when a book is deleted. | `BookService.java:132-133` deletes book copies and book title from repositories, but does not update or mark historical `Transaction` records (which retain `bookId` and `bookCopyId`). | View Borrowing History, Analytics. | Historical transactions reference non-existent book titles (`bookRepository.findById(id) == null`). UI displays fallback string. | Delete a book with past returned loans and execute Member "View Borrowing History" and Admin "Analytics Dashboard". |
| **ISS-04** | Medium | Architectural / Persistence | Total data volatility due to exclusively in-memory storage. | All repositories implement in-memory `DataStore` maps without database or file persistence. | Entire application lifecycle. | Complete data loss occurs whenever the Java console process exits or restarts. | Restart application and observe all added members, books, and transactions vanish. |
| **ISS-05** | Medium | Missing Feature | Book update and individual copy management features are absent from the codebase. | `BookService.java`, `Librarian.java`, and `Admin.java` contain no methods or menu choices to update book metadata (title, publisher, year) or increment/decrement copy counts. | Catalogue Management. | Librarians cannot correct typographical errors or add physical copies without deleting and recreating titles. | Inspect `Librarian.java` menu and `BookService.java` method list. |
| **ISS-06** | Low | Security | Hardcoded default credentials in initial seed data. | `SyntheticData.java:57, 64, 69, 73` creates default admin and librarian accounts with hardcoded passwords (`admin123`, `lib123`) using BCrypt. | Staff Authentication. | In a multi-user environment, default passwords present an unauthorized access risk if not changed immediately. | Verify staff login prompts succeed with `admin123` on startup. |
| **ISS-07** | Low | External Integration | Mock payment gateway always simulates successful payment. | `Razorpay.java:14-25` generates mock reference strings and prints to console; does not integrate with payment provider APIs. | Membership purchase, Fine settlement. | No real financial verification occurs; invalid payments cannot be simulated without mocking. | Unit test verifying payment gateway failure path. |
| **ISS-08** | High | Test Coverage | Zero test classes in Maven test source directory (`src/test`). | `mvn test` execution results: `[INFO] No sources to compile`, `[INFO] No tests to run`. | Entire codebase. | Future changes carry high risk of undetected regressions unless automated tests are introduced to `src/test`. | Inspect Maven build output of `mvn test`. |

---

## Part 2: Testing & Verification Status

### 1. Actual Build & Test Commands Executed

| Command Executed | Exit Code | Build Result | Source Files Compiled | Verified Runtime Behavior |
|---|---|---|---|---|
| `mvn compile` | `0` | **BUILD SUCCESS** | 73 source files compiled with javac [debug release 17] | Clean compilation without errors or warnings. |
| `mvn test` | `0` | **BUILD SUCCESS** | 0 test files found (`No tests to run`) | Confirmed that no automated unit/integration tests currently reside in `src/test/java`. |
| `git status` | `1` | **FATAL** | N/A | Output: `fatal: not a git repository (or any of the parent directories): .git`. |

### 2. Scratch Verification Executed (in IDE Artifact Scratch Directory)

During the prior refactoring phase, two independent test harnesses were compiled and executed against JDK 17 using the IDE brain scratch directory (`C:\Users\Srimathi\.gemini\antigravity-ide\brain\c39639c9-a4d2-4e11-9e2f-f9a63f1a3858\scratch\`):

1. **`VerificationTest.java` (10 Unit Checks)**:
   - Check 1: Add book successfully with 2 copies. (PASSED)
   - Check 2: Reject duplicate ISBN. (PASSED)
   - Check 3: Reject empty title. (PASSED)
   - Check 4: Reject zero copies. (PASSED)
   - Check 5: Reject unauthorized user adding book. (PASSED)
   - Check 6: Reject removal of book with issued copies. (PASSED)
   - Check 7: Reject removal of book with reserved copies. (PASSED)
   - Check 8: Remove book successfully when copies available. (PASSED)
   - Check 9: Reject removal of non-existent ISBN. (PASSED)
   - Check 10: Reject unauthorized user removing book. (PASSED)

2. **`UiInteractionTest.java` (UI Integration Check)**:
   - Simulated interactive console inputs through `Librarian.handleAddBook` and `Librarian.handleRemoveBook`.
   - Verified that success messages and failure messages were printed exactly once without unhandled exceptions or duplicate prompts. (PASSED)

---

## Part 3: Prioritized Regression Test Matrix

This matrix specifies the automated test suite recommended for future implementation under `src/test/java`:

| Priority | Test Name / Suite | Scope & Target Class | Test Scenarios & Invariants Verified |
|---|---|---|---|
| **P0** | `BookServiceAddRemoveTest` | `BookService` | 1. Successful book addition and verified copy creation count.<br>2. Rejection of duplicate ISBN.<br>3. Rejection of empty required fields (title, ISBN, copies < 1).<br>4. Rollback of book and copies when copy persistence fails.<br>5. Authorization failure for Member role attempting inventory changes.<br>6. Rejection of book removal when active loans or reservations exist.<br>7. Clean deletion of available copies and book title on removal. |
| **P0** | `LoanLifecycleTest` | `BookTransactionService` | 1. Request book when copies available -> auto-reserves copy.<br>2. Request book when no copies available -> queues request.<br>3. Mark ready for pickup -> status transitions.<br>4. Issue book -> loan active, copy marked `ISSUED`, due date set correctly.<br>5. Return book on time -> copy returned, copy auto-allocated to next in queue.<br>6. Cancel request -> releases copy reservation and allocates to next in queue. |
| **P0** | `OverdueFineCalculationTest` | `FineService`, `OverdueFineSchedulerService` | 1. Return book overdue -> calculates exact overdue days * fine rate from user's plan.<br>2. Verify no duplicate overdue fine records created for same loan on subsequent days.<br>3. Settle fine -> status transitions `UNPAID -> PARTIALLY_PAID -> PAID`. |
| **P1** | `PolicyEnforcementTest` | `PolicyService` | 1. Borrowing limit enforcement (e.g. max 3 books on Standard Plan, 6 on Premium).<br>2. Block loan issue when member has unpaid fines or expired membership.<br>3. Family plan quota calculation across all linked family accounts. |
| **P1** | `FamilyAccountTest` | `FamilyAccountService` | 1. Create family group and generate 6-digit BCrypt code.<br>2. Request to join and approve with valid code.<br>3. Reject join when code is incorrect.<br>4. Enforce maximum cap of 4 family members.<br>5. Reject join if user already holds active individual membership. |
| **P2** | `AuthAndRoleHierarchyTest` | `AuthService`, `UserService` | 1. Password validation (min 8 chars, uppercase, digit, special character).<br>2. BCrypt hashing and verification.<br>3. Role hierarchy: Admin can access librarian and member operations; Librarian cannot access admin operations. |
| **P2** | `ConcurrencyStressTest` | `DataStore`, `OverdueFineSchedulerService` | 1. Concurrent loan returns, issues, and background overdue scans across 20 threads. |
