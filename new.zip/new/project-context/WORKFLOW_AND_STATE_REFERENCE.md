# Workflow & State Machine Reference Manual

This document provides complete, source-verified specifications for all business workflows (Workflows A through V) and lifecycle state machines implemented in the Library Management System (`d:/Library_v3`).

---

## Part 1: State Machines & Invariant Relationships

### 1. Transaction Lifecycle State Machine

The `Transaction` entity tracks the lifecycle of a borrowing interaction.

```mermaid
stateDiagram-v2
    [*] --> REQUESTED: Member requests book (no available copies)
    [*] --> RESERVED: Member requests book (copy auto-allocated)
    REQUESTED --> RESERVED: autoReserveAvailableCopies() / copy returned or freed
    REQUESTED --> CANCELLED: cancelRequest()
    RESERVED --> READY_FOR_PICKUP: markReadyForPickup() by staff
    RESERVED --> CANCELLED: cancelRequest() (releases copy reservation)
    READY_FOR_PICKUP --> ISSUED: issueBook() by staff
    READY_FOR_PICKUP --> CANCELLED: cancelRequest() (releases copy reservation)
    ISSUED --> RETURNED: returnBook() (copy freed; overdue fine created if late)
    ISSUED --> LOST: markCopyLost() (copy marked LOST; lost fine created)
    ISSUED --> DAMAGED: markCopyDamaged() (copy marked DAMAGED; damage fine created)
    RETURNED --> [*]
    LOST --> [*]
    DAMAGED --> [*]
    CANCELLED --> [*]
```

#### Detailed Transaction State Transitions

| Current Status | Target Status | Triggering Method | Preconditions | Side Effects on Entity & System |
|---|---|---|---|---|
| *Initial* | `REQUESTED` | `BookTransactionService.createBookRequest` | Member has active membership, under book limit, no active loan/request for same book, no copies available. | Transaction saved with `bookCopyId = 0`. Notification queued: "Your request is queued." Audit logged: `BOOK_REQUESTED`. |
| *Initial* or `REQUESTED` | `RESERVED` | `BookTransactionService.autoReserveAvailableCopies` | Physical copy with `AVAILABLE` status exists. Request has highest queue priority. | Copy status transitions `AVAILABLE -> RESERVED`. Transaction updated with `reserveDate = now()`, `bookCopyId = copy.id`, `status = RESERVED`. Notification: "Your book is reserved for pickup." |
| `RESERVED` | `READY_FOR_PICKUP` | `BookTransactionService.markReadyForPickup` | Caller is active Librarian/Admin. Copy status is `RESERVED` and matches transaction `bookId`. | Transaction `readyDate = now()`, `status = READY_FOR_PICKUP`. Notification sent. Audit logged: `BOOK_READY_FOR_PICKUP`. |
| `READY_FOR_PICKUP` | `ISSUED` | `BookTransactionService.issueBook` | Caller is active Librarian/Admin. Member remains eligible under borrowing policies. Copy is `RESERVED`. | Copy status `RESERVED -> ISSUED`. Transaction `issueDate = now()`, `dueDate = now() + loanPeriodDays`, `status = ISSUED`. Audit logged: `BOOK_ISSUED`. Notification sent. |
| `ISSUED` | `RETURNED` | `BookTransactionService.returnBook` | Caller is active Librarian/Admin. Copy is `ISSUED`. | If `now > dueDate`, overdue fine calculated and saved. Copy `ISSUED -> AVAILABLE`. Transaction `returnDate = now()`, `status = RETURNED`. Copy freed triggers `autoReserveAvailableCopies(bookId)`. Notification sent. |
| `ISSUED` | `LOST` | `BookTransactionService.markCopyLost` | Caller is active Librarian/Admin. Copy is `ISSUED`. | If overdue, overdue fine created. Copy `ISSUED -> LOST`. Transaction `returnDate = now()`, `status = LOST`. Lost fine created. Audit logged: `BOOK_COPY_MARKED_LOST`. |
| `ISSUED` | `DAMAGED` | `BookTransactionService.markCopyDamaged` | Caller is active Librarian/Admin. Copy is `ISSUED`. | Overdue fine settled/created if late. Copy `ISSUED -> DAMAGED`. Transaction `returnDate = now()`, `status = DAMAGED`. Damaged fine created. Audit logged: `BOOK_COPY_MARKED_DAMAGED`. |
| `REQUESTED`, `RESERVED`, or `READY_FOR_PICKUP` | `CANCELLED` | `BookTransactionService.cancelRequest` | Caller is member or staff acting on member's behalf. Loan not yet issued. | Transaction `status = CANCELLED`. If `bookCopyId > 0`, copy reservation released (`RESERVED -> AVAILABLE`). Audit logged: `BOOK_REQUEST_CANCELLED`. `autoReserveAvailableCopies(bookId)` triggered. |

---

### 2. Physical Book Copy State Machine

Tracks physical assets in `BookCopy` (`enums.BookCopyStatus`).

```mermaid
stateDiagram-v2
    [*] --> AVAILABLE: Book creation (addBookFromDetails)
    AVAILABLE --> RESERVED: autoReserveAvailableCopies()
    RESERVED --> AVAILABLE: cancelRequest() or staff unreserves
    RESERVED --> ISSUED: issueBook()
    ISSUED --> AVAILABLE: returnBook()
    ISSUED --> LOST: markCopyLost()
    ISSUED --> DAMAGED: markCopyDamaged()
    AVAILABLE --> LOST: markCopyLostUnidentified()
    AVAILABLE --> DAMAGED: markCopyDamagedUnidentified()
    LOST --> [*]
    DAMAGED --> [*]
```

#### Invariant Relationships between Transaction & Book Copy

1. **One-to-One Active Coupling**: A physical copy in status `RESERVED` or `ISSUED` must be bound to exactly one active `Transaction` whose `bookCopyId` matches that copy's ID.
2. **Book Title Integrity**: A transaction's `bookId` must match the copy's `bookId`. Verified in `issueBook`, `returnBook`, `markReadyForPickup`, and `updateCopyCondition`.
3. **No Phantom Availability**: When a copy transitions to `AVAILABLE` (on return or cancellation), `autoReserveAvailableCopies(bookId)` immediately attempts to allocate it to the oldest eligible `REQUESTED` transaction before the method returns.

---

### 3. Membership Lifecycle State Machine

```mermaid
stateDiagram-v2
    [*] --> ACTIVE: Purchase Plan (payment success)
    ACTIVE --> ACTIVE: Renew Membership (extends endDate by plan duration)
    ACTIVE --> SUSPENDED: Staff manual suspension / Excessive unpaid fines
    SUSPENDED --> ACTIVE: Staff reactivation
    ACTIVE --> EXPIRED: System checks today > endDate
    ACTIVE --> CANCELLED: Staff / Member manual cancellation
    EXPIRED --> ACTIVE: Renew or Purchase new plan
```

- **Invariants**:
  - `Membership.findActiveByUserPhone` returns a membership only if `status == MembershipStatus.ACTIVE` and `today <= endDate`.
  - Family membership: The primary member purchases a "Family" plan. Joinees share the primary member's validity and combined borrowing quota (e.g. 12 or 15 books).

---

### 4. Fine Lifecycle State Machine

```mermaid
stateDiagram-v2
    [*] --> UNPAID: Overdue / Lost / Damaged fine created
    UNPAID --> PARTIALLY_PAID: Partial payment processed
    PARTIALLY_PAID --> PAID: Remaining balance settled
    UNPAID --> PAID: Full payment processed
    UNPAID --> WAIVED: Staff waives fine
    PARTIALLY_PAID --> WAIVED: Staff waives balance
```

- **Invariants**:
  - `Fine.amount` represents the original assessed penalty.
  - `Fine.paidAmount` accumulates payments. `remainingAmount = amount - paidAmount`.
  - Overdue scheduler creates at most one overdue fine per transaction; subsequent days update the fine amount rather than creating duplicates.

---

### 5. Payment State Machine

```mermaid
stateDiagram-v2
    [*] --> PENDING: Payment record created
    PENDING --> SUCCESS: PaymentGateway returns success
    PENDING --> FAILED: PaymentGateway fails / throws
    SUCCESS --> REFUNDED: Staff issues refund (fines only; memberships non-refundable)
```

- **Invariants**:
  - `Payment.isMembershipPayment() == true` cannot be refunded. `PaymentService.refundPayment()` throws `IllegalStateException("Membership payments cannot be refunded.")`.

---

### 6. Family Join Request State Machine

```mermaid
stateDiagram-v2
    [*] --> PENDING: Joinee submits join request with primary member phone
    PENDING --> APPROVED: Primary member or staff approves request (with 6-digit BCrypt code)
    PENDING --> REJECTED: Primary member or staff rejects request
```

- **Invariants**:
  - Max 4 members per family account (1 primary + 3 joinees).
  - Joinees cannot have an active standalone membership or be linked to another family group.

---

### 7. User Account State Machine

```mermaid
stateDiagram-v2
    [*] --> ACTIVE: Registration (Member) or Creation by Admin (Staff)
    ACTIVE --> INACTIVE: Admin deactivates account
    INACTIVE --> ACTIVE: Admin activates account
    INACTIVE --> [*]: Admin deletes account (only if no active loans/fines)
```

---

## Part 2: Step-by-Step Workflow Traces (A through V)

### Workflow A: Registration and Login

1. **Entry Point**: `src/ui/Member.java:member()` (Option 1: Login, Option 2: Register).
2. **Registration Flow**:
   - UI prompts for Name, 10-digit Phone, Email regex, Age (1–120), Gender, Password (min 8 chars, 1 uppercase, 1 digit, 1 special), and Confirm Password.
   - UI invokes `authService.register(name, email, phone, confirmPassword)`:
     - `AuthService` delegates to `userService.addUser(name, email, phone, password, UserRole.MEMBER, UserStatus.ACTIVE)`.
     - Validates unique phone and unique email.
     - Hashes password using `BCrypt.hashpw(password, BCrypt.gensalt(12))`.
     - Persists new `User` to `userRepository`.
     - Records audit: `USER_REGISTERED`.
   - UI invokes `userService.updateRegistrationDetails(phone, age, gender)`.
3. **Login Flow**:
   - UI prompts for identifier (Phone or Email) and Password.
   - UI invokes `authService.login(identifier, password)`:
     - Looks up user by phone; if null, looks up by email.
     - Validates `BCrypt.checkpw(password, user.getPasswordHash())`.
     - Verifies account status is `ACTIVE`.
     - Records audit: `USER_LOGIN`.
     - Returns authenticated `User` object, assigned to `Main.currentUser`.

---

### Workflow B: Membership Purchase

1. **Entry Point**: `src/ui/Member.java:handleActivateMembership()`.
2. **Flow**:
   - UI checks whether user already has an active membership.
   - UI lists all available plans from `membershipPlanService.getAllPlans()`.
   - User enters Plan ID.
   - User chooses Payment Method (UPI, CARD, NET_BANKING) via `UiHelpers.choosePaymentMethod()`.
   - UI invokes `membershipService.purchaseMembership(user, planId, method)`:
     - Validates user is active member.
     - Resolves plan.
     - Calls payment gateway (`paymentStrategy.pay(user, plan.getAmount(), method)`).
     - Persists successful `Payment` entity (`membershipPayment = true`).
     - Creates and persists `Membership` entity: `status = ACTIVE`, `startDate = today`, `endDate = today.plusDays(365)` (or 30 days based on plan configuration).
     - Records audit: `MEMBERSHIP_ACTIVATED`.
     - Sends notification to member.

---

### Workflow C: Membership Renewal

1. **Entry Point**: `src/ui/Member.java:handleRenewMembership()`.
2. **Flow**:
   - UI looks up existing membership (`memberships.findByUserPhone`).
   - If membership is currently active, extends `endDate` by plan duration. If expired, sets `startDate = today` and `endDate = today.plusDays(planDays)`.
   - Processes payment via `paymentStrategy.pay()`.
   - Updates `Membership` record and saves.
   - Emits notification and logs audit.

---

### Workflow D: Family-Plan Setup and Family-Member Linking

1. **Setup**: Primary member who purchased a Family plan calls `FamilyAccountService.createFamilyAccount(owner)`:
   - Sets `owner.familyGroupId = "FAMILY-" + owner.getUserId()`.
   - Generates 6-digit random code (e.g., `"482910"`).
   - Hashes code with BCrypt into `owner.familyJoinCodeHash`.
   - Returns plaintext code to primary member.
2. **Join Request**: Joinee calls `FamilyAccountService.requestToJoin(joinee, primaryPhone)`:
   - Verifies joinee has no membership and no existing family link.
   - Appends `FamilyJoinRequest(primaryPhone, joineePhone, PENDING)` to `dataStore.familyJoinRequests`.
3. **Approval**: Primary member calls `processJoinRequest(...)`:
   - Verifies code against `BCrypt.checkpw(code, primary.familyJoinCodeHash)`.
   - Verifies linked member count < 4.
   - Sets `joinee.familyGroupId = primary.familyGroupId`.
   - Marks request `APPROVED`.

---

### Workflow E: Add Book

*(Detailed in forensic audit document `ADD_BOOK_REMOVE_BOOK_AUDIT.md`)*
- UI calls `bookService.addBookFromDetails(...)`.
- Validates permissions, fields, normalizes ISBN, looks up/creates taxonomy (authors/genres/categories), persists `Book`, persists `BookCopy` records. Rolls back copies and book on failure.

---

### Workflow F: Remove Book

*(Detailed in forensic audit document `ADD_BOOK_REMOVE_BOOK_AUDIT.md`)*
- UI calls `bookService.removeBookByIsbn(...)`.
- Validates permissions and ISBN. Verifies no copies are `ISSUED` or `RESERVED`. Deletes copies and book title.

---

### Workflow G: Update Book

- **Status**: **DOES NOT EXIST IN CODEBASE**.
- Neither `BookService.java`, `Librarian.java`, nor `Admin.java` provides a book update method or menu option.

---

### Workflow H: Add and Remove Individual Book Copies

- **Status**: **DOES NOT EXIST IN CODEBASE**.
- Copies are created solely in bulk during `addBookFromDetails`. There is no standalone UI or service method to increment or decrement copy counts for an existing title.

---

### Workflow I: Request Book

1. **Entry Point**: `src/ui/Member.java:handleRequestBook()`.
2. **Flow**:
   - Member enters ISBN.
   - UI calls `bookTransactionService.requestBookByIsbn(memberPhone, isbn, currentUser)`.
   - Evaluates `getRequestFailureReasons`:
     - Checks active membership.
     - Checks member borrowing limit (`policy.canRequestBook`).
     - Checks unpaid fines (`fineService.hasPendingFineForUser`).
     - Checks whether member already has an active loan/request for this title.
   - Creates new `Transaction(status = REQUESTED)`.
   - Calls `autoReserveAvailableCopies(bookId)`:
     - If copy available: assigns copy, transitions to `RESERVED`.
     - If no copy available: leaves in `REQUESTED` and sends notification: "Your request is queued."

---

### Workflow J: Automatic Reservation and Queue Allocation

1. **Method**: `BookTransactionService.autoReserveAvailableCopies(int bookId)`.
2. **Queue Ordering**:
   - Priority 1: User plan priority (`policy.getRequestQueuePriority(phone)`: Premium/Family = higher priority).
   - Priority 2: `requestDate` ascending (FIFO).
   - Priority 3: `transactionId` ascending (tiebreaker).
3. **Execution**:
   - Iterates while `copies.findAvailableCopy(bookId) != null` and `getNextEligibleRequest(bookId) != null`.
   - Transitions copy `AVAILABLE -> RESERVED`.
   - Links copy ID to transaction, sets `reserveDate = now()`, transitions to `RESERVED`.

---

### Workflow K: Cancel Book Request

1. **Entry Point**: `src/ui/Member.java:handleCancelRequest()`.
2. **Flow**:
   - Member enters ISBN.
   - UI calls `bookTransactionService.cancelRequest(phone, isbn, currentUser)`.
   - Finds active request (`REQUESTED`, `RESERVED`, or `READY_FOR_PICKUP`).
   - If copy was allocated (`RESERVED`), calls `copy.releaseReservation()`, reverting copy to `AVAILABLE`.
   - Sets transaction status `CANCELLED`.
   - Calls `autoReserveAvailableCopies(bookId)` to immediately pass released copy to next in queue.

---

### Workflow L: Issue Book

1. **Entry Point**: `src/ui/Librarian.java:handleIssueBook()`.
2. **Flow**:
   - Librarian views requests marked `READY_FOR_PICKUP`.
   - Enters Transaction ID.
   - Calls `bookTransactionService.issueBook(transactionId, librarian)`:
     - Validates librarian inventory permissions.
     - Validates transaction is `READY_FOR_PICKUP`.
     - Validates member remains eligible (`policy.canIssueBook`).
     - Sets `copy.issue()`, `t.issue(dueDate)`.
     - Persists copy and transaction.
     - Emits notification with due date.
     - Logs audit: `BOOK_ISSUED`.

---

### Workflow M: Process Return

1. **Entry Point**: `src/ui/Librarian.java:handleProcessReturn()`.
2. **Flow**:
   - Librarian enters member phone and ISBN to find issued loan.
   - Calls `bookTransactionService.returnBook(transactionId, librarian)`:
     - Checks if overdue (`today > dueDate`). If overdue, calls `fineService.createOverdueFine(transactionId, today)`.
     - Sets `t.returnBook()`, `copy.returnCopy()`.
     - Persists copy and transaction.
     - Emits notification to member.
     - Calls `autoReserveAvailableCopies(bookId)` to reallocate returned copy.

---

### Workflow N: Renew Book

1. **Entry Point**: `src/ui/Member.java:handleRenewBook()`.
2. **Flow**:
   - Member enters ISBN.
   - Service verifies loan is `ISSUED`.
   - Verifies loan is not overdue (`!t.isOverdue()`).
   - Verifies no outstanding unpaid fines.
   - Extends due date: `dueDate = dueDate.plusDays(loanPeriodDays)`.
   - Persists transaction and sends notification.

---

### Workflow O: Mark Book Lost

1. **Entry Point**: `src/ui/Librarian.java:handleCopyIncident()`.
2. **Flow**:
   - Staff selects copy incident: Lost.
   - If copy is associated with an active issued loan:
     - Calls `fineService.createOverdueFine()` if currently overdue.
     - Calls `fineService.createLostBookFine(transactionId)` (assesses lost book charge from plan).
     - Sets `transaction.markLost()`, `copy.markLost()`.
   - If copy was sitting in library unissued:
     - Calls `markCopyLostUnidentified()`. No fine assessed to any member.
     - Logs audit: `UNIDENTIFIED_BOOK_INCIDENT`.

---

### Workflow P: Mark Book Damaged

1. **Entry Point**: `src/ui/Librarian.java:handleCopyIncident()`.
2. **Flow**:
   - Same flow as Mark Lost, but calls `fineService.createDamagedBookFine(transactionId)` and transitions to `DAMAGED`.

---

### Workflow Q: Fine Generation and Payment

1. **Generation**: Created automatically by `OverdueFineSchedulerService`, `returnBook`, `markCopyLost`, or `markCopyDamaged`.
2. **Payment Flow**:
   - Member or Librarian enters Fine ID.
   - Selects payment method.
   - Calls `paymentService.payFine(user, fineId, amount, method)`.
   - Payment gateway executes.
   - Updates `fine.paidAmount`. If `paidAmount >= amount`, fine status becomes `PAID`. Otherwise `PARTIALLY_PAID`.
   - Persists `Payment` record and fine record.

---

### Workflow R: Membership-Plan Management

1. **Entry Point**: `src/ui/Admin.java:handleManageMembershipPlans()`.
2. **Flow**:
   - Admin views all plans or enters new plan details (Name, Amount, Max Books, Loan Days, Fine/day, Lost charge, Damaged charge).
   - Calls `membershipPlanService.createPlan(...)`.
   - Persists to `membershipPlanRepository`.

---

### Workflow S: Policy Management

1. **Entry Point**: `src/ui/Admin.java:handleManagePolicies()`.
2. **Flow**:
   - Admin selects Plan ID.
   - Admin updates borrowing parameters (Max books, loan period, fine per day, lost book charge, damaged book charge).
   - Calls `membershipPlanService.updatePlanPolicies(...)`.

---

### Workflow T: User Management

1. **Entry Point**: `src/ui/Admin.java:handleManageUsers()`.
2. **Flow**:
   - Admin options: View users, Add Librarian, Add Admin, Activate account, Deactivate account, Change role, Delete user.
   - Deletion safety: `userService.deleteUser` prevents deleting self or users with active loans or unpaid fines.

---

### Workflow U: Audit-Log Queries

1. **Entry Point**: `src/ui/Main.java:handleViewAuditLogs()`.
2. **Flow**:
   - Filter options: View all, filter by date, week, month, year, or role.
   - Formats tabular output with Actor phone, Role, Action, Entity, Timestamp, and Details.

---

### Workflow V: Analytics Dashboard

1. **Entry Point**: `src/ui/Admin.java:handleDashboard()`.
2. **Flow**:
   - Admin enters target year.
   - Calls `analyticsService.getDashboardForYear(year)`.
   - Outputs: Registrations by age group, registrations by gender, most borrowed books by year/month/quarter, total users, membership earnings, and fine payment earnings.
