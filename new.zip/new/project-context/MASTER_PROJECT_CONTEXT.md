# Master Project Context & Architectural Authority: Library Management System (LMS)

This document is the central, comprehensive reference manual for the Java Library Management System (LMS) located at `d:/Library_v3`. It is intended to serve as the definitive source of truth for future development, code reviews, debugging, refactoring, and AI pair-programming. Every architectural statement, business rule, and workflow trace herein has been verified directly against the production source code.

---

## 1. Project Overview

- **Project Root**: `d:/Library_v3`
- **Application Type**: Interactive Java Console Application
- **Language & Runtime**: Java 17 (`javac [debug release 17]`)
- **Build System**: Apache Maven (`pom.xml`)
- **Total Source Files**: 73 Java files across 8 packages under `src/`
- **Persistence Model**: In-memory data store (`repository.DataStore`) holding `Map` and `List` collections. No external database.
- **Git Repository Status**: Not a Git repository (`fatal: not a git repository`).
- **External Dependencies**:
  - `org.mindrot:jbcrypt:0.4` (BCrypt password hashing and family join code hashing)
- **Primary Domain Functions**:
  - User and staff authentication with role-based access control (`MEMBER`, `LIBRARIAN`, `ADMIN`).
  - Book catalogue management (titles, copies, authors, genres, categories, search).
  - Loan lifecycle (borrowing requests, priority queue auto-allocation, pickup readiness, issuance, returns, renewals).
  - Incident handling (lost copies, damaged copies, unidentified library incidents).
  - Financial operations (overdue fine calculation, incident fines, fine payment, mock payment gateway).
  - Membership subscriptions (individual plans, family shared plans with BCrypt join codes).
  - Operational audit logging and statistical analytics dashboards.

---

## 2. Actual Architecture & Dependency Wiring

The application employs a layered architecture: **UI Layer -> Service Layer -> Repository Layer -> In-Memory DataStore**.

```mermaid
graph TD
    UI[Console UI: Main, Admin, Librarian, Member, UiHelpers] --> Services[Service Layer: BookService, BookTransactionService, UserService, AuthService, etc.]
    Services --> Repositories[Repository Interfaces: 12 InMemory Implementations]
    Repositories --> DataStore[Central In-Memory Storage: DataStore]
    Services --> External[Integrations: Razorpay Mock, BCrypt]
    DataStore --> IdGen[IdGenerator]
```

### 2.1 Startup & Dependency Assembly

All dependencies are instantiated as static fields inside `src/ui/Main.java:248-275`:
1. `DataStore dataStore = new DataStore()` is created.
2. 12 repository implementations (`InMemory*Repository`) are initialized with `dataStore`.
3. Support services are wired: `AuditService`, `NotificationService`, `PasswordAuthentication`, `Razorpay`.
4. Domain services are wired:
   - `PolicyService` (injected with 5 repositories and `AuditService`).
   - `FineService` (injected with `FineRepository`, `TransactionRepository`, `PolicyService`, `AuditService`).
   - `UserService` (injected with `UserRepository`, `AuditService`).
   - `AuthService` (injected with `UserService`, `UserRepository`, `PasswordAuthentication`, `AuditService`).
   - `BookService` (injected with `BookRepository`, `BookCopyRepository`, `TransactionRepository`, `AuditService`, `AuthorRepository`, `GenreRepository`).
   - `BookTransactionService` (injected with `BookRepository`, `BookCopyRepository`, `TransactionRepository`, `PolicyService`, `AuditService`, `NotificationService`, `FineService`, `UserRepository`).
     - *Note*: Constructor automatically initializes and starts `OverdueFineSchedulerService` background thread.
   - `PaymentService`, `MembershipPlanService`, `MembershipService`, `FamilyAccountService`, `AnalyticsService`.
5. `SyntheticData.syntheticData()` seeds baseline demo records on first startup.
6. `Main.main()` starts the interactive console loop.

---

## 3. Package & File Map

| Package | Count | Responsibilities | Key Classes |
|---|---|---|---|
| `authentication` | 2 | Authentication SPI and BCrypt password strategy. | `AuthenticationStrategy`, `PasswordAuthentication` |
| `enums` | 9 | Core lifecycle and domain status enums. | `BookCopyStatus`, `FineStatus`, `FineType`, `MembershipStatus`, `PaymentMethod`, `PaymentStatus`, `TransactionStatus`, `UserRole`, `UserStatus` |
| `model` | 14 | Domain entity models and carriers. | `Book`, `BookCopy`, `User`, `Transaction`, `Fine`, `Payment`, `Membership`, `MembershipPlan`, `Author`, `Genre`, `Category`, `FamilyJoinRequest`, `Audit`, `AnalyticsDashboard` |
| `paymentStrategy`| 2 | Payment gateway abstraction and mock implementation. | `PaymentStrategy`, `Razorpay` |
| `repository` | 26 | 12 interfaces, 12 in-memory implementations, `DataStore`, `SyntheticData`. | `BookRepository`, `TransactionRepository`, `UserRepository`, `DataStore`, etc. |
| `service` | 14 | Core business logic, validation, policy enforcement, scheduling. | `BookService`, `BookTransactionService`, `PolicyService`, `UserService`, `AuthService`, `FineService`, etc. |
| `ui` | 5 | Console UI menus, input parsers, and view renderers. | `Main`, `Admin`, `Librarian`, `Member`, `UiHelpers` |
| `util` | 1 | Thread-safe ID sequence generator. | `IdGenerator` |

*(See [PROJECT_FILE_MAP.md](file:///d:/Library_v3/project-context/PROJECT_FILE_MAP.md) for individual file breakdowns).*

---

## 4. Class Responsibilities & Service Dependencies

```mermaid
classDiagram
    class BookService {
        +addBookFromDetails(User, String, String, ...) Book
        +removeBookByIsbn(User, String) boolean
        +searchBooks(String) List~Book~
        +searchByField(String, String) List~Book~
    }
    class BookTransactionService {
        +requestBookByIsbn(String, String, User) Transaction
        +markReadyForPickup(int, User) boolean
        +issueBook(int, User) boolean
        +returnBook(int, User) boolean
        +renewBook(String, String, User) boolean
        +cancelRequest(String, String, User)
        +markCopyLost(int, User) boolean
        +markCopyDamaged(int, User) boolean
    }
    class PolicyService {
        +canManageInventory(User) boolean
        +canRequestBook(String) boolean
        +canIssueBook(String) boolean
        +getBorrowingLimitForUser(String) int
        +getFinePerDayForUser(String) double
    }
    class UserService {
        +addUser(String, String, String, String, UserRole, UserStatus) boolean
        +deleteUser(User, int) boolean
        +activateAccount(User, int) boolean
        +deactivateAccount(User, int) boolean
    }
    class AuthService {
        +login(String, String) User
        +register(String, String, String, String) boolean
        +hasRole(User, UserRole) boolean
    }
    class FineService {
        +createOverdueFine(int, LocalDate) Fine
        +createLostBookFine(int) Fine
        +createDamagedBookFine(int) Fine
        +settleFine(int, double) boolean
    }
    BookTransactionService --> PolicyService
    BookTransactionService --> FineService
    BookService --> PolicyService
    AuthService --> UserService
```

---

## 5. Domain Model, Data Dictionary & Entity Relationships

### 5.1 Entity Relationship Diagram

```mermaid
erDiagram
    USER ||--o{ MEMBERSHIP : holds
    USER ||--o{ TRANSACTION : borrows
    USER ||--o{ FINE : incurs
    USER ||--o{ PAYMENT : makes
    MEMBERSHIP_PLAN ||--o{ MEMBERSHIP : defines
    BOOK ||--|{ BOOK_COPY : contains
    BOOK }|--|{ AUTHOR : written_by
    BOOK }|--|{ GENRE : categorized_by
    BOOK }|--|{ CATEGORY : classified_as
    TRANSACTION ||--|| BOOK_COPY : binds_copy
    TRANSACTION ||--o{ FINE : generates
    FINE ||--o{ PAYMENT : settles
```

### 5.2 Key Data Entities & Identity Dictionary

1. **`User` (`src/model/User.java`)**:
   - `userId` (`int`, PK generated by `IdGenerator.getUserId()`).
   - `phone` (`String`, 10 digits, unique business key across system).
   - `email` (`String`, unique).
   - `passwordHash` (`String`, BCrypt hash).
   - `role` (`UserRole`: `MEMBER`, `LIBRARIAN`, `ADMIN`).
   - `status` (`UserStatus`: `ACTIVE`, `INACTIVE`).
   - `familyGroupId` (`String`, nullable, format `"FAMILY-<primaryUserId>"`).
   - `familyJoinCodeHash` (`String`, nullable, BCrypt hash of 6-digit code).
2. **`Book` (`src/model/Book.java`)**:
   - `bookId` (`int`, PK).
   - `isbn` (`String`, unique business key, normalized uppercase alphanumeric).
   - `title`, `publisher`, `publicationYear`, `totalCopies`, `availableCopies`.
   - `authorIds` (`List<Integer>`), `genreIds` (`List<Integer>`), `categoryIds` (`List<Integer>`).
3. **`BookCopy` (`src/model/BookCopy.java`)**:
   - `bookCopyId` (`int`, PK).
   - `bookId` (`int`, FK to `Book`).
   - `status` (`BookCopyStatus`: `AVAILABLE`, `RESERVED`, `ISSUED`, `LOST`, `DAMAGED`).
4. **`Transaction` (`src/model/Transaction.java`)**:
   - `transactionId` (`int`, PK).
   - `userPhone` (`String`, FK to `User`).
   - `bookId` (`int`, FK to `Book`).
   - `bookCopyId` (`int`, FK to `BookCopy`, 0 if queued request).
   - `status` (`TransactionStatus`: `REQUESTED`, `RESERVED`, `READY_FOR_PICKUP`, `ISSUED`, `RETURNED`, `LOST`, `DAMAGED`, `CANCELLED`).
   - Dates: `requestDate`, `reserveDate`, `readyDate`, `issueDate`, `dueDate`, `returnDate`.
5. **`Fine` (`src/model/Fine.java`)**:
   - `fineId` (`int`, PK).
   - `transactionId` (`int`, FK).
   - `userPhone` (`String`, FK).
   - `amount` (`double`), `paidAmount` (`double`), `status` (`FineStatus`), `type` (`FineType`).

---

## 6. Business Rules & Policies Matrix

| Rule | Source File & Method | Implemented Behavior | Intended Behavior | Verification Status |
|---|---|---|---|---|
| **Inventory Mutation Auth** | `BookService.java:36,106`, `PolicyService.java:65` | Requires caller `user != null`, `status == ACTIVE`, and `role == LIBRARIAN || role == ADMIN`. | Staff only can add or remove books. | **Verified** |
| **ISBN Duplicate Check** | `BookService.java:53`, `InMemoryBookRepository.java:35` | Normalizes ISBN (strips dashes/spaces, uppercase) and rejects if existing book matches. | Prevent duplicate book titles under same ISBN. | **Verified** |
| **Active Copy Deletion Guard** | `BookService.java:122-129` | Rejects book deletion if any physical copy is currently `ISSUED` or `RESERVED`. Allows deletion if copies are `AVAILABLE`, `LOST`, or `DAMAGED`. | Prevent deleting titles with active member loans. | **Verified** |
| **Borrowing Quota Enforcement** | `PolicyService.java:82-105` | Checks count of active transactions (`ISSUED`, `RESERVED`, `READY_FOR_PICKUP`) against plan `maxBooks`. Family accounts aggregate loans across all members. | Block borrowing if user or family exceeds plan quota. | **Verified** |
| **Outstanding Fine Block** | `PolicyService.java:120-130`, `BookTransactionService.java:140` | Checks `fineService.hasPendingFineForUser(phone)`. Blocks new book requests or loan issues if unpaid fines exist. | Members must settle fines before borrowing. | **Verified** |
| **Loan Overdue Fine Accrual** | `FineService.java:30-58`, `OverdueFineSchedulerService.java:118-125` | Overdue days = `between(dueDate, asOfDate)`. Fine = `days * plan.finePerDay`. Updates existing overdue fine rather than creating duplicate fine record. | Accrue daily overdue fines accurately. | **Verified** |
| **Incident Charges** | `FineService.java:60-95` | Marks copy lost/damaged and creates fine with plan's `lostBookCharge` or `damagedBookCharge`. | Compensate library for damaged/lost inventory. | **Verified** |
| **Family Group Cap** | `FamilyAccountService.java:150-153` | Counts users sharing `familyGroupId`. Rejects join if count >= 4. | Family plans support up to 4 members. | **Verified** |
| **Membership Refund Prohibition** | `PaymentService.java:65-72` | Throws `IllegalStateException` if `payment.isMembershipPayment() == true`. Allows refunds for fine payments only. | Subscriptions are non-refundable. | **Verified** |
| **User Deletion Safety** | `UserService.java:120-140` | Blocks deleting own account, or accounts with active loans or unpaid fines. | Maintain referential integrity and audit trails. | **Verified** |

---

## 7. Complete Workflow Traces Summary

1. **Workflow A (Registration & Login)**: Handled via `AuthService` and `UserService` using 12-round BCrypt salt. Role hierarchy enforced: `ADMIN > LIBRARIAN > MEMBER`.
2. **Workflow B & C (Membership Purchase & Renewal)**: Managed by `MembershipService` with `Razorpay` payment gateway simulation. Extends dates and emits notifications.
3. **Workflow D (Family Account Sharing)**: Managed by `FamilyAccountService`. Generates 6-digit BCrypt-hashed join code. Joinees link to primary `familyGroupId` (capped at 4 members).
4. **Workflow E & F (Add Book & Remove Book)**: Fully consolidated in `BookService` with compensation rollback and active copy protection.
5. **Workflow G & H (Update Book & Individual Copies)**: **DO NOT EXIST IN CODEBASE**.
6. **Workflow I, J, K (Request, Queue & Cancel)**: Automated queue prioritization (`policy.getRequestQueuePriority()`, FIFO request date, ID). Automatic reallocation on cancel or return.
7. **Workflow L, M, N (Issue, Return & Renew)**: Physical copy status transitions in lockstep with loan status. Returns automatically compute overdue fines.
8. **Workflow O & P (Lost & Damaged Incidents)**: Assesses plan replacement charges. Supports unidentified copy incidents.
9. **Workflow Q (Fine Settlement)**: Supports full or partial payments. Updates status to `PARTIALLY_PAID` or `PAID`.
10. **Workflow R & S (Plans & Policies)**: Allows Admin to configure plan pricing, book limits, loan days, fine rates, and incident charges.
11. **Workflow T, U, V (User Management, Audit Logs, Analytics)**: Admin user management, multi-criteria audit log filtering, and annual/quarterly/monthly analytics metrics.

*(See [WORKFLOW_AND_STATE_REFERENCE.md](file:///d:/Library_v3/project-context/WORKFLOW_AND_STATE_REFERENCE.md) for complete step-by-step traces).*

---

## 8. State Machines & Consistency Invariants

### State Space Overview
- **Transaction**: `REQUESTED` -> `RESERVED` -> `READY_FOR_PICKUP` -> `ISSUED` -> `RETURNED` / `LOST` / `DAMAGED` / `CANCELLED`.
- **BookCopy**: `AVAILABLE` -> `RESERVED` -> `ISSUED` -> `AVAILABLE` / `LOST` / `DAMAGED`.
- **Membership**: `ACTIVE` -> `EXPIRED` / `SUSPENDED` / `CANCELLED`.
- **Fine**: `UNPAID` -> `PARTIALLY_PAID` -> `PAID` / `WAIVED`.
- **Payment**: `PENDING` -> `SUCCESS` / `FAILED` -> `REFUNDED` (Fines only).
- **FamilyJoinRequest**: `PENDING` -> `APPROVED` / `REJECTED`.
- **User**: `ACTIVE` <-> `INACTIVE`.

*(See [WORKFLOW_AND_STATE_REFERENCE.md](file:///d:/Library_v3/project-context/WORKFLOW_AND_STATE_REFERENCE.md) for full state transition diagrams).*

---

## 9. Repository, DataStore & Persistence Architecture

- **`DataStore.java`**: Holds all primary data in Java collections:
  - `Map<Integer, User> users`, `Map<String, User> usersByPhone`, `Map<String, User> usersByEmail`.
  - `Map<Integer, Book> books`, `Map<String, Book> booksByIsbn`.
  - `Map<Integer, BookCopy> bookCopies`, `Map<Integer, List<BookCopy>> copiesByBookId`.
  - `Map<Integer, Transaction> transactions`.
  - `Map<Integer, Membership> memberships`.
  - `Map<Integer, Fine> fines`.
  - `Map<Integer, Payment> payments`.
  - `Map<Integer, Author> authors`, `Map<String, Author> authorsByName`.
  - `Map<Integer, Genre> genres`, `Map<String, Genre> genresByName`.
  - `Map<Integer, Category> categories`, `Map<String, Category> categoriesByName`.
  - `Map<Integer, MembershipPlan> membershipPlans`.
  - `List<Audit> auditLogs`.
  - `List<FamilyJoinRequest> familyJoinRequests`.
- **Index Synchronization**: In-memory repositories update both primary ID maps and secondary index maps synchronously during `save` and `delete`.
- **Limitations**:
  - Entire dataset is lost when process terminates.
  - Plain `HashMap` structures are not thread-safe.

---

## 10. Authorization & Security Audit

1. **Role Hierarchy**:
   - `ADMIN`: Highest privileges. Satisfies `LIBRARIAN` and `MEMBER` checks.
   - `LIBRARIAN`: Inventory management, circulation desk operations, fine handling, member assistance. Satisfies `MEMBER` checks.
   - `MEMBER`: Self-service borrowing, catalogue search, fine payments, profile updates.
2. **Staff Impersonation Pattern (`runForTargetMember`)**:
   - Implemented in `src/ui/Member.java:868-901`.
   - Allows staff (Admin or Librarian) to perform member workflows on behalf of a target member.
   - Sets temporary static context `operationTargetUser`. `getOperationUser()` returns the target member while preserving staff identity in `currentUser` for audit logs.
   - Closes context cleanly in a `finally` block (`operationTargetUser = null`).
3. **Password Security**:
   - BCrypt with salt factor 12. Plaintext passwords never stored.

---

## 11. Exception Handling & UI Output Conventions

1. **Exception Hierarchy**:
   - `SecurityException`: Thrown when unauthorized user attempts protected operations.
   - `IllegalArgumentException`: Thrown for invalid input, missing required fields, duplicate ISBNs.
   - `IllegalStateException`: Thrown for invariant violations (e.g. removing book with active loans, renewing overdue loans).
2. **UI Output Standards**:
   - UI catches domain exceptions and displays concise, user-friendly messages: `System.out.println("Unable to [action]: " + e.getMessage());`.
   - Stack traces (`e.printStackTrace()`) are suppressed from the console.
   - Operations print success or failure messages **exactly once**.

---

## 12. Add Book & Remove Book Summary

- **Add Book**:
  - Handled by `BookService.addBookFromDetails`.
  - Normalizes ISBN, ensures unique title, creates taxonomy, persists book title, persists copies in loop.
  - Executes compensation rollback (deletes copies and book) if copy persistence fails.
- **Remove Book**:
  - Handled by `BookService.removeBookByIsbn`.
  - Validates ISBN, checks every copy. Rejects deletion if any copy is `ISSUED` or `RESERVED`.
  - Deletes copies and book title atomically in memory.

*(See [ADD_BOOK_REMOVE_BOOK_AUDIT.md](file:///d:/Library_v3/project-context/ADD_BOOK_REMOVE_BOOK_AUDIT.md) for full forensic details).*

---

## 13. Testing & Verification Summary

- **Maven Test Status**: `mvn test` executed; 0 tests exist in `src/test`.
- **Maven Compile Status**: `mvn compile` compiled 73 source files cleanly with exit code 0.
- **Scratch Verification**: 10 unit checks and UI interaction checks passed in IDE brain scratch directory.

*(See [KNOWN_ISSUES_AND_TEST_MATRIX.md](file:///d:/Library_v3/project-context/KNOWN_ISSUES_AND_TEST_MATRIX.md) for the prioritized regression test matrix).*

---

## 14. Prioritized Known Issues

1. **Concurrency Risk (High)**: Background `OverdueFineSchedulerService` daemon runs every 6 hours concurrently with UI thread accessing unsynchronized `HashMap` collections in `DataStore`.
2. **Swallowed Background Exceptions (High)**: Background scheduler catches `Exception` and prints hardcoded string to stdout without stack traces.
3. **Dangling Transaction References on Book Deletion (Medium)**: Past returned transactions retain `bookId` when a book is deleted.
4. **Data Volatility (Medium)**: In-memory only storage. All data lost on process exit.
5. **Missing Features (Medium)**: Book update and individual copy management are absent from code.

*(See [KNOWN_ISSUES_AND_TEST_MATRIX.md](file:///d:/Library_v3/project-context/KNOWN_ISSUES_AND_TEST_MATRIX.md) for full issue register).*

---

## 15. Historical Baseline & Git Status

- **Working Directory**: `d:/Library_v3`
- **Git Status**: Not a Git repository (`fatal: not a git repository`). No commit history or branch information is available on disk.
- **Source of Truth**: The active source files under `d:/Library_v3/src/` represent the sole and authoritative current implementation.

---

## 16. Rules for Future AI Assistants

Future AI assistants working on this codebase must adhere to the following confirmed rules and development constraints:

| Preference / Rule | Classification | Description & Enforcement |
|---|---|---|
| **Source Authority** | Confirmed | Inspect the actual source code before making claims or modifications. Do not trust outdated comments or assumptions. |
| **Targeted Changes Only** | Confirmed | Modify only the strictly requested files. Do not refactor unrelated classes or introduce opportunistic changes. |
| **Separation of Concerns** | Confirmed | Keep UI classes (`ui.*`) focused strictly on input collection, menu navigation, and rendering. Put business rules, validation, and mutations in services (`service.*`). |
| **Preserve Existing Behavior** | Confirmed | Preserve existing behavior and API contracts unless an explicit change is requested. |
| **No Redundant Auth Wrappers** | Confirmed | Do not introduce superfluous authorization wrappers in UI classes that merely duplicate service-level checks. Place authorization checks inside mutating service methods. |
| **Member Self-Service Identity** | Confirmed | Keep member operations tied to the logged-in member. Do not add unwanted account-ownership helper methods. |
| **Concise User Messages** | Confirmed | Use concise, precise, actionable messages. Never display raw stack traces (`printStackTrace()`) to the console user. |
| **Single Message Output** | Confirmed | Ensure the UI outputs each success or failure message exactly once. Never print success before a mutation succeeds. |
| **No Silent Swallowing** | Confirmed | Do not catch and silently discard exceptions without logging or propagating actionable feedback. |
| **Honest Payment Reporting** | Confirmed | Never report a payment failure if payment was never attempted. Never report success before confirmation. |
| **Preserve Shared Staff Methods** | Confirmed | Preserve delegation between `Admin.java` and `Librarian.java` for shared desk and catalogue operations. |
| **Verify Before Completing** | Confirmed | Always compile and verify code with `mvn compile` or test harnesses before declaring a task complete. |

---

## 17. Unresolved Questions & Assumptions

1. **Persistent Storage Strategy**: It is assumed that in-memory storage is intentional for educational/prototype purposes. If disk persistence is required in the future, repository interfaces are already decoupled and can support JDBC/JPA implementations.
2. **Book Update Requirements**: Since Workflow G (Update Book) does not exist, any future implementation must define whether ISBN changes are permitted, and how existing loans are affected.
3. **Copy Inventory Adjustments**: Since Workflow H (Individual Copy Add/Remove) does not exist, requirements must be clarified regarding whether copies can be retired or added to existing titles without re-adding the book.
