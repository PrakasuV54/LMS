# Forensic Audit: Add Book & Remove Book Workflows

This document presents a comprehensive, source-verified forensic analysis of the **Add Book** and **Remove Book** use cases in the Library Management System. Every finding, call graph, and invariant documented here has been extracted directly from the production source code in `src/ui/Librarian.java`, `src/service/BookService.java`, `src/model/Book.java`, `src/service/PolicyService.java`, `src/ui/Admin.java`, and the underlying repository implementations.

---

## 1. Executive Summary of Audit Findings

1. **Service-Layer Encapsulation**: Following the recent refactoring, business logic, authorization validation, field validation, ISBN normalization, duplicate detection, and copy creation are strictly consolidated in `BookService.java` (`addBookFromDetails` and `removeBookByIsbn`). `Librarian.java` acts purely as an input-gathering and rendering layer, following the Request Book reference pattern.
2. **Authorization**: Both operations invoke `policyService.canManageInventory(currentUser)` at the top of the service methods. Inventory management requires an active user with either `LIBRARIAN` or `ADMIN` role.
3. **Admin Delegation**: In `src/ui/Admin.java`, menu options 12 ("Add Book") and 13 ("Remove Book") directly invoke `Librarian.handleAddBook()` and `Librarian.handleRemoveBook()`. Admin uses the exact same implementation as Librarian.
4. **Rollback Behavior in Add Book**: If copy creation or repository insertion fails after the book entity is saved, `BookService` executes a compensation rollback: all newly created copies are deleted from `bookCopyRepository`, the book is deleted from `bookRepository`, and an `IllegalArgumentException` is propagated to the UI.
5. **Partial Reference Retention in Add Book**: While book and copy entities roll back on failure, newly created authors, genres, or categories created during `getOrCreate*` are **not rolled back**. They remain in their respective repositories. In the LMS domain, master catalogue taxonomy entities (author names, genre names, categories) are persistent reference data and do not invalidate the catalogue.
6. **Active Copy Guard in Remove Book**: `BookService.removeBookByIsbn` inspects every physical copy of the book. If any copy has a status other than `AVAILABLE`, `LOST`, or `DAMAGED` (specifically, if any copy is `ISSUED` or `RESERVED`), the deletion is immediately rejected with: `"Cannot delete book: One or more copies are currently issued or reserved."`
7. **Dangling Transaction References on Book Deletion**: When a book and its copies are removed, past completed `Transaction` records (status `RETURNED`, `LOST`, `DAMAGED`) and associated `Fine` records in repository memory retain `bookId` and `bookCopyId` integer foreign keys. Because repositories do not execute cascading deletes against historical transactions (to maintain audit and accounting integrity), those IDs become historical references to a removed title.

---

## 2. Forensic Investigation: Add Book

### 2.1 Complete Call Graph & Component Sequence

```mermaid
sequenceDiagram
    autonumber
    actor Staff as Librarian / Admin
    participant UI as Librarian.handleAddBook
    participant BS as BookService.addBookFromDetails
    participant PS as PolicyService.canManageInventory
    participant BR as BookRepository
    participant AR as AuthorRepository
    participant GR as GenreRepository
    participant CR as CategoryRepository
    participant BCR as BookCopyRepository
    participant AS as AuditService

    Staff->>UI: Enter ISBN, Title, Author, Genre, Category, Publisher, Year, Copies
    UI->>BS: addBookFromDetails(currentUser, isbn, title, author, genre, category, pub, year, copies)
    BS->>PS: canManageInventory(currentUser)
    alt Unauthorized
        PS-->>BS: false
        BS-->>UI: throw SecurityException("Unauthorized: Only active librarians or admins can add books.")
        UI-->>Staff: Display "Unable to add book: Unauthorized..."
    end
    BS->>BS: Validate fields (Title, ISBN, Copies >= 1)
    BS->>BS: Normalize ISBN (trim, uppercase, strip hyphens/spaces)
    BS->>BR: findByIsbn(normalizedIsbn)
    alt Duplicate ISBN
        BR-->>BS: existing Book
        BS-->>UI: throw IllegalArgumentException("Book with ISBN ... already exists.")
        UI-->>Staff: Display "Unable to add book: Book with ISBN ... already exists."
    end
    BS->>AR: getOrCreateAuthor(authorName)
    BS->>GR: getOrCreateGenre(genreName)
    BS->>CR: getOrCreateCategory(categoryName)
    BS->>BR: save(book)
    loop For each copy (1 to totalCopies)
        BS->>BCR: save(new BookCopy(bookId, AVAILABLE))
    end
    alt Copy creation failure
        BS->>BCR: deleteByBookId(bookId)
        BS->>BR: delete(bookId)
        BS-->>UI: throw IllegalArgumentException("Failed to create book copies: ...")
    end
    BS->>AS: record(staffPhone, "ADD_BOOK", "BOOK", bookId, details)
    BS-->>UI: return saved Book
    UI-->>Staff: Display "Book added successfully!" and formatted book details
```

### 2.2 Forensic Analysis Across the 20 Evaluation Points

1. **Input Collection and Normalization**:
   - Location: `src/ui/Librarian.java` lines 434–474.
   - User is prompted for: ISBN, Title, Author, Genre, Category, Publisher, Publication Year, Number of copies.
   - UI prompts support `0 to cancel` on mandatory prompts (ISBN and Title).
   - In `BookService.java` line 52: `String normalizedIsbn = normalizeIsbn(isbn);`.
   - `normalizeIsbn` converts null/empty to empty string, trims whitespace, converts to upper case, and strips all hyphens (`-`) and spaces (` `).

2. **Authorization**:
   - Location: `src/service/BookService.java` lines 36–39.
   - Evaluates `if (!policyService.canManageInventory(currentUser)) throw new SecurityException(...)`.
   - `PolicyService.canManageInventory(User)` verifies `user != null`, `user.getStatus() == UserStatus.ACTIVE`, and `(user.getRole() == UserRole.LIBRARIAN || user.getRole() == UserRole.ADMIN)`.

3. **Required-Field Validation**:
   - Location: `src/service/BookService.java` lines 41–48.
   - Validates:
     - `isbn == null || isbn.trim().isEmpty()` -> throws `"ISBN is required."`
     - `title == null || title.trim().isEmpty()` -> throws `"Title is required."`
     - `totalCopies < 1` -> throws `"Number of copies must be at least 1."`

4. **ISBN Validation and Duplicate Detection**:
   - Location: `src/service/BookService.java` lines 53–57.
   - Executes `if (bookRepository.findByIsbn(normalizedIsbn) != null)` -> throws `"Book with ISBN " + normalizedIsbn + " already exists."`.
   - In `InMemoryBookRepository.java`, `findByIsbn` checks both the raw input and normalized ISBN index.

5. **Existing versus Newly Created Authors**:
   - Location: `src/service/BookService.java` lines 61, 237–246 (`getOrCreateAuthor`).
   - If an author name is provided, checks `authorRepository.findByName(trimmed)`.
   - If existing author found, its `authorId` is reused.
   - If not found, a new `Author` is instantiated with `DataStore.getAuthorId()` and saved in `authorRepository`.

6. **Existing versus Newly Created Categories**:
   - Location: `src/service/BookService.java` lines 69, 259–268 (`getOrCreateCategory`).
   - If category name provided, checks `categoryRepository.findByName(trimmed)`.
   - If found, reuses `categoryId`; otherwise instantiates a new `Category` and saves to `categoryRepository`.

7. **Existing versus Newly Created Genres**:
   - Location: `src/service/BookService.java` lines 65, 248–257 (`getOrCreateGenre`).
   - If genre name provided, checks `genreRepository.findByName(trimmed)`.
   - Reuses existing `genreId` or creates and saves a new `Genre`.

8. **Whether at Least One Author is Required**:
   - Source finding: In `src/service/BookService.java` line 60: `if (authorName != null && !authorName.trim().isEmpty()) { ... }`.
   - Author name is optional at service validation level; if omitted, `authorIds` list is empty. However, UI prompt indicates `Enter author:` without explicitly allowing blank, but if blank is entered, it proceeds without author.

9. **Whether at Least One Genre is Required under Existing Rules**:
   - Source finding: In `src/service/BookService.java` line 64: `if (genreName != null && !genreName.trim().isEmpty()) { ... }`.
   - Genre is optional at service level. If omitted, `genreIds` list is empty.

10. **Book Creation and Constructor Validation**:
    - Location: `src/service/BookService.java` lines 73–74:
      ```java
      Book book = new Book(DataStore.getBookId(), normalizedIsbn, title.trim(),
              publisher != null ? publisher.trim() : "", publicationYear, totalCopies);
      ```
    - `Book.java` assigns `bookId`, `isbn`, `title`, `publisher`, `publicationYear`, `totalCopies`, initializes `authorIds`, `genreIds`, `categoryIds` lists, and sets `availableCopies = 0` (updated dynamically by copy persistence).

11. **Initial Book-Copy Creation**:
    - Location: `src/service/BookService.java` lines 81–85.
    - Loops `for (int i = 0; i < totalCopies; i++)`:
      `BookCopy copy = new BookCopy(DataStore.getBookCopyId(), saved.getBookId(), BookCopyStatus.AVAILABLE);`
      `bookCopyRepository.save(copy);`

12. **Repository Insertion Order**:
    - Step 1: `AuthorRepository` / `GenreRepository` / `CategoryRepository` (lookup or insert).
    - Step 2: `BookRepository.save(book)` (inserts book title record).
    - Step 3: `BookCopyRepository.save(copy)` (inserts individual copies in loop).
    - Step 4: `AuditService.record(...)` (records system audit event).

13. **Rollback Behavior if Any Step Fails**:
    - Location: `src/service/BookService.java` lines 86–92:
      ```java
      try {
          // copy saving loop
      } catch (Exception ex) {
          bookCopyRepository.deleteByBookId(saved.getBookId());
          bookRepository.delete(saved.getBookId());
          throw new IllegalArgumentException("Failed to create book copies: " + ex.getMessage(), ex);
      }
      ```
    - Both copies and book title are cleaned up atomically upon copy insertion exception.

14. **Cleanup Failures During Rollback**:
    - If `bookCopyRepository.deleteByBookId` or `bookRepository.delete` encounters an unhandled runtime error, an exception will propagate out of the catch block. However, in `InMemory*` repositories, `delete` operations remove from local hash maps and lists, which do not throw checked IO exceptions.

15. **Duplicate Validation Across UI and Service Layers**:
    - Source finding: In `src/ui/Librarian.java`, all manual validation loops (such as calling `bookService.findByIsbn` or manual string checks) were **removed** during refactoring. The UI simply prompts for input and delegates directly to `bookService.addBookFromDetails`. Duplicate validation is 100% eliminated.

16. **Whether ISBN Normalization Changes Historical Behavior**:
    - `normalizeIsbn` strips spaces and dashes and upper-cases characters (`"978-0-13-235088-4"` -> `"9780132350884"`).
    - Historical synthetic data in `SyntheticData.java` seeded ISBNs like `"9780132350884"`. In `InMemoryBookRepository`, lookups check both the raw key and `normalizeIsbn(isbn)`. Normalization provides uniform lookup behavior across search, request, issue, and remove.

17. **Whether Partially Inserted Entities Can Remain After Failure**:
    - Books and copies: **Cleaned up** via compensation rollback.
    - Authors, genres, categories: **Retained**. If an author "J.K. Rowling" was newly added and copy creation failed, the author entry remains in `AuthorRepository`. This is non-destructive since taxonomy references are globally reusable.

18. **Whether the UI Displays Service Results Exactly Once**:
    - Location: `src/ui/Librarian.java` lines 480–493.
    - Inside `try { Book added = bookService.addBookFromDetails(...); System.out.println("Book added successfully!"); ... } catch (IllegalArgumentException | SecurityException e) { System.out.println("Unable to add book: " + e.getMessage()); }`.
    - Result is printed exactly once on both success and failure paths.

19. **Whether Admin Uses the Same Implementation**:
    - Location: `src/ui/Admin.java` line 60: `case 12: Librarian.handleAddBook(); break;`.
    - Verified: Admin executes the exact same method.

20. **Whether Any Other Workflow Depends on the Current Methods**:
    - `SyntheticData.java` lines 105–115 uses `bookService.addBook(...)` (an overloaded signature that delegates directly into repository saves).
    - No other UI menu calls `addBookFromDetails`.

---

## 3. Forensic Investigation: Remove Book

### 3.1 Complete Call Graph & Component Sequence

```mermaid
sequenceDiagram
    autonumber
    actor Staff as Librarian / Admin
    participant UI as Librarian.handleRemoveBook
    participant BS as BookService.removeBookByIsbn
    participant PS as PolicyService.canManageInventory
    participant BR as BookRepository
    participant BCR as BookCopyRepository
    participant AS as AuditService

    Staff->>UI: Enter ISBN to remove
    UI->>BS: removeBookByIsbn(currentUser, isbn)
    BS->>PS: canManageInventory(currentUser)
    alt Unauthorized
        PS-->>BS: false
        BS-->>UI: throw SecurityException("Unauthorized: Only active librarians or admins can remove books.")
        UI-->>Staff: Display "Unable to remove book: Unauthorized..."
    end
    BS->>BS: Validate ISBN (not null, not blank)
    BS->>BR: findByIsbn(normalizedIsbn)
    alt Book Not Found
        BR-->>BS: null
        BS-->>UI: throw IllegalArgumentException("Book with ISBN ... not found.")
        UI-->>Staff: Display "Unable to remove book: Book with ISBN ... not found."
    end
    BS->>BCR: findByBookId(book.getBookId())
    loop For each copy
        opt Copy status != AVAILABLE && != LOST && != DAMAGED
            BS-->>UI: throw IllegalStateException("Cannot delete book: One or more copies are currently issued or reserved.")
            UI-->>Staff: Display "Unable to remove book: Cannot delete book..."
        end
    end
    BS->>BCR: deleteByBookId(book.getBookId())
    BS->>BR: delete(book.getBookId())
    BS->>AS: record(staffPhone, "REMOVE_BOOK", "BOOK", bookId, details)
    BS-->>UI: return true
    UI-->>Staff: Display "Book ... and all associated copies removed successfully."
```

### 3.2 Forensic Analysis Across the 14 Evaluation Points

1. **Input Collection**:
   - Location: `src/ui/Librarian.java` lines 528–537.
   - User is prompted for ISBN (`Enter ISBN to remove (0 to cancel):`).
   - Entering `0` cancels the operation immediately and returns to the menu.

2. **Authorization**:
   - Location: `src/service/BookService.java` lines 106–109.
   - Evaluates `if (!policyService.canManageInventory(currentUser)) throw new SecurityException(...)`.
   - Requires active `LIBRARIAN` or `ADMIN`.

3. **ISBN Validation**:
   - Location: `src/service/BookService.java` lines 111–114.
   - Validates `if (isbn == null || isbn.trim().isEmpty()) throw new IllegalArgumentException("ISBN is required.");`.
   - Normalizes ISBN via `normalizeIsbn(isbn)`.

4. **Book Lookup**:
   - Location: `src/service/BookService.java` lines 116–120.
   - Calls `Book book = bookRepository.findByIsbn(normalizedIsbn);`.
   - If `book == null`, throws `IllegalArgumentException("Book with ISBN " + normalizedIsbn + " not found.");`.

5. **Restrictions Involving Issued, Reserved, or Otherwise Active Copies**:
   - Location: `src/service/BookService.java` lines 122–129:
     ```java
     List<BookCopy> copies = bookCopyRepository.findByBookId(book.getBookId());
     for (BookCopy copy : copies) {
         if (copy.getStatus() != BookCopyStatus.AVAILABLE
                 && copy.getStatus() != BookCopyStatus.LOST
                 && copy.getStatus() != BookCopyStatus.DAMAGED) {
             throw new IllegalStateException("Cannot delete book: One or more copies are currently issued or reserved.");
         }
     }
     ```
   - Copies with status `ISSUED` or `RESERVED` explicitly block deletion.
   - Copies marked `LOST`, `DAMAGED`, or `AVAILABLE` do not block deletion.

6. **Dependencies on Existing Transactions, Fines, and Audit Records**:
   - Historical transactions (e.g., returned loans) referencing the deleted `bookId` remain in `transactionRepository`.
   - Fine records for past overdue loans on this book remain in `fineRepository`.
   - Audit logs remain in `auditLogRepository`.
   - The system preserves accounting and audit history rather than corrupting financial or event records.

7. **Whether Copies and Related Records are Deleted Consistently**:
   - Physical copies are deleted via `bookCopyRepository.deleteByBookId(book.getBookId())`.
   - The book title is deleted via `bookRepository.delete(book.getBookId())`.
   - Authors, genres, and categories are **not deleted**, because they may be shared by other books in the library.

8. **Deletion Order**:
   - Step 1: Physical copies deleted (`bookCopyRepository.deleteByBookId`).
   - Step 2: Book title deleted (`bookRepository.delete`).
   - Step 3: Audit entry recorded (`auditService.record`).
   - This order avoids orphan copies existing under a non-existent parent book ID during execution.

9. **Partial Failure and Rollback Behavior**:
   - In `InMemoryBookCopyRepository`, `deleteByBookId` iterates and removes matching copy objects from memory maps.
   - If an unexpected error occurs during deletion, any remaining in-memory objects remain. However, in the current single-threaded in-memory architecture, memory map removals do not fail mid-iteration.

10. **Exception Handling and Returned Messages**:
    - Service throws:
      - `SecurityException` -> `"Unauthorized: Only active librarians or admins can remove books."`
      - `IllegalArgumentException` -> `"ISBN is required."` or `"Book with ISBN ... not found."`
      - `IllegalStateException` -> `"Cannot delete book: One or more copies are currently issued or reserved."`
    - UI catches all three specific types and outputs: `System.out.println("Unable to remove book: " + e.getMessage());`.

11. **Whether Internal Exception Details Can Reach the User**:
    - No raw stack traces (`e.printStackTrace()`) are output. Only the concise domain message `e.getMessage()` is presented to the user.

12. **Whether the UI Duplicates Success or Failure Messages**:
    - Verified: `Librarian.handleRemoveBook` contains a single `try-catch` block printing exactly one line on success or failure.

13. **Whether Admin Delegates to the Same Handler**:
    - Location: `src/ui/Admin.java` line 61: `case 13: Librarian.handleRemoveBook(); break;`.
    - Admin shares the exact same method.

14. **Whether Removing a Book Can Leave Dangling References**:
    - Active copies cannot be dangling because deletion is blocked if any copy is `ISSUED` or `RESERVED`.
    - Inactive historical transactions (status `RETURNED`, `LOST`, `DAMAGED`) hold `bookId`. Lookups on those transactions will find `bookRepository.findById(tx.getBookId()) == null`. Services handling transaction queries (e.g. `OverdueFineSchedulerService`, `AnalyticsService`) check for null when looking up books (`if (book != null)`), preventing `NullPointerException`.
