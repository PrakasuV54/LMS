package model;

import java.util.*;

public class AnalyticsDashboard {
    public static final String[] MONTH_NAMES = {
        "January", "February", "March", "April", "May", "June",
        "July", "August", "September", "October", "November", "December"
    };

    private final int year;

    private final int totalUsersInSystem;
    private final int totalRegistrationsInYear;
    private final int[] monthlyRegistrations;
    private final Map<Integer, Map<String, Integer>> monthlyRegistrationsByGender;
    private final Map<String, Integer> registrationsByAgeGroup;
    private final Map<String, Integer> registrationsByGender;

    private final int totalBorrowingsInYear;
    private final int[] monthlyBorrowings;
    private final List<BorrowedBookDetail> borrowedBookRankings;
    private final Map<Integer, Map<String, Integer>> monthlyBorrowingByBook;
    private final Map<String, Integer> mostBorrowedBooksForYear;
    private final Map<String, Map<String, Integer>> mostBorrowedBooksByMonth;

    public static class BorrowedBookDetail {
        private final String isbn;
        private final String title;
        private final int count;

        public BorrowedBookDetail(String isbn, String title, int count) {
            this.isbn = isbn != null ? isbn : "N/A";
            this.title = title != null ? title : "Unknown";
            this.count = count;
        }

        public String getIsbn() { return isbn; }
        public String getTitle() { return title; }
        public int getCount() { return count; }
    }

    public AnalyticsDashboard(Map<String, Map<String, Integer>> mostBorrowedBooksByMonth,
                              Map<String, Map<String, Integer>> mostBorrowedBooksByQuarter,
                              Map<String, Integer> mostBorrowedBooksForYear,
                              Map<String, Integer> registrationsByAgeGroup,
                              Map<String, Integer> registrationsByGender) {
        this(java.time.Year.now().getValue(), 0, 0, new int[12], new LinkedHashMap<>(),
                registrationsByAgeGroup, registrationsByGender, 0, new int[12],
                new ArrayList<>(), new LinkedHashMap<>(), mostBorrowedBooksForYear,
                mostBorrowedBooksByMonth, mostBorrowedBooksByQuarter);
    }

    public AnalyticsDashboard(
            int year,
            int totalUsersInSystem,
            int totalRegistrationsInYear,
            int[] monthlyRegistrations,
            Map<Integer, Map<String, Integer>> monthlyRegistrationsByGender,
            Map<String, Integer> registrationsByAgeGroup,
            Map<String, Integer> registrationsByGender,
            int totalBorrowingsInYear,
            int[] monthlyBorrowings,
            List<BorrowedBookDetail> borrowedBookRankings,
            Map<Integer, Map<String, Integer>> monthlyBorrowingByBook,
            Map<String, Integer> mostBorrowedBooksForYear,
            Map<String, Map<String, Integer>> mostBorrowedBooksByMonth,
            Map<String, Map<String, Integer>> mostBorrowedBooksByQuarter) {

        this.year = year;
        this.totalUsersInSystem = totalUsersInSystem;
        this.totalRegistrationsInYear = totalRegistrationsInYear;
        this.monthlyRegistrations = monthlyRegistrations != null ? monthlyRegistrations : new int[12];
        this.monthlyRegistrationsByGender = monthlyRegistrationsByGender != null ? monthlyRegistrationsByGender : new LinkedHashMap<>();
        this.registrationsByAgeGroup = registrationsByAgeGroup != null ? registrationsByAgeGroup : new LinkedHashMap<>();
        this.registrationsByGender = registrationsByGender != null ? registrationsByGender : new LinkedHashMap<>();

        this.totalBorrowingsInYear = totalBorrowingsInYear;
        this.monthlyBorrowings = monthlyBorrowings != null ? monthlyBorrowings : new int[12];
        this.borrowedBookRankings = borrowedBookRankings != null ? borrowedBookRankings : new ArrayList<>();
        this.monthlyBorrowingByBook = monthlyBorrowingByBook != null ? monthlyBorrowingByBook : new LinkedHashMap<>();
        this.mostBorrowedBooksForYear = mostBorrowedBooksForYear != null ? mostBorrowedBooksForYear : new LinkedHashMap<>();
        this.mostBorrowedBooksByMonth = mostBorrowedBooksByMonth != null ? mostBorrowedBooksByMonth : new LinkedHashMap<>();
    }

    public int getYear() { return year; }
    public int getTotalUsersInSystem() { return totalUsersInSystem; }
    public int getTotalRegistrationsInYear() { return totalRegistrationsInYear; }
    public int[] getMonthlyRegistrations() { return monthlyRegistrations; }
    public Map<Integer, Map<String, Integer>> getMonthlyRegistrationsByGender() { return monthlyRegistrationsByGender; }
    public Map<String, Integer> getRegistrationsByAgeGroup() { return registrationsByAgeGroup; }
    public Map<String, Integer> getRegistrationsByGender() { return registrationsByGender; }

    public int getTotalBorrowingsInYear() { return totalBorrowingsInYear; }
    public int[] getMonthlyBorrowings() { return monthlyBorrowings; }
    public List<BorrowedBookDetail> getBorrowedBookRankings() { return borrowedBookRankings; }
    public Map<Integer, Map<String, Integer>> getMonthlyBorrowingByBook() { return monthlyBorrowingByBook; }
    public Map<String, Integer> getMostBorrowedBooksForYear() { return mostBorrowedBooksForYear; }
    public Map<String, Map<String, Integer>> getMostBorrowedBooksByMonth() { return mostBorrowedBooksByMonth; }

    public void display() {
        System.out.println();
        System.out.println("====================================================================================================");
        System.out.println("                     LIBRARY MANAGEMENT SYSTEM - ANNUAL ANALYTICS DASHBOARD (" + year + ")");
        System.out.println("====================================================================================================");

        displayUserRegistrationAnalytics();
        displayBookBorrowingAnalytics();

        System.out.println("====================================================================================================");
        System.out.println("                                      END OF DASHBOARD REPORT");
        System.out.println("====================================================================================================");
        System.out.println();
    }

    private void displayUserRegistrationAnalytics() {
        System.out.println("\n----------------------------------------------------------------------------------------------------");
        System.out.println("1. USER REGISTRATION ANALYTICS (YEAR: " + year + ")");
        System.out.println("----------------------------------------------------------------------------------------------------");
        System.out.println("Total Users Registered in " + year + ": " + totalRegistrationsInYear);
        System.out.println("Total Users in LMS (All-time): " + totalUsersInSystem);
        System.out.println();
        System.out.println("Monthly Registration Counts (January - December " + year + "):");

        System.out.println("+---------------+---------------------+-------------+---------------+---------------------+");
        System.out.println("| Month         | Total Registrations | Male        | Female        | Other / Unspecified |");
        System.out.println("+---------------+---------------------+-------------+---------------+---------------------+");

        int sumTotal = 0;
        int sumMale = 0;
        int sumFemale = 0;
        int sumOther = 0;

        for (int i = 0; i < 12; i++) {
            int m = i + 1;
            int count = monthlyRegistrations[i];
            sumTotal += count;

            Map<String, Integer> gMap = monthlyRegistrationsByGender.getOrDefault(m, Collections.emptyMap());
            int male = gMap.getOrDefault("MALE", 0);
            int female = gMap.getOrDefault("FEMALE", 0);
            int other = 0;
            for (Map.Entry<String, Integer> entry : gMap.entrySet()) {
                if (!entry.getKey().equalsIgnoreCase("MALE") && !entry.getKey().equalsIgnoreCase("FEMALE")) {
                    other += entry.getValue();
                }
            }
            sumMale += male;
            sumFemale += female;
            sumOther += other;

            System.out.printf("| %-13s | %19d | %11d | %13d | %19d |\n",
                    MONTH_NAMES[i], count, male, female, other);
        }

        System.out.println("+---------------+---------------------+-------------+---------------+---------------------+");
        System.out.printf("| %-13s | %19d | %11d | %13d | %19d |\n",
                "Total", sumTotal, sumMale, sumFemale, sumOther);
        System.out.println("+---------------+---------------------+-------------+---------------+---------------------+");

        System.out.println("\nRegistration Breakdown by Age Group (" + year + "):");
        System.out.println("+----------------------+-------+");
        System.out.println("| Age Group            | Count |");
        System.out.println("+----------------------+-------+");
        int ageTotal = 0;
        for (Map.Entry<String, Integer> entry : registrationsByAgeGroup.entrySet()) {
            System.out.printf("| %-20s | %5d |\n", entry.getKey(), entry.getValue());
            ageTotal += entry.getValue();
        }
        System.out.println("+----------------------+-------+");
        System.out.printf("| %-20s | %5d |\n", "Total", ageTotal);
        System.out.println("+----------------------+-------+");

        System.out.println("\nRegistration Breakdown by Gender (" + year + "):");
        System.out.println("+----------------------+-------+");
        System.out.println("| Gender               | Count |");
        System.out.println("+----------------------+-------+");


    }

    private void displayBookBorrowingAnalytics() {
        System.out.println("\n----------------------------------------------------------------------------------------------------");
        System.out.println("2. BOOK BORROWING ANALYTICS (YEAR: " + year + ")");
        System.out.println("----------------------------------------------------------------------------------------------------");
        System.out.println("Total Borrowing Activity (Books Issued in " + year + "): " + totalBorrowingsInYear);
        System.out.println();
        System.out.println("Monthly Borrowing Counts (January - December " + year + "):");

        System.out.println("+---------------+----------------+");
        System.out.println("| Month         | Books Borrowed |");
        System.out.println("+---------------+----------------+");

        int sumBorrow = 0;
        for (int i = 0; i < 12; i++) {
            int count = monthlyBorrowings[i];
            sumBorrow += count;
            System.out.printf("| %-13s | %14d |\n", MONTH_NAMES[i], count);
        }

        System.out.println("+---------------+----------------+");
        System.out.printf("| %-13s | %14d |\n", "Total", sumBorrow);
        System.out.println("+---------------+----------------+");

        System.out.println("\nMost-Borrowed Books in " + year + " (Ranked):");
        if (borrowedBookRankings.isEmpty()) {
            System.out.println("  No books were borrowed in " + year + ".");
        } else {
            System.out.println("+------+-------------------+--------------------------------------------------+---------------+");
            System.out.println("| Rank | ISBN              | Book Title                                       | Borrow Count  |");
            System.out.println("+------+-------------------+--------------------------------------------------+---------------+");
            int rank = 1;
            for (BorrowedBookDetail detail : borrowedBookRankings) {
                String title = detail.getTitle().length() > 48 ? detail.getTitle().substring(0, 45) + "..." : detail.getTitle();
                System.out.printf("| %-4d | %-17s | %-48s | %13d |\n",
                        rank++, detail.getIsbn(), title, detail.getCount());
            }
            System.out.println("+------+-------------------+--------------------------------------------------+---------------+");
        }

        System.out.println("\nMonthly Borrowing Breakdown by Book (" + year + "):");
        for (int i = 0; i < 12; i++) {
            int m = i + 1;
            Map<String, Integer> bMap = monthlyBorrowingByBook.getOrDefault(m, Collections.emptyMap());
            System.out.println("  " + MONTH_NAMES[i] + ":");
            if (bMap.isEmpty()) {
                System.out.println("    - No borrowings recorded");
            } else {
                for (Map.Entry<String, Integer> entry : bMap.entrySet()) {
                    System.out.println("    - " + entry.getKey() + ": " + entry.getValue() + " borrow(s)");
                }
            }
        }
    }
}
