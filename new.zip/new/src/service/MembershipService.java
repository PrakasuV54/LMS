package service;

import enums.MembershipStatus;
import enums.PaymentMethod;
import enums.UserStatus;
import model.Membership;
import model.MembershipPlan;
import model.Payment;
import model.User;
import paymentStrategy.PaymentStrategy;
import repository.DataStore;
import repository.MembershipRepository;
import repository.PaymentRepository;
import repository.UserRepository;
import java.time.LocalDate;

public class  MembershipService {
    private final UserRepository userRepository;
    private final MembershipRepository membershipRepository;
    private final MembershipPlanService membershipPlanService;
    private final PaymentRepository paymentRepository;
    private final PaymentStrategy paymentStrategy;
    private final AuditService auditService;
    private final NotificationService notificationService;


    public MembershipService(UserRepository users, MembershipRepository memberships, MembershipPlanService plans,
    PaymentRepository payments, PaymentStrategy strategy, AuditService auditService,
    NotificationService notificationService) {
        this.userRepository=users;
        this.membershipRepository=memberships;
        this.membershipPlanService=plans;
        this.paymentRepository=payments;
        this.paymentStrategy=strategy;
        this.auditService=auditService;
        this.notificationService=notificationService;
    }

//    private void sendUserNotification(String phone, String message) {
//        if (notificationService == null || phone == null || phone.isBlank()) return;
//        String trimmed = phone.trim();
//        User user = (userRepository != null) ? userRepository.findByPhone(trimmed) : null;
//        if (user == null && userRepository != null && trimmed.matches("\\d+")) {
//            try {
//                user = userRepository.findById(Integer.parseInt(trimmed));
//            } catch (NumberFormatException ignored) {}
//        }
//        if (user != null && user.getName() != null && !user.getName().isBlank()) {
//            notificationService.send(user.getName(), user.getPhone(), message);
//        } else {
//            notificationService.send(trimmed, message);
//        }
//    }

    private void sendUserNotification(Membership membership, String message) {
        if (notificationService == null || membership == null) return;
        User user = null;
        if (userRepository != null && membership.getUserId() > 0) {
            user = userRepository.findById(membership.getUserId());
        }
        if (user == null && userRepository != null && membership.getUserPhone() != null
                && !membership.getUserPhone().isBlank()) {
            user = userRepository.findByPhone(membership.getUserPhone().trim());
        }
        if (user != null) {
            notificationService.send(user, message);
        } else if (membership.getUserPhone() != null && !membership.getUserPhone().isBlank()) {
            notificationService.send(membership.getUserPhone(), message);
        } else if (membership.getUserId() > 0) {
            notificationService.send("Member (ID: " + membership.getUserId() + ")", null, message);
        }
    }



    public String getPurchaseFailureReason(String phone, int planId, int durationInMonths, PaymentMethod method) {
        java.util.List<String> failures = new java.util.ArrayList<>();
        User user = null;

        if (phone == null || phone.isBlank()) {
            failures.add("Phone number is required.");
        } else {
            user = userRepository.findByPhone(phone.trim());
            if (user == null || user.getStatus() != UserStatus.ACTIVE) {
                failures.add("Your account was not found or is inactive.");
                user = null;
            }
        }

        MembershipPlan plan = membershipPlanService.findById(planId);
        if (plan == null || plan.getAmount() <= 0) {
            failures.add("The selected membership plan is invalid or unavailable.");
        }

        if (durationInMonths <= 0) {
            failures.add("Duration must be greater than zero months.");
        }
        if (method == null) {
            failures.add("A payment method must be selected.");
        }

        if (user != null) {
            for (Membership previous : membershipRepository.findByUserPhone(phone.trim())) {
                if (previous.getStatus() == MembershipStatus.ACTIVE) {
                    if (previous.getEndDate() == null) {
                        failures.add("The existing membership has no expiry date. Please contact library staff before purchasing another membership.");
                        break;
                    }
                    if (!LocalDate.now().isAfter(previous.getEndDate())) {
                        failures.add("You already have an active membership. Please use Renew Membership to extend or change plans.");
                        break;
                    }
                }
            }
        }

        return failures.isEmpty() ? null : String.join("\n", failures);
    }



    public Membership getMembershipByPhoneInternal(String phone) {
        if (phone == null || phone.isBlank()) return null;
        return membershipRepository.findActiveByUserPhone(phone.trim());
    }

    public Membership getMembershipByPhone(String phone) {
        return getMembershipByPhoneInternal(phone);
    }

    public void purchaseMembership(String phone, int planId, int durationInMonths, PaymentMethod method) {
        String failure = getPurchaseFailureReason(phone, planId, durationInMonths, method);
        if (failure != null) throw new IllegalArgumentException(failure);
        phone = phone.trim();
        MembershipPlan planResult = membershipPlanService.findById(planId);
        for (Membership previous : membershipRepository.findByUserPhone(phone)) {
            if (previous.getStatus() == MembershipStatus.ACTIVE && previous.getEndDate() != null
                    && LocalDate.now().isAfter(previous.getEndDate())) {
                previous.expire();
                membershipRepository.save(previous);
            }
        }
        int membershipId=DataStore.getMembershipId();
        int paymentId=DataStore.getPaymentId();
        double totalCost = planResult.getAmount() * durationInMonths;
        Payment payment=Payment.forMembership(paymentId,membershipId,phone,totalCost,method);
        paymentRepository.save(payment);
        int gatewayReference = paymentStrategy.pay(totalCost);
        LocalDate start = LocalDate.now();
        Membership membership = new Membership(membershipId, phone, planId, start,
                start.plusMonths(durationInMonths), MembershipStatus.ACTIVE, paymentId);
        payment.markSuccess("GATEWAY-" + gatewayReference);
        paymentRepository.save(payment);
        membershipRepository.save(membership);
        if (auditService != null) auditService.record(phone, "MEMBERSHIP_PURCHASED", "MEMBERSHIP", String.valueOf(membershipId), "Plan ID " + planId + ", payment ID " + paymentId);
        sendUserNotification(membership, "Membership activated until " + membership.getEndDate());
    }

    public boolean renewMembership(String phone, int planId, int durationInMonths, PaymentMethod method) {
        String failure = getRenewFailureReason(phone, planId, durationInMonths, method);
        if (failure != null) throw new IllegalArgumentException(failure);
        phone = phone.trim();
        Membership membership = membershipRepository.findActiveByUserPhone(phone);
        MembershipPlan plan = membershipPlanService.findById(planId);
        double totalCost = plan.getAmount() * durationInMonths;
        int paymentId = DataStore.getPaymentId();
        Payment payment = Payment.forMembership(paymentId, membership.getMembershipId(), phone, totalCost, method);
        paymentRepository.save(payment);
        int gatewayReference = paymentStrategy.pay(totalCost);
        LocalDate baseDate = membership.getEndDate() != null && membership.getEndDate().isAfter(LocalDate.now())
                ? membership.getEndDate() : LocalDate.now();
        LocalDate newEndDate = baseDate.plusMonths(durationInMonths);
        payment.markSuccess("GATEWAY-" + gatewayReference);
        paymentRepository.save(payment);
        membership.extend(newEndDate);
        membership.setPlanId(planId);
        membershipRepository.save(membership);
        if (auditService != null)
            auditService.record(phone, "MEMBERSHIP_RENEWED", "MEMBERSHIP", String.valueOf(membership.getMembershipId()), "Payment ID " + paymentId + ", new end date " + newEndDate);
        sendUserNotification(membership, "Membership renewed until " + newEndDate);
        return true;
    }

    private boolean renewMembershipForPhone(String phone, int planId, int durationInMonths, PaymentMethod method) {
        String failure = getRenewFailureReason(phone, planId, durationInMonths, method);
        if (failure != null) throw new IllegalArgumentException(failure);
        phone = phone.trim();
        Membership membership = membershipRepository.findActiveByUserPhone(phone);
        MembershipPlan plan = membershipPlanService.findById(planId);
        double totalCost = plan.getAmount() * durationInMonths;
        int paymentId = DataStore.getPaymentId();
        Payment payment = Payment.forMembership(paymentId, membership.getMembershipId(), phone, totalCost, method);
        paymentRepository.save(payment);
        int gatewayReference;
        try {
            gatewayReference = paymentStrategy.pay(totalCost);
        } catch (RuntimeException ex) {
            payment.markFailed();
            paymentRepository.save(payment);
            return false;
        }
        if (gatewayReference <= 0) {
            payment.markFailed();
            paymentRepository.save(payment);
            return false;
        }
        LocalDate baseDate = membership.getEndDate() != null && membership.getEndDate().isAfter(LocalDate.now())
                ? membership.getEndDate() : LocalDate.now();
        LocalDate newEndDate = baseDate.plusMonths(durationInMonths);
        payment.markSuccess("GATEWAY-" + gatewayReference);
        paymentRepository.save(payment);
        membership.extend(newEndDate);
        membership.setPlanId(planId);
        membershipRepository.save(membership);
        if (auditService != null)
            auditService.record(phone, "MEMBERSHIP_RENEWED", "MEMBERSHIP", String.valueOf(membership.getMembershipId()), "Payment ID " + paymentId + ", new end date " + newEndDate);
        sendUserNotification(membership, "Membership renewed until " + newEndDate);
        return true;
    }

    public String manageMembershipStatus(User staff, String phone, boolean suspend) {
        try {
            if (!isAdminOrStaff(staff)) return "Insufficient permissions. Staff authorization required.";
            if (phone == null || phone.isBlank()) return "Member phone number is required.";
            String memberPhone = phone.trim();
            Membership membership = null;
            if (suspend) {
                membership = membershipRepository.findActiveByUserPhone(memberPhone);
                if (membership == null) return "Member does not have an active membership to suspend.";
            } else {
                for (Membership candidate : membershipRepository.findByUserPhone(memberPhone)) {
                    if (candidate.getStatus() == MembershipStatus.SUSPENDED) {
                        membership = candidate;
                        break;
                    }
                }
                if (membership == null) return "No suspended membership found for this member.";
                if (membership.getEndDate() != null && LocalDate.now().isAfter(membership.getEndDate())) {
                    return "The suspended membership has expired. The member must purchase a new membership.";
                }
            }

            if (suspend) membership.suspend();
            else membership.activate();
            membershipRepository.save(membership);


                String action = suspend ? "MEMBERSHIP_SUSPENDED" : "MEMBERSHIP_REACTIVATED";
                auditService.record(staff.getPhone(), action, "MEMBERSHIP",
                        String.valueOf(membership.getMembershipId()), "Member phone " + memberPhone);

            return null;
        } catch (RuntimeException e) {
            return "Unable to update membership status. Please check the membership and try again.";
        }
    }

    private boolean isAdminOrStaff(User staff) {
        if (staff == null || staff.getStatus() != UserStatus.ACTIVE || (staff.getRole() != enums.UserRole.ADMIN && staff.getRole() != enums.UserRole.LIBRARIAN)) return false;
        User stored = userRepository.findByPhone(staff.getPhone());
        return stored != null && stored.getUserId() == staff.getUserId() && stored.getRole() == staff.getRole() && stored.getStatus() == UserStatus.ACTIVE;
    }

    public Membership getActiveMembership(String phone, User caller) {
        return getMembershipByPhoneInternal(phone);
    }

    public Membership getActiveMembershipInternal(String phone) {
        if (phone == null || phone.isBlank()) return null;
        return membershipRepository.findActiveByUserPhone(phone.trim());
    }

    public Membership getActiveMembership(String phone) {
        return getActiveMembershipInternal(phone);
    }

    public String getRenewFailureReason(String phone, int planId, int durationInMonths, PaymentMethod method) {
        java.util.List<String> failures = new java.util.ArrayList<>();
        User user = null;
        Membership active = null;

        if (phone == null || phone.isBlank()) {
            failures.add("Phone number is required.");
        } else {
            user = userRepository.findByPhone(phone.trim());
            if (user == null || user.getStatus() != UserStatus.ACTIVE) {
                failures.add("User account is not active.");
                user = null;
            } else {
                active = membershipRepository.findActiveByUserPhone(phone.trim());
                if (active == null) {
                    failures.add("You do not have an active membership to renew. Please use Activate Membership to purchase a plan.");
                } else if (active.getEndDate() == null) {
                    failures.add("The existing membership has no expiry date. Please contact library staff before renewing it.");
                }
            }
        }

        MembershipPlan plan = membershipPlanService.findById(planId);
        if (plan == null) {
            failures.add("Invalid membership plan ID: " + planId + ".");
        } else if (plan.getAmount() <= 0) {
            failures.add("The selected membership plan is invalid or unavailable.");
        }

        if (durationInMonths <= 0) {
            failures.add("Duration must be greater than zero months.");
        }
        if (method == null) {
            failures.add("Payment method is required.");
        }

        return failures.isEmpty() ? null : String.join("\n", failures);
    }

}
