package enums;

public enum BookStatus {
    ACTIVE, REMOVED
}
