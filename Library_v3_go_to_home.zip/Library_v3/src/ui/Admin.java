package ui;

import enums.*;
import model.*;

public class Admin extends Main {

    public static void admin() {
        if (currentUser == null || currentUser.getStatus() != UserStatus.ACTIVE || !authService.hasRole(currentUser, UserRole.ADMIN)) {
            System.out.println("Please log in as Admin"); return;
        }
        while (true) {
            System.out.println("\nAdmin Menu");
            System.out.println("1.View All Books");
            System.out.println("2.Search Books");
            System.out.println("3.Request Book");
            System.out.println("4.Cancel Request");
            System.out.println("5.Renew Book");
            System.out.println("6.Activate Membership");
            System.out.println("7.Renew Membership");
            System.out.println("8.View Currently Rented Books");
            System.out.println("9.View Borrowing History");
            System.out.println("10.Manage Fines");
            System.out.println("11.Update My Profile");
            System.out.println("12.Add Book");
            System.out.println("13.Remove Book Copy");
            System.out.println("14.View Open Requests / Pickup Queue");
            System.out.println("15.Mark Copy Ready for Pickup");
            System.out.println("16.Issue Book");
            System.out.println("17.Process Return");
            System.out.println("18.Mark Copy Lost/Damaged");
            System.out.println("19.View Defaulters");
            System.out.println("20.View Current Fines");
            System.out.println("21.Manage Current Fines");
            System.out.println("22.Manage Membership Status");
            System.out.println("23.Manage Payments");
            System.out.println("24.Dashboard");
            System.out.println("25.Manage Users");
            System.out.println("26.Manage Policies");
            System.out.println("27.Manage Membership Plans");
            System.out.println("28.View Audit Logs");
            System.out.println("29.Logout");
            System.out.println("0. Go to Home");
            System.out.println("Enter choice");
            int choice = readInt();
            try {
                switch (choice) {
                    case 0: break;
                    case 1: Member.handleViewAllBooks(); break;
                    case 2: Member.handleSearchBooks(); break;
                    case 3: Member.runForTargetMember(Member::handleRequestBook); break;
                    case 4: Member.runForTargetMember(Member::handleCancelRequest); break;
                    case 5: Member.runForTargetMember(Member::handleRenewBook); break;
                    case 6: Member.runForTargetMember(Member::handleActivateMembership); break;
                    case 7: Member.runForTargetMember(Member::handleRenewMembership); break;
                    case 8: Member.runForTargetMember(Member::handleViewCurrentlyRentedBooks); break;
                    case 9: Member.runForTargetMember(Member::handleViewBorrowingHistory); break;
                    case 10: Member.runForTargetMember(Member::handleManageFines); break;
                    case 11: Member.runForTargetMember(Member::handleUpdateProfile); break;
                    case 12: Librarian.handleAddBook(); break;
                    case 13: Librarian.handleRemoveBookCopy(); break;
                    case 14: Librarian.handleViewPendingRequests(); break;
                    case 15: Librarian.handleMarkReadyForPickup(); break;
                    case 16: Librarian.handleIssueBook(); break;
                    case 17: Librarian.handleProcessReturn(); break;
                    case 18: Librarian.handleCopyIncident(); break;
                    case 19: Librarian.handleViewDefaulters(); break;
                    case 20: Librarian.viewCurrentFines(); break;
                    case 21: Librarian.manageCurrentFines(); break;
                    case 22: Librarian.handleManageMembershipStatus(); break;
                    case 23: Librarian.handleManagePayments(); break;
                    case 24: handleDashboard(); break;
                    case 25: handleManageUsers(); break;
                    case 26: handleManagePolicies(); break;
                    case 27: handleManageMembershipPlans(); break;
                    case 28: handleViewAuditLogs(); break;
                    case 29:
                        currentUser = null;
                        System.out.println("Logged out");
                        return;
                    default:
                        System.out.println("Invalid choice");
                }
            } catch (RuntimeException e) {
                if (e != GO_HOME) throw e;
            }
        }
    }

    public static void handleDashboard() {
        System.out.println("Enter year for dashboard"); int year = readInt();
        AnalyticsDashboard dashboard = analyticsService.getDashboardForYear(year);
        dashboard.display();
    }

    public static void handleManageUsers() {
        System.out.println("1.View users  2.Add librarian  3.Add admin  4.Activate account  5.Deactivate account  6.Delete user");
        int userChoice = readInt();
        try {
            if (userChoice == 1) {
                java.util.List<User> users = userService.getAllUsers(currentUser);
                if (users == null || users.isEmpty()) {
                    System.out.println("No users found.");
                } else {
                    System.out.println("\n--- Registered Users (" + users.size() + ") ---");
                    for (User user : users) {
                        System.out.println("User ID: " + user.getUserId()
                                + " | Name: " + user.getName()
                                + " | Email: " + user.getEmail()
                                + " | Phone: " + user.getPhone()
                                + " | Role: " + user.getRole()
                                + " | Status: " + user.getStatus()
                                + " | Created: " + user.getCreatedAt());
                    }
                }
            } else if (userChoice == 2 || userChoice == 3) {
                System.out.println("Enter name"); String name = sc.nextLine().trim();
                System.out.println("Enter email"); String email = sc.nextLine().trim();
                System.out.println("Enter phone"); String phone = sc.nextLine().trim();
                System.out.println("Enter password"); String password = sc.nextLine();
                if (userChoice == 2) {
                    userService.addLibrarian(currentUser, name, email, phone, password);
                } else {
                    userService.addAdmin(currentUser, name, email, phone, password);
                }
                System.out.println("User created");
            } else if (userChoice >= 4 && userChoice <= 6) {
                System.out.println("Enter user ID"); int userId = readInt();
                if (userChoice == 4) {
                    userService.activateAccount(currentUser, userId);
                } else if (userChoice == 5) {
                    userService.deactivateAccount(currentUser, userId);
                } else {
                    userService.deleteUser(currentUser, userId);
                }
                System.out.println(userChoice == 6 ? "User deleted" : "User updated");
            } else {
                System.out.println("Invalid choice");
            }
        } catch (SecurityException | IllegalArgumentException | IllegalStateException e) {
            String action = userChoice == 2 || userChoice == 3 ? "create user"
                    : userChoice == 4 ? "activate account"
                    : userChoice == 5 ? "deactivate account"
                    : userChoice == 6 ? "delete user" : "manage users";
            System.out.println("Unable to " + action + ": " + e.getMessage());
        }
    }

    public static void handleManagePolicies() {
        try {
            java.util.List<MembershipPlan> plans = membershipPlanService.getAllPlans();
            if (plans.isEmpty()) {
                System.out.println("No membership plans exist. Create a plan first.");
                return;
            }

            System.out.println("\\nSelect the plan whose policies you want to manage:");
            for (MembershipPlan plan : plans) {
                System.out.println("Plan ID: " + plan.getPlanId() + " | " + plan.getPlanName()
                        + " | Max books: " + plan.getMaxBooks()
                        + " | Loan days: " + plan.getLoanPeriodDays()
                        + " | Fine/day: Rs." + plan.getFinePerDay()
                        + " | Lost: Rs." + plan.getLostBookCharge()
                        + " | Damaged: Rs." + plan.getDamagedBookCharge());
            }

            System.out.println("Enter Plan ID (0 to cancel)");
            int planId = readInt();
            if (planId == 0) return;

            MembershipPlan selected = membershipPlanService.findById(planId);
            if (selected == null) {
                System.out.println("Unable to manage policies: membership plan not found.");
                return;
            }

            System.out.println("Managing policies for " + selected.getPlanName() + " (ID " + planId + ")");
            System.out.println("1.Maximum books (" + selected.getMaxBooks() + ")");
            System.out.println("2.Loan days (" + selected.getLoanPeriodDays() + ")");
            System.out.println("3.Fine per day (Rs." + selected.getFinePerDay() + ")");
            System.out.println("4.Lost book charge (Rs." + selected.getLostBookCharge() + ")");
            System.out.println("5.Damaged book charge (Rs." + selected.getDamagedBookCharge() + ")");
            int choice = readInt();

            int maxBooks = selected.getMaxBooks();
            int loanDays = selected.getLoanPeriodDays();
            double fine = selected.getFinePerDay();
            double lost = selected.getLostBookCharge();
            double damaged = selected.getDamagedBookCharge();

            switch (choice) {
                case 1:
                    System.out.println("Enter maximum books allowed for " + selected.getPlanName());
                    maxBooks = readInt();
                    break;
                case 2:
                    System.out.println("Enter loan period in days for " + selected.getPlanName());
                    loanDays = readInt();
                    break;
                case 3:
                    System.out.println("Enter fine per overdue day for " + selected.getPlanName());
                    fine = readDouble();
                    break;
                case 4:
                    System.out.println("Enter lost book charge for " + selected.getPlanName());
                    lost = readDouble();
                    break;
                case 5:
                    System.out.println("Enter damaged book charge for " + selected.getPlanName());
                    damaged = readDouble();
                    break;
                default:
                    System.out.println("Invalid choice");
                    return;
            }

            MembershipPlan updated = membershipPlanService.updatePlanPolicies(currentUser, planId,
                    maxBooks, loanDays, fine, lost, damaged);
            System.out.println("Policy updated for " + updated.getPlanName() + " only.");
        } catch (SecurityException | IllegalArgumentException | IllegalStateException e) {
            System.out.println("Unable to manage policies: " + e.getMessage());
        }
    }

    public static void handleManageMembershipPlans() {
        try {
            System.out.println("1.View All Plans  2.Create Plan");
            int planChoice = readInt();

            if (planChoice == 1) {
                java.util.List<MembershipPlan> plans = membershipPlanService.getAllPlans();
                if (plans.isEmpty()) {
                    System.out.println("No membership plans exist.");
                    return;
                }
                for (MembershipPlan p : plans) {
                    System.out.println("Plan ID: " + p.getPlanId() + ", Name: " + p.getPlanName()
                            + ", Amount: Rs." + p.getAmount()
                            + ", Max books: " + p.getMaxBooks()
                            + ", Loan days: " + p.getLoanPeriodDays()
                            + ", Fine/day: Rs." + p.getFinePerDay()
                            + ", Lost charge: Rs." + p.getLostBookCharge()
                            + ", Damaged charge: Rs." + p.getDamagedBookCharge());
                }
            } else if (planChoice == 2) {
                System.out.println("Enter plan name");
                String planName = sc.nextLine().trim();
                System.out.println("Enter plan amount");
                double planAmount = readDouble();
                System.out.println("Enter maximum books that can be borrowed at once");
                int maxBooks = readInt();
                System.out.println("Enter loan period in days");
                int loanDays = readInt();
                System.out.println("Enter fine per overdue day (Rs.; 0 to disable)");
                double finePerDay = readDouble();
                System.out.println("Enter lost book charge (Rs.; 0 if not applicable)");
                double lostCharge = readDouble();
                System.out.println("Enter damaged book charge (Rs.; 0 if not applicable)");
                double damagedCharge = readDouble();

                MembershipPlan created = membershipPlanService.createPlan(currentUser, planName, planAmount,
                        maxBooks, loanDays, finePerDay, lostCharge, damagedCharge);
                System.out.println("Plan created successfully: " + created.getPlanName());
            } else {
                System.out.println("Invalid choice");
            }
        } catch (SecurityException | IllegalArgumentException | IllegalStateException e) {
            System.out.println("Unable to manage membership plans: " + e.getMessage());
        }
    }
}
