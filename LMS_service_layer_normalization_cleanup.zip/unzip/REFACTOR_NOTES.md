# UI-to-service refactoring pass

## Changes in this pass
- Removed `PolicyService.isStaff(User)`, a pass-through wrapper around `canManageInventory(User)`, and updated `FineService` to call the authorization method directly.
- Moved filtering for RESERVED and READY_FOR_PICKUP transactions from `Librarian` UI into `BookTransactionService` methods.
- Moved unique issued-loan selection (including duplicate detection) from `Member.handleRenewBook()` into `BookTransactionService`.
- Added author-presence validation to `BookService.getAddBookFailureReason()` and removed duplicate field-level validation from `Librarian.handleAddBook()` so the service owns add-book business validation.

## Still UI responsibilities
Console input, menu routing, displaying results, and verifying that a selected ID appears in the list currently displayed are kept in UI code.

## Scope limitation
This is a focused refactor, not a claim that every business rule has been removed from `Member`, `Admin`, and `Librarian`. Family-account workflows and some admin reporting / fine-display aggregation still contain direct repository operations and should be migrated in a subsequent dedicated pass to avoid changing their behavior without tests.

## Validation
Source-level changes and ZIP integrity were checked. A full Maven build and runtime test suite were not run in this environment.
