# Superseded authorization notes

This earlier note described a `canAccessAccount()` helper. The helper has since been removed per the requested simplification.

See `AUTHORIZATION_SIMPLIFICATION.md` for the current design and verification details.
