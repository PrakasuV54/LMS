package service;

import enums.MembershipStatus;
import enums.UserRole;
import enums.UserStatus;
import model.FamilyJoinRequest;
import model.Membership;
import model.MembershipPlan;
import model.User;
import repository.DataStore;
import repository.MembershipRepository;
import repository.UserRepository;

import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class FamilyAccountService {
    private final UserRepository users;
    private final MembershipRepository memberships;
    private final MembershipPlanService plans;
    private final DataStore dataStore;

    public FamilyAccountService(UserRepository users, MembershipRepository memberships,
                                MembershipPlanService plans, DataStore dataStore) {
        this.users = users;
        this.memberships = memberships;
        this.plans = plans;
        this.dataStore = dataStore;
    }

    public String createFamilyAccount(User owner) {
        if (!isStoredActiveMember(owner) || owner.getFamilyGroupId() != null) return null;
        Membership membership = memberships.findActiveByUserPhone(owner.getPhone());
        MembershipPlan plan = membership == null ? null : plans.findById(membership.getPlanId());
        if (!isFamilyPlan(plan)) return null;
        String code = generateCode();
        owner.setFamilyGroupId("FAMILY-" + owner.getUserId());
        owner.setFamilyJoinCodeHash(org.mindrot.jbcrypt.BCrypt.hashpw(code, org.mindrot.jbcrypt.BCrypt.gensalt()));
        users.save(owner);
        return code;
    }

    public boolean isActiveFamilyPrimary(User primary) {
        if (!isStoredActiveMember(primary) || primary.getFamilyGroupId() == null
                || primary.getFamilyJoinCodeHash() == null
                || !primary.getFamilyGroupId().equals("FAMILY-" + primary.getUserId())) return false;
        Membership active = memberships.findActiveByUserPhone(primary.getPhone());
        MembershipPlan plan = active == null ? null : plans.findById(active.getPlanId());
        return isFamilyPlan(plan);
    }

    public String regenerateJoinCode(User caller, String primaryPhone) {
        if (caller == null || caller.getStatus() != UserStatus.ACTIVE
                || primaryPhone == null || primaryPhone.isBlank()) return null;
        String normalizedPrimaryPhone = primaryPhone.trim();
        User primary = users.findByPhone(normalizedPrimaryPhone);
        boolean staff = isActiveStaff(caller);
        if (!staff && (!isStoredActiveMember(caller)
                || caller.getPhone() == null || !caller.getPhone().equals(normalizedPrimaryPhone))) return null;
        if (!isActiveFamilyPrimary(primary)) return null;
        String code = generateCode();
        primary.setFamilyJoinCodeHash(org.mindrot.jbcrypt.BCrypt.hashpw(code, org.mindrot.jbcrypt.BCrypt.gensalt()));
        users.save(primary);
        return code;
    }

    public String requestToJoin(User joinee, String primaryPhone) {
        if (!isStoredActiveMember(joinee)) return "Member login required.";
        if (primaryPhone == null || primaryPhone.isBlank()) return "Primary member phone number is required.";
        if (joinee.getFamilyGroupId() != null || memberships.findActiveByUserPhone(joinee.getPhone()) != null)
            return "Account already has a membership or family link.";
        String normalizedPrimaryPhone = primaryPhone.trim();
        User primary = users.findByPhone(normalizedPrimaryPhone);
        if (!isActiveFamilyPrimary(primary)) return "Active family account not found.";
        for (FamilyJoinRequest request : dataStore.getFamilyJoinRequests()) {
            if (request.getStatus() == FamilyJoinRequest.Status.PENDING
                    && request.getJoineePhone().equals(joinee.getPhone())) return "A family request is already pending.";
        }
        dataStore.addFamilyJoinRequest(primary.getPhone(), joinee.getPhone());
        return null;
    }

    public List<FamilyJoinRequest> getPendingRequests(String primaryPhone, User caller) {
        List<FamilyJoinRequest> result = new ArrayList<>();
        if (caller == null || primaryPhone == null || primaryPhone.isBlank()) return result;
        String normalizedPrimaryPhone = primaryPhone.trim();
        User primary = users.findByPhone(normalizedPrimaryPhone);
        boolean staff = isActiveStaff(caller);
        if (!isActiveFamilyPrimary(primary)) return result;
        if (!staff && (!isStoredActiveMember(caller) || caller.getPhone() == null
                || !caller.getPhone().equals(primary.getPhone()))) return result;
        for (FamilyJoinRequest request : dataStore.getFamilyJoinRequests()) {
            if (request.getStatus() == FamilyJoinRequest.Status.PENDING
                    && request.getPrimaryPhone().equals(primary.getPhone())) result.add(request);
        }
        return result;
    }

    public String processJoinRequest(User caller, String primaryPhone, String joineePhone,
                                     String code, boolean approve, boolean requireCode) {
        if (caller == null || caller.getStatus() != UserStatus.ACTIVE) return "Login required.";
        String normalizedPrimaryPhone = primaryPhone == null ? "" : primaryPhone.trim();
        User primary = users.findByPhone(normalizedPrimaryPhone);
        boolean staff = isActiveStaff(caller);
        if (!isActiveFamilyPrimary(primary)) return "Active family account not found.";
        if (!staff && (!isStoredActiveMember(caller) || caller.getPhone() == null || !caller.getPhone().equals(primary.getPhone())))
            return "You cannot manage this family account.";
        FamilyJoinRequest selected = null;
        for (FamilyJoinRequest request : dataStore.getFamilyJoinRequests()) {
            if (request.getStatus() == FamilyJoinRequest.Status.PENDING
                    && request.getPrimaryPhone().equals(primary.getPhone())
                    && request.getJoineePhone().equals(joineePhone)) {
                selected = request;
                break;
            }
        }
        if (selected == null) return "Pending request not found.";
        if (!approve) {
            selected.setStatus(FamilyJoinRequest.Status.REJECTED);
            return null;
        }
        String linkReason = linkMember(primary, joineePhone, requireCode ? code : null);
        if (linkReason != null) return linkReason;
        selected.setStatus(FamilyJoinRequest.Status.APPROVED);
        return null;
    }

    public String addFamilyMember(User caller, String primaryPhone, String joineePhone, String code,
                                  boolean requireCode) {
        if (caller == null || caller.getStatus() != UserStatus.ACTIVE) return "Login required.";
        String normalizedPrimaryPhone = primaryPhone == null ? "" : primaryPhone.trim();
        User primary = users.findByPhone(normalizedPrimaryPhone);
        boolean staff = isActiveStaff(caller);
        if (!isActiveFamilyPrimary(primary)) return "Active family account not found.";
        if (!staff && (!isStoredActiveMember(caller) || caller.getPhone() == null || !caller.getPhone().equals(primary.getPhone())))
            return "Only the primary family member can add members.";
        String reason = linkMember(primary, joineePhone, requireCode ? code : null);
        if (reason != null) return reason;
        markMatchingRequests(primary.getPhone(), joineePhone, FamilyJoinRequest.Status.APPROVED);
        return null;
    }

    private String linkMember(User primary, String joineePhone, String code) {
        if (!isActiveFamilyPrimary(primary)) return "Active family account not found.";
        if (code != null && (code.isBlank() || !org.mindrot.jbcrypt.BCrypt.checkpw(code, primary.getFamilyJoinCodeHash())))
            return "Invalid family code.";
        if (joineePhone == null || joineePhone.isBlank()) return "Joinee phone is required.";
        String normalizedJoineePhone = joineePhone.trim();
        User joinee = users.findByPhone(normalizedJoineePhone);
        if (joinee == null || joinee.getRole() != UserRole.MEMBER || joinee.getStatus() != UserStatus.ACTIVE
                || joinee.getFamilyGroupId() != null || memberships.findActiveByUserPhone(normalizedJoineePhone) != null
                || primary.getPhone().equals(normalizedJoineePhone)) return "Joinee is not eligible.";
        int linkedCount = 0;
        for (User user : users.findAll()) {
            if (primary.getFamilyGroupId().equals(user.getFamilyGroupId())) linkedCount++;
        }
        if (linkedCount >= 4) return "Family account is full.";
        joinee.setFamilyGroupId(primary.getFamilyGroupId());
        users.save(joinee);
        return null;
    }

    private void markMatchingRequests(String primaryPhone, String joineePhone, FamilyJoinRequest.Status status) {
        for (FamilyJoinRequest request : dataStore.getFamilyJoinRequests()) {
            if (request.getStatus() == FamilyJoinRequest.Status.PENDING
                    && request.getPrimaryPhone().equals(primaryPhone)
                    && request.getJoineePhone().equals(joineePhone)) request.setStatus(status);
        }
    }


    private boolean isActiveStaff(User caller) {
        if (caller == null || caller.getPhone() == null || caller.getStatus() != UserStatus.ACTIVE
                || (caller.getRole() != UserRole.ADMIN && caller.getRole() != UserRole.LIBRARIAN)) return false;
        User stored = users.findByPhone(caller.getPhone());
        return stored != null && stored.getUserId() == caller.getUserId()
                && stored.getStatus() == UserStatus.ACTIVE && stored.getRole() == caller.getRole();
    }

    private boolean isStoredActiveMember(User caller) {
        if (caller == null || caller.getPhone() == null || caller.getStatus() != UserStatus.ACTIVE
                || caller.getRole() != UserRole.MEMBER) return false;
        User stored = users.findByPhone(caller.getPhone());
        return stored != null && stored.getUserId() == caller.getUserId()
                && stored.getStatus() == UserStatus.ACTIVE && stored.getRole() == UserRole.MEMBER;
    }

    private boolean isFamilyPlan(MembershipPlan plan) {
        return plan != null && plan.getPlanName() != null
                && plan.getPlanName().toLowerCase(Locale.ROOT).contains("family");
    }

    private String generateCode() {
        return String.format(Locale.ROOT, "%06d", new SecureRandom().nextInt(1_000_000));
    }
}
