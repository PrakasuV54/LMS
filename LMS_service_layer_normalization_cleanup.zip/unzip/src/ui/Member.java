package ui;

import enums.PaymentMethod;
import enums.PaymentStatus;
import enums.TransactionStatus;
import enums.UserRole;
import enums.UserStatus;
import model.*;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import service.AuthService;
import java.util.*;

public class Member extends Main {



    public static void member() {
        System.out.println("1.Login or 2.Register or 3.Exit");
        int loginChoice = readInt();

        switch (loginChoice) {
            case 1:
                System.out.println("Enter Mobile or Email");
                String identifier = sc.nextLine().trim();
                System.out.println("Enter Password");
                String loginPassword = sc.nextLine();

                if (identifier.isEmpty() || loginPassword.isEmpty()) {
                    System.out.println("Login Failed: Phone/Email and password cannot be empty. Please enter your credentials.");
                    break;
                }

                User user = authService.login(identifier, loginPassword);
                if (user != null) {
                    if (user.getRole() != UserRole.MEMBER) {
                        currentUser = null;
                        System.out.println("Login Failed: This account is registered as " + user.getRole() + ". Please log in via the Librarian or Admin menu.");
                        break;
                    }
                    if (user.getStatus() != UserStatus.ACTIVE) {
                        currentUser = null;
                        System.out.println("Login Failed: Your account has been deactivated. Please contact the librarian for reactivation.");
                        break;
                    }
                    currentUser = user;
                    System.out.println("Login Success");
                    memberMenu();
                } else {
                    
                    User existing = userService.findByPhone(identifier);
                    if (existing == null) existing = userService.findByEmail(identifier);
                    if (existing != null && existing.getStatus() == UserStatus.INACTIVE) {
                        System.out.println("Login Failed: Your account has been deactivated. Please contact the librarian for reactivation.");
                    } else {
                        System.out.println("Login Failed: Invalid credentials. Please check your phone/email and password, or register for a new account.");
                    }
                }
                break;

            case 2:
                System.out.println("Enter your name");
                String name = sc.nextLine().trim();
                if (name.isEmpty()) {
                    System.out.println("Registration failed: Name cannot be empty.");
                    break;
                }

                System.out.println("Enter your phone number");
                String phone = sc.nextLine().trim();
                if (!phone.matches("\\d{10}")) {
                    System.out.println("Registration failed: Phone number must be a valid 10-digit number.");
                    break;
                }
                if (userService.phoneExists(phone)) {
                    System.out.println("Registration failed: An account with phone number " + phone + " already exists. Please log in or use a different phone number.");
                    break;
                }

                System.out.println("Enter your email");
                String email = sc.nextLine().trim();
                if (!email.matches("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$")) {
                    System.out.println("Registration failed: Invalid email format. Please provide a valid email address (e.g. user@example.com).");
                    break;
                }
                if (userService.emailExists(email)) {
                    System.out.println("Registration failed: An account with email address " + email + " already exists. Please log in or use a different email address.");
                    break;
                }

                System.out.println("Enter your age");
                int age;
                try { age = Integer.parseInt(sc.nextLine().trim()); }
                catch (NumberFormatException ex) { System.out.println("Registration failed: Enter a valid age."); break; }
                if (age < 1 || age > 120) { System.out.println("Registration failed: Age must be between 1 and 120."); break; }

                System.out.println("Enter your gender (MALE/FEMALE/NON_BINARY/OTHER/PREFER_NOT_TO_SAY)");
                String gender = sc.nextLine().trim().toUpperCase(java.util.Locale.ROOT);
                if (!Set.of("MALE", "FEMALE", "NON_BINARY", "OTHER", "PREFER_NOT_TO_SAY").contains(gender)) {
                    System.out.println("Registration failed: Choose one of the listed gender options."); break;
                }

                System.out.println("Enter your password");
                String registerPassword = sc.nextLine();
                if (registerPassword.length() < 8
                        || !registerPassword.matches(".*[A-Z].*")
                        || !registerPassword.matches(".*\\d.*")
                        || !registerPassword.matches(".*[^A-Za-z0-9].*")) {
                    System.out.println("Registration failed: Password must be at least 8 characters and include an uppercase letter, a number, and a special character.");
                    break;
                }

                System.out.println("Enter your password again");
                String confirmPassword = sc.nextLine();
                if (!registerPassword.equals(confirmPassword)) {
                    System.out.println("Registration failed: Passwords do not match.");
                    break;
                }

                if (authService.register(name, email, phone, confirmPassword)) {
                    if (userService.updateRegistrationDetails(phone, age, gender)) {
                        System.out.println("Registration successful. Your account and profile details have been saved.");
                    } else {
                        System.out.println("Account created, but profile details could not be saved. Please contact library staff before using the account.");
                    }
                } else {
                    String regReason = userService.getRegistrationFailureReason(name, email, phone, confirmPassword);
                    System.out.println("Registration failed: " + (regReason != null ? regReason : "Unable to create user account. Please check your details."));
                }
                break;

            case 3:
                return;

            default:
                System.out.println("Invalid Input");
        }
    }

    public static void memberMenu() {
        while (true) {
            System.out.println("\n1.View All Books");
            System.out.println("2.Search Books");
            System.out.println("3.Request Book");
            System.out.println("4.Cancel Request");
            System.out.println("5.Renew Book");
            System.out.println("6.Activate Membership");
            System.out.println("7.Renew Membership");
            System.out.println("8.View Currently Rented Books");
            System.out.println("9.View Borrowing History");
            System.out.println("10.Manage Fines");
            System.out.println("11.Update Profile");
            System.out.println("12.Join Family Account");
            System.out.println("13.Regenerate Family Join Code");
            System.out.println("14.Add Member to My Family (phone number)");
            System.out.println("15.Process Family Join Requests");
            System.out.println("16.Get Family Join Code");
            System.out.println("17.Logout");
            System.out.println("Enter Your Choice");

            int choice = readInt();

            switch (choice) {
                case 1:
                    handleViewAllBooks();
                    break;
                case 2:
                    handleSearchBooks();
                    break;
                case 3:
                    handleRequestBook();
                    break;
                case 4:
                    handleCancelRequest();
                    break;
                case 5:
                    handleRenewBook();
                    break;
                case 6:
                    handleActivateMembership();
                    break;
                case 7:
                    handleRenewMembership();
                    break;
                case 8:
                    handleViewCurrentlyRentedBooks();
                    break;
                case 9:
                    handleViewBorrowingHistory();
                    break;
                case 10:
                    handleManageFines();
                    break;
                case 11:
                    handleUpdateProfile();
                    break;
                case 12:
                    requestToJoinFamily();
                    break;
                case 13:
                    manageFamilyJoinCode();
                    break;
                case 14:
                    addMemberToMyFamily();
                    break;
                case 15:
                    processMyFamilyJoinRequests();
                    break;
                case 16:
                    getFamilyJoinCode();
                    break;
                case 17:
                    currentUser = null;
                    System.out.println("Logged out successfully");
                    return;
                default:
                    System.out.println("Invalid Choice");
            }
        }
    }

    public static void handleViewAllBooks() {
        List<Book> allBooks = bookService.getAllBooks();
        if (allBooks.isEmpty()) {
            System.out.println("No Books Found");
            return;
        }
        UiHelpers.handleBookListInteraction(allBooks);
    }

    public static void handleSearchBooks() {
        UiHelpers.searchBooks();
    }

    public static void handleRequestBook() {
        while (true) {
            System.out.println("\n--- Request a Book ---");
            System.out.println("1. Request directly by ISBN");
            System.out.println("2. Search books and request from results");
            System.out.println("3. Browse catalogue and request a book");
            System.out.println("4. Back");
            System.out.println("Enter choice:");
            int choice = readInt();
            switch (choice) {
                case 1:
                    System.out.println("Enter ISBN (0 to cancel):");
                    String requestIsbn = sc.nextLine().trim();
                    if (requestIsbn.equals("0") || requestIsbn.isEmpty()) break;
                    Book targetBook = bookService.getBookByIsbn(requestIsbn);
                    if (targetBook == null) {
                        System.out.println("No book found for ISBN '" + requestIsbn + "'. Check the ISBN or search the catalogue.");
                    } else {
                        requestBookForSelectedBook(targetBook);
                    }
                    break;
                case 2:
                    UiHelpers.searchBooks();
                    break;
                case 3:
                    List<Book> allBooks = bookService.getAllBooks();
                    if (allBooks.isEmpty()) System.out.println("The catalogue is empty.");
                    else UiHelpers.handleBookListInteraction(allBooks);
                    break;
                case 4:
                    return;
                default:
                    System.out.println("Invalid choice. Select 1-4.");
            }
        }
    }

    public static void requestBookForSelectedBook(Book book) {
        if (book == null) {
            System.out.println("No book selected.");
            return;
        }
        if (currentUser == null) {
            System.out.println("Please log in before requesting a book.");
            return;
        }
        if (currentUser.getRole() != UserRole.MEMBER && operationTargetUser == null) {
            runForTargetMember(() -> submitBookRequest(book));
        } else {
            submitBookRequest(book);
        }
    }

    private static void submitBookRequest(Book book) {
        User requestingMember = getOperationUser();
        if (requestingMember == null || requestingMember.getRole() != UserRole.MEMBER) {
            System.out.println("A valid member must be selected before requesting this book.");
            return;
        }

        List<String> borrowingBlockers = policyService.getBorrowingEligibilityFailureReasons(requestingMember.getPhone());
        if (!borrowingBlockers.isEmpty()) {
            System.out.println("Cannot request this book for " + requestingMember.getName() + ":");
            for (String blocker : borrowingBlockers) System.out.println("- " + blocker);
            String advice = policyService.getBorrowingResolutionAdvice(borrowingBlockers);
            if (!advice.isEmpty()) System.out.println("\n" + advice);
            return;
        }

        Transaction requested = bookTransactionService.requestBookByIsbn(
                requestingMember.getPhone(), book.getIsbn(), currentUser);
        if (requested == null) {
            System.out.println("Request failed for '" + book.getTitle() + "'. You may already have a request or loan for this book, or the request could not be saved.");
        } else {
            System.out.println("Book request submitted successfully.");
            System.out.println("Book: " + book.getTitle() + " | ISBN: " + book.getIsbn());
            System.out.println("Member: " + requestingMember.getName());
            System.out.println("Request status: " + requested.getStatus());
        }
    }

    public static void handleCancelRequest() {
        System.out.println("Enter ISBN to cancel request");
        String cancelIsbn = sc.nextLine().trim();
        if (cancelIsbn.isEmpty()) {
            System.out.println("ISBN cannot be empty");
            return;
        }

        Book cancelBook = bookService.getBookByIsbn(cancelIsbn);
        if (cancelBook == null) {
            System.out.println("Cancellation failed: Book with ISBN '" + cancelIsbn + "' not found in the catalogue.");
            return;
        }

        User targetMember = getOperationUser();
        if (targetMember == null || targetMember.getRole() != UserRole.MEMBER) {
            System.out.println("Cancellation failed: A valid member must be selected.");
            return;
        }

        if (bookTransactionService.cancelRequest(
                targetMember.getPhone(), cancelIsbn, currentUser)) {
            System.out.println("Request cancelled successfully");
        } else {
            System.out.println("Cancellation failed: No unique cancellable request was found for this ISBN. "
                    + "The request may already be issued, returned, cancelled, expired, or duplicated.");
        }
    }

    public static void handleRenewBook() {
        System.out.println("Enter ISBN to renew");
        String renewIsbn = sc.nextLine().trim();
        if (renewIsbn.isEmpty()) {
            System.out.println("ISBN cannot be empty");
            return;
        }

        Book renewBook = bookService.getBookByIsbn(renewIsbn);
        if (renewBook == null) {
            System.out.println("Renewal failed: Book with ISBN '" + renewIsbn + "' not found in the catalogue.");
            return;
        }

        User member = getOperationUser();
        if (member == null || member.getRole() != UserRole.MEMBER) {
            System.out.println("Renewal failed: A valid member account is required.");
            return;
        }

        // Only a book currently issued to this member can be renewed.
        List<Transaction> issuedTransactions =
                bookTransactionService.getCurrentlyBorrowedBooks(member.getPhone());
        Transaction loanToRenew = null;
        for (Transaction transaction : issuedTransactions) {
            if (transaction.getBookId() == renewBook.getBookId()
                    && transaction.getStatus() == TransactionStatus.ISSUED) {
                if (loanToRenew != null) {
                    System.out.println("Renewal failed: Multiple active loans found for this ISBN. Contact the librarian.");
                    return;
                }
                loanToRenew = transaction;
            }
        }

        if (loanToRenew == null) {
            if (issuedTransactions.isEmpty()) {
                System.out.println("Renewal failed: You currently have no issued books.");
            } else {
                System.out.println("Renewal failed: This book is not currently issued to you.");
            }
            return;
        }

        String renewFailure = bookTransactionService.getRenewFailureReason(
                loanToRenew.getTransactionId(), currentUser);
        if (renewFailure != null) {
            System.out.println("Renewal failed: " + renewFailure);
            return;
        }

        if (bookTransactionService.renewBook(loanToRenew.getTransactionId(), currentUser)) {
            System.out.println("Book renewed successfully");
        } else {
            System.out.println("Renewal failed: Unable to renew loan. Please contact library staff.");
        }
    }

    public static void handleActivateMembership() {
        User operationUser = getOperationUser();
        if (operationUser == null || operationUser.getPhone() == null || operationUser.getPhone().isBlank()) {
            System.out.println("Membership activation failed: A valid logged-in member account is required.");
            return;
        }
        Membership existingActive = membershipService.getActiveMembership(operationUser.getPhone());
        if (existingActive != null && existingActive.getEndDate() != null
                && !existingActive.getEndDate().isBefore(LocalDate.now())) {
            System.out.println("You already have an active membership (Plan ID " + existingActive.getPlanId()
                    + ", expires on " + existingActive.getEndDate() + "). Please use Renew Membership to extend or change plans.");
            return;
        }

        List<MembershipPlan> plans = membershipPlanService.getAllPlans();
        if (plans.isEmpty()) {
            System.out.println("No membership plans available");
            return;
        }

        for (MembershipPlan plan : plans) {
            System.out.println(plan.getPlanId() + ". " + plan.getPlanName()
                    + " - Rs." + plan.getAmount());
        }

        System.out.println("Enter Plan ID");
        int planId = readInt();
        MembershipPlan selectedPlan = membershipPlanService.findById(planId);
        if (selectedPlan == null) {
            System.out.println("Invalid plan ID. Please select a valid plan from the list above.");
            return;
        }

        boolean familyPlanSelected = selectedPlan.getPlanName().toLowerCase(java.util.Locale.ROOT).contains("family");
        if (familyPlanSelected && getOperationUser().getFamilyGroupId() != null) {
            System.out.println("Account already linked to a family.");
            return;
        }
        if (familyPlanSelected && getOperationUser().getRole() != UserRole.MEMBER) {
            System.out.println("Family Plans can only be purchased for member accounts.");
            return;
        }

        System.out.println("Enter duration in months");
        int duration = readInt();
        if (duration <= 0) {
            System.out.println("Duration must be greater than zero months.");
            return;
        }

        double totalCost = selectedPlan.getAmount() * duration;
        System.out.println("Selected Plan: " + selectedPlan.getPlanName());
        System.out.println("Monthly Price: ₹" + selectedPlan.getAmount());
        System.out.println("Duration: " + duration + " months");
        System.out.println("Total Amount: ₹" + totalCost);

        PaymentMethod membershipMethod = UiHelpers.choosePaymentMethod();
        if (membershipMethod == null) {
            return;
        }

        String purchaseFailure = membershipService.getPurchaseFailureReason(
                operationUser.getPhone(), planId, duration, membershipMethod);
        if (purchaseFailure != null) {
            System.out.println("Membership activation failed: " + purchaseFailure);
            return;
        }

        boolean activationSucceeded;
        try {
            activationSucceeded = membershipService.getMembershipByPhone(
                    operationUser.getPhone(), planId, duration, membershipMethod);
        } catch (RuntimeException ex) {
            System.out.println("Membership activation encountered an unexpected error. Check your payment history before retrying; contact library staff if you were charged.");
            return;
        }

        if (activationSucceeded) {
            Membership activeMem = membershipService.getActiveMembership(operationUser.getPhone());
            System.out.println("Payment Status: SUCCESS");
            System.out.println("Membership Status: " + (activeMem != null ? activeMem.getStatus() : "Unable to reload membership status"));
            if (activeMem != null && activeMem.getEndDate() != null) {
                System.out.println("Membership Expiry Date: " + activeMem.getEndDate());
            }
            System.out.println("Membership activated successfully");
            if (familyPlanSelected) {
                String generatedCode = setupFamilyAccount(operationUser);
                if (generatedCode != null) {
                    System.out.println("Family join code: " + generatedCode);
                    System.out.println("Share this code only with people you want to join.");
                } else {
                    System.out.println("IMPORTANT: Your membership payment and activation succeeded, but family account setup failed. Do not pay again. Please contact library staff to complete family setup.");
                }
            }
        } else {
            System.out.println("Membership activation failed: Payment was not completed or membership activation could not be saved. Check your payment history before retrying; contact library staff if you were charged.");
        }
    }

    private static String setupFamilyAccount(User owner) {
        try {
            String code = familyAccountService.createFamilyAccount(owner);
            if (code == null) {
                System.out.println("Unable to create family account. An active family plan is required.");
                return null;
            }
            System.out.println("Family account created. Up to 3 members can join.");
            return code;
        } catch (RuntimeException ex) {
            System.out.println("Family account setup encountered an error.");
            return null;
        }
    }

    
    public static void manageFamilyJoinCode() {
        if (currentUser == null) {
            System.out.println("Login required.");
            return;
        }
        String code = familyAccountService.regenerateJoinCode(currentUser, currentUser.getPhone());
        if (code == null) {
            System.out.println("Only the primary family member with an active family plan can manage this code.");
            return;
        }
        System.out.println("New family join code: " + code);
        System.out.println("Previous code is no longer valid. Share this code only with intended members.");
    }

    





    public static void getFamilyJoinCode() {
        if (currentUser == null) {
            System.out.println("Login required.");
            return;
        }
        boolean staff = currentUser.getRole() == UserRole.LIBRARIAN || currentUser.getRole() == UserRole.ADMIN;
        System.out.println("Enter primary member phone number:");
        String primaryPhone = sc.nextLine().trim();
        if (primaryPhone.equals("0")) return;
        if (primaryPhone.isEmpty()) {
            System.out.println("Phone number required.");
            return;
        }
        if (!staff && !primaryPhone.equals(currentUser.getPhone())) {
            System.out.println("You can only manage your own family code.");
            return;
        }
        String code = familyAccountService.regenerateJoinCode(currentUser, primaryPhone);
        if (code == null) {
            System.out.println("Primary family account with an active family plan not found, or access denied.");
            return;
        }
        System.out.println("Family join code: " + code);
        System.out.println("Previous code invalidated.");
    }



    public static void requestToJoinFamily() {
        if (currentUser == null) {
            System.out.println("Member login required.");
            return;
        }
        System.out.println("Enter primary member phone number:");
        String primaryPhone = sc.nextLine().trim();
        if (primaryPhone.equals("0")) return;
        String reason = familyAccountService.requestToJoin(currentUser, primaryPhone);
        if (reason != null) System.out.println(reason);
        else System.out.println("Family join request submitted.");
    }

    
    public static void processMyFamilyJoinRequests() {
        if (currentUser == null) {
            System.out.println("Login required.");
            return;
        }
        List<FamilyJoinRequest> pending = familyAccountService.getPendingRequests(currentUser.getPhone(), currentUser);
        if (pending.isEmpty()) {
            System.out.println("No pending requests or active family account not found.");
            return;
        }
        for (FamilyJoinRequest request : pending) {
            User joinee = userService.findByPhone(request.getJoineePhone());
            System.out.println("Request #" + request.getRequestId() + " | "
                    + (joinee == null ? request.getJoineePhone() : joinee.getName())
                    + " | " + request.getJoineePhone());
        }
        System.out.println("Enter joinee phone number (0 to cancel):");
        String joineePhone = sc.nextLine().trim();
        if (joineePhone.equals("0")) return;
        System.out.println("1.Approve  2.Reject  0.Cancel");
        int action = readInt();
        if (action == 0) return;
        if (action != 1 && action != 2) {
            System.out.println("Invalid choice.");
            return;
        }
        String reason = familyAccountService.processJoinRequest(currentUser, currentUser.getPhone(),
                joineePhone, null, action == 1, false);
        if (reason != null) System.out.println(reason);
        else System.out.println(action == 1 ? "Family account linked." : "Request rejected.");
    }

    public static void processFamilyJoinRequest() {
        System.out.println("Enter primary account phone (0 to cancel):");
        String primaryPhone = sc.nextLine().trim();
        if (primaryPhone.equals("0")) return;
        List<FamilyJoinRequest> pending = familyAccountService.getPendingRequests(primaryPhone, currentUser);
        if (pending.isEmpty()) {
            System.out.println("No pending requests or active family account not found.");
            return;
        }
        for (FamilyJoinRequest request : pending) {
            User joinee = userService.findByPhone(request.getJoineePhone());
            System.out.println("Request #" + request.getRequestId() + " | "
                    + (joinee == null ? request.getJoineePhone() : joinee.getName())
                    + " | " + request.getJoineePhone());
        }
        System.out.println("Enter joinee phone number to approve (0 to cancel):");
        String joineePhone = sc.nextLine().trim();
        if (joineePhone.equals("0")) return;
        System.out.println("Enter family secret code:");
        String code = sc.nextLine().trim();
        String reason = familyAccountService.processJoinRequest(currentUser, primaryPhone, joineePhone, code, true, true);
        if (reason != null) System.out.println(reason);
        else System.out.println("Family account linked.");
    }

    
    public static void staffAddFamilyMember() {
        System.out.println("Enter primary account phone (0 to cancel):");
        String primaryPhone = sc.nextLine().trim();
        if (primaryPhone.equals("0")) return;
        System.out.println("Enter family secret code:");
        String code = sc.nextLine().trim();
        System.out.println("Enter joinee phone (0 to cancel):");
        String joineePhone = sc.nextLine().trim();
        if (joineePhone.equals("0")) return;
        String reason = familyAccountService.addFamilyMember(currentUser, primaryPhone, joineePhone, code, true);
        if (reason != null) System.out.println(reason);
        else System.out.println("Family account linked.");
    }

    
    public static void addMemberToMyFamily() {
        if (currentUser == null) {
            System.out.println("Login required.");
            return;
        }
        System.out.println("Enter joinee phone (0 to cancel):");
        String joineePhone = sc.nextLine().trim();
        if (joineePhone.equals("0")) return;
        String reason = familyAccountService.addFamilyMember(currentUser, currentUser.getPhone(), joineePhone, null, false);
        if (reason != null) System.out.println(reason);
        else System.out.println("Family account linked.");
    }





    public static void handleRenewMembership() {
        User operationUser = getOperationUser();
        if (operationUser == null || operationUser.getPhone() == null || operationUser.getPhone().isBlank()) {
            System.out.println("Membership renewal failed: A valid logged-in member account is required.");
            return;
        }
        if (membershipService.getActiveMembership(operationUser.getPhone()) == null) {
            System.out.println("You do not have an active membership to renew. Please use Activate Membership to purchase a plan.");
            return;
        }

        List<MembershipPlan> renewalPlans = membershipPlanService.getAllPlans();
        if (renewalPlans.isEmpty()) {
            System.out.println("No membership plans available");
            return;
        }

        for (MembershipPlan plan : renewalPlans) {
            System.out.println(plan.getPlanId() + ". " + plan.getPlanName()
                    + " - Rs." + plan.getAmount());
        }

        System.out.println("Enter Plan ID");
        int renewalPlanId = readInt();
        MembershipPlan selectedRenewalPlan = membershipPlanService.findById(renewalPlanId);
        if (selectedRenewalPlan == null) {
            System.out.println("Invalid plan ID. Please select a valid plan from the list above.");
            return;
        }

        System.out.println("Enter duration in months");
        int renewalDuration = readInt();
        if (renewalDuration <= 0) {
            System.out.println("Duration must be greater than zero months.");
            return;
        }

        double renewalTotalCost = selectedRenewalPlan.getAmount() * renewalDuration;
        System.out.println("Selected Plan: " + selectedRenewalPlan.getPlanName());
        System.out.println("Monthly Price: ₹" + selectedRenewalPlan.getAmount());
        System.out.println("Duration: " + renewalDuration + " months");
        System.out.println("Total Amount: ₹" + renewalTotalCost);

        PaymentMethod renewalMethod = UiHelpers.choosePaymentMethod();
        if (renewalMethod == null) {
            return;
        }

        String renewalFailure = membershipService.getRenewFailureReason(
                operationUser.getPhone(), renewalPlanId, renewalDuration, renewalMethod);
        if (renewalFailure != null) {
            System.out.println("Membership renewal failed: " + renewalFailure);
            return;
        }

        boolean renewalSucceeded;
        try {
            renewalSucceeded = membershipService.renewMembership(operationUser.getPhone(),
                    renewalPlanId, renewalDuration, renewalMethod);
        } catch (RuntimeException ex) {
            System.out.println("Membership renewal encountered an unexpected error. Check your payment history before retrying; contact library staff if you were charged.");
            return;
        }

        if (renewalSucceeded) {
            Membership activeMem = membershipService.getActiveMembership(operationUser.getPhone());
            System.out.println("Payment Status: SUCCESS");
            System.out.println("Membership Status: " + (activeMem != null ? activeMem.getStatus() : "Unable to reload membership status"));
            if (activeMem != null && activeMem.getEndDate() != null) {
                System.out.println("Membership Expiry Date: " + activeMem.getEndDate());
            }
            System.out.println("Membership renewed successfully");
        } else {
            System.out.println("Membership renewal failed: Payment was not completed or the membership update could not be saved. Check your payment history before retrying; contact library staff if you were charged.");
        }
    }

    public static void handleViewCurrentlyRentedBooks() {
        List<Transaction> borrowed =
                bookTransactionService.getCurrentlyBorrowedBooks(getOperationUser().getPhone());
        if (borrowed.isEmpty()) {
            System.out.println("You have no currently issued books");
            return;
        }

        for (Transaction t : borrowed) {
            Book borrowedBook = bookService.getBookById(t.getBookId());
            if (borrowedBook != null) {
                System.out.println("ISBN: " + borrowedBook.getIsbn());
                System.out.println("Title: " + borrowedBook.getTitle());
                System.out.println("Status: " + t.getStatus());
                System.out.println("Due Date: " + t.getDueDate());
                System.out.println("--------------------");
            }
        }
    }

    public static void handleViewBorrowingHistory() {
        List<Transaction> history =
                bookTransactionService.getBorrowingHistory(getOperationUser().getPhone());
        if (history.isEmpty()) {
            System.out.println("No borrowing history found");
            return;
        }

        for (Transaction t : history) {
            Book historyBook = bookService.getBookById(t.getBookId());
            if (historyBook != null) {
                System.out.println("ISBN: " + historyBook.getIsbn());
                System.out.println("Title: " + historyBook.getTitle());
                System.out.println("Status: " + t.getStatus());
                System.out.println("Request Date: " + t.getRequestDate());
                System.out.println("Due Date: " + t.getDueDate());
                System.out.println("--------------------");
            }
        }
    }

    public static void handleManageFines() {
        List<Fine> fineHistory = fineService.getFineHistory(getOperationUser().getPhone(), currentUser);
        if (fineHistory.isEmpty()) {
            System.out.println("No fines found");
            return;
        }

        List<Fine> outstandingFines = fineService.getOutstandingFines(getOperationUser().getPhone(), currentUser);
        for (int i = 0; i < fineHistory.size(); i++) {
            Fine fine = fineHistory.get(i);
            Transaction fineTransaction = bookTransactionService.findTransactionById(fine.getTransactionId());
            Book fineBook = fineTransaction == null ? null
                    : bookService.getBookById(fineTransaction.getBookId());

            System.out.println((i + 1) + ". ISBN: "
                    + (fineBook == null ? "Unavailable" : fineBook.getIsbn())
                    + ", Type: " + fine.getType()
                    + ", Amount: Rs." + fine.getAmount()
                    + ", Paid: Rs." + fine.getAmountPaid()
                    + ", Remaining: Rs." + fine.getRemainingAmount()
                    + ", Status: " + fine.getStatus());
        }

        if (outstandingFines.isEmpty()) {
            System.out.println("No outstanding fines to pay");
            return;
        }

        System.out.println("Enter the ISBN for the fine you want to pay");
        String fineIsbn = sc.nextLine().trim();
        if (fineIsbn.isEmpty()) {
            System.out.println("ISBN cannot be empty");
            return;
        }

        List<Fine> matchingFines = new ArrayList<>();
        for (Fine fine : outstandingFines) {
            Transaction t = bookTransactionService.findTransactionById(fine.getTransactionId());
            Book fineBook = t == null ? null : bookService.getBookById(t.getBookId());
            if (fineBook != null && fineBook.getIsbn().equalsIgnoreCase(fineIsbn)) {
                matchingFines.add(fine);
            }
        }

        if (matchingFines.isEmpty()) {
            System.out.println("No outstanding fine found for ISBN: " + fineIsbn);
            return;
        }
        if (matchingFines.size() > 1) {
            System.out.println("More than one outstanding fine exists for this ISBN. Contact the librarian to avoid paying the wrong fine");
            return;
        }

        Fine selectedFine = matchingFines.get(0);
        System.out.println("Remaining amount: Rs." + selectedFine.getRemainingAmount());
        System.out.println("Enter amount to pay");
        String amountInput = sc.nextLine().trim();
        double amount;
        try {
            amount = Double.parseDouble(amountInput);
        } catch (NumberFormatException ex) {
            System.out.println("Invalid payment amount: Enter a numeric amount, for example 100 or 100.50.");
            return;
        }
        if (!Double.isFinite(amount)) {
            System.out.println("Invalid payment amount: Enter a valid finite amount.");
            return;
        }
        if (amount <= 0) {
            System.out.println("Invalid payment amount: Amount must be greater than zero.");
            return;
        }
        if (amount > selectedFine.getRemainingAmount()) {
            System.out.println("Invalid payment amount: Rs." + amount + " exceeds the remaining fine balance of Rs." + selectedFine.getRemainingAmount() + ".");
            return;
        }

        PaymentMethod fineMethod = UiHelpers.choosePaymentMethod();
        if (fineMethod == null) {
            return;
        }

        Payment payment;
        try {
            payment = paymentService.payFine(getOperationUser().getPhone(),
                    selectedFine.getFineId(), amount, fineMethod);
        } catch (RuntimeException ex) {
            System.out.println("Fine payment encountered an unexpected error. Refresh your fine balance before retrying; contact library staff if you were charged.");
            return;
        }
        if (payment != null && payment.getStatus() == PaymentStatus.SUCCESS) {
            System.out.println("Fine payment successful");
        } else if (payment != null && payment.getStatus() == PaymentStatus.FAILED) {
            System.out.println("Fine payment failed: The payment gateway did not complete the transaction. Please verify your fine balance before trying again.");
        } else {
            System.out.println("Fine payment was not completed. Your fine balance may have changed; refresh the fine list and try again if the balance is still outstanding.");
        }
    }

    public static void handleUpdateProfile() {
        System.out.println("1.Update Name");
        System.out.println("2.Update Email");
        System.out.println("3.Update Phone");
        System.out.println("4.Change Password");
        System.out.println("5.Back");
        System.out.println("Enter choice");
        int profileChoice = readInt();

        switch (profileChoice) {
            case 1:
                System.out.println("Enter new name");
                String newName = sc.nextLine().trim();
                if (newName.isEmpty()) {
                    System.out.println("Name cannot be empty");
                } else if (newName.equals(currentUser.getName())) {
                    System.out.println("Unable to update name: New name is identical to your current name.");
                } else if (userService.updateNameByPhone(newName, currentUser.getPhone(), currentUser)) {
                    currentUser = userService.findByPhone(currentUser.getPhone());
                    System.out.println("Name updated successfully");
                } else {
                    System.out.println("Unable to update name: Account session is inactive or unauthorized.");
                }
                break;

            case 2:
                System.out.println("Enter new email");
                String newEmail = sc.nextLine().trim();
                if (!newEmail.matches("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$")) {
                    System.out.println("Invalid email format. Please enter a valid email address (e.g., user@example.com).");
                } else if (newEmail.equalsIgnoreCase(currentUser.getEmail())) {
                    System.out.println("Unable to update email: New email is identical to your current email.");
                } else if (userService.findByEmail(newEmail) != null) {
                    System.out.println("Unable to update email: The email address '" + newEmail + "' is already registered to another account.");
                } else if (userService.changeEmailByPhone(newEmail, currentUser.getPhone(), currentUser)) {
                    currentUser = userService.findByPhone(currentUser.getPhone());
                    System.out.println("Email updated successfully");
                } else {
                    System.out.println("Unable to update email: Account session is inactive or unauthorized.");
                }
                break;

            case 3:
                System.out.println("Enter new phone number");
                String newPhone = sc.nextLine().trim();
                if (!newPhone.matches("\\d{10}")) {
                    System.out.println("Enter a valid 10-digit phone number");
                } else if (newPhone.equals(currentUser.getPhone())) {
                    System.out.println("Unable to update phone: New phone number is identical to your current phone number.");
                } else if (userService.findByPhone(newPhone) != null) {
                    System.out.println("Unable to update phone: The phone number '" + newPhone + "' is already registered to another account.");
                } else if (userService.changePhoneByPhone(currentUser.getPhone(), newPhone, currentUser)) {
                    currentUser = userService.findByPhone(newPhone);
                    System.out.println("Phone updated successfully");
                } else {
                    System.out.println("Unable to update phone: Account session is inactive or unauthorized.");
                }
                break;

            case 4:
                System.out.println("Enter current password");
                String oldPassword = sc.nextLine();
                System.out.println("Enter new password");
                String newPassword = sc.nextLine();
                if (!isValidPassword(newPassword)) {
                    System.out.println("Password must be at least 8 characters and include an uppercase letter, a number, and a special character.");
                } else if (!AuthService.verifyPassword(oldPassword, currentUser.getPasswordHash())) {
                    System.out.println("Password change failed: Current password is incorrect.");
                } else if (AuthService.verifyPassword(newPassword, currentUser.getPasswordHash())) {
                    System.out.println("Password change failed: New password cannot be the same as your current password.");
                } else if (userService.changePasswordByPhone(
                        currentUser.getPhone(), oldPassword, newPassword, currentUser)) {
                    currentUser = userService.findByPhone(currentUser.getPhone());
                    System.out.println("Password changed successfully");
                } else {
                    System.out.println("Password change failed: Account session is inactive or unauthorized.");
                }
                break;

            case 5:
                break;

            default:
                System.out.println("Invalid choice");
        }
    }
    private static boolean isValidPassword(String password) {
        return password != null && password.length() >= 8
                && password.matches(".*[A-Z].*")
                && password.matches(".*\\d.*")
                && password.matches(".*[^A-Za-z0-9].*");
    }

    public static void runForTargetMember(Runnable operation) {
        if (currentUser == null || operation == null) {
            System.out.println("Please log in before performing this operation.");
            return;
        }
        System.out.println("Enter the member's phone number or email (0 to cancel):");
        String identifier = sc.nextLine().trim();
        if (identifier.isEmpty() || identifier.equals("0")) return;

        User target = userService.findByPhone(identifier);
        if (target == null && identifier.contains("@")) {
            target = userService.findByEmail(identifier);
        }
        if (target == null) {
            System.out.println("No account found for that phone number or email.");
            return;
        }
        if (target.getRole() != UserRole.MEMBER) {
            System.out.println("This operation is for member accounts only. The selected account is " + target.getRole() + ".");
            return;
        }
        if (target.getStatus() != UserStatus.ACTIVE) {
            System.out.println("This member account is not active. Activate the account before continuing.");
            return;
        }

        operationTargetUser = target;
        try {
            System.out.println("Selected member: " + target.getName() + " | Phone: " + target.getPhone() + " | Email: " + target.getEmail());
            operation.run();
        } finally {
            operationTargetUser = null;
        }
    }
    private static User operationTargetUser;

    private static User getOperationUser() {

        return operationTargetUser != null ? operationTargetUser : currentUser;
    }
}
