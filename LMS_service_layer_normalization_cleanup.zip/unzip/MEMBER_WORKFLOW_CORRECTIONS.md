# Member Workflow Corrections

## Scope
Corrected the member workflows identified in the audit. Per the project decision, this change does not add account-ownership checks to member-specific operations where the UI derives the phone number from the logged-in member.

## Changes
1. Registration now checks the result of `updateRegistrationDetails`. It no longer prints full success if profile details were not saved.
2. Registration failure diagnostics now check phone uniqueness using `findByPhone`, rather than the phone value through the ID lookup.
3. Fine payment reads the amount as text and handles non-numeric, non-finite, zero, and negative values without crashing. Payment exceptions and gateway failure vs. a rejected/stale payment request have distinct messages.
4. Membership activation now runs a preflight validation method before charging: account state, family membership, plan validity, duration, payment method, and existing membership/expiry state. Invalid eligibility is not reported as a payment failure.
5. Expired memberships no longer get blocked in the member UI as if they were still active. The purchase service safely expires old active memberships when they have an expiry date.
6. Membership renewal runs its preflight validation before payment and detects missing expiry dates before charging. The renewal service also rejects a missing expiry date before attempting payment.
7. Membership activation and renewal no longer label every `false` result as a definite gateway failure. Unexpected exceptions tell the user to check payment history before retrying, to avoid duplicate charges.
8. If a family membership activates but family-account setup fails, the UI clearly says membership activation/payment succeeded but family setup did not, and advises contacting staff rather than paying again.
9. Profile password changes now apply the same policy as registration: at least eight characters, one uppercase letter, one digit, and one special character. The service enforces this too, not only the UI.

## Verification
- Compiled all 73 Java source files with `javac -Xlint:all` using a temporary BCrypt API stub: success.
- One existing warning remains in `src/model/Book.java:44`: possible `this` escape during construction.
- Maven and the real BCrypt dependency were unavailable in the execution environment, so no real Maven build or runtime/integration tests were run.
- The temporary BCrypt stub was used for compile-time API compatibility only; it does not validate password hashing behavior.
