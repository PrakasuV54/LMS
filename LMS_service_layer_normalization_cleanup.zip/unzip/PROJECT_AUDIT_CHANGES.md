# LMS service and validation cleanup

## Scope checked
Reviewed the Java service layer and its call paths in the latest project archive, including `AnalyticsService`, `AuditService`, `AuthService`, `BookService`, `BookTransactionService`, `FineService`, `MembershipPlanService`, `MembershipService`, `NotificationService`, `OverdueFineSchedulerService`, `PaymentService`, `PolicyService`, and `UserService`, plus the `Main` wiring and `SyntheticData` repository setup.

## Changes made

1. **Repository dependency direction**
   - `BookService` now receives `AuthorRepository` and `GenreRepository` directly.
   - Removed the `BookService` accessors that reached into `InMemoryBookRepository` through implementation casts.
   - `InMemoryBookRepository` no longer owns/exposes author and genre repositories; those are wired independently in `Main`.
   - `SyntheticData` receives its repositories explicitly instead of extracting a `DataStore` by casting `UserRepository` to `InMemoryUserRepository`.

2. **Notification recipient lookup**
   - Notification recipient lookup remains in the calling business service, using its directly injected `UserRepository`.
   - `NotificationService` only validates/format-sends the recipient details supplied to it; it does not retrieve users or depend on `PolicyService`.
   - Removed the duplicate message validation in `NotificationService.send(User, message)`, because it delegates to the overload that already validates the message.
   - The defaulters list in `PolicyService` was retained: it is used by the staff-facing defaulters feature and is not part of notification recipient resolution.

3. **Repeated validation / normalization**
   - `PolicyService` now normalizes the phone once in the borrowing-eligibility explanation path and reuses it for user, membership, fine, and transaction lookups.
   - `getIssueEligibilityFailureReasons` reuses the normalized phone and the private validated-phone helper instead of repeating the public validation/normalization path.
   - In `UserService`, private update helpers no longer repeat phone checks. Their public entry points validate the target phone before authorization/delegation. Checks for other arguments remain where the caller does not already guarantee them.
   - Removed obsolete commented-out membership notification and renewal methods.
   - Removed a redundant non-null check in `SyntheticData` after the constructor requires the repository.

## Deliberately retained

- Public entry-point validation is retained because public methods may be called independently of the UI or another service.
- Validation for arguments not guaranteed by the caller is retained (for example passwords, email/name, renewal duration, payment method, and new phone number).
- `PolicyService.getDefaulters()` and `UserService.getAllUsers()` continue returning user entities for their intended staff/admin user-list use cases; these are not being used as notification lookup APIs.
- The existing automatic book reservation flow remains unchanged.

## Verification

- The changed Java files compile successfully with `javac` against the project's existing compiled classes.
- A full Maven build/test run could not be performed because Maven is not installed in the environment. The existing compiled classes were used only as a compile-time classpath; this is not a substitute for a clean full build or runtime tests.


## Follow-up service-layer refactor

See `PROJECT_WIDE_REFACTOR_AUDIT.md` for the latest full scope and verification status. This follow-up adds FamilyAccountService, moves dashboard aggregates and audit filtering into services, removes direct repository calls from the UI classes, and delegates fine-payment validation to the responsible services.
