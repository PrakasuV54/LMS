# Book Request, Cancellation, Renewal and Eligibility Audit

## Scope
Reviewed the request/cancel/renew flows in `Member.java` and the corresponding public service methods in `BookTransactionService.java` and `PolicyService.java`. Checked supporting `Transaction` state transitions and repository behavior. This is a source-level audit plus Java compilation using a temporary BCrypt API stub; it is not a full runtime/integration test.

## Workflow assessment

### Request
Expected flow: UI resolves the member and ISBN -> `getRequestFailureReasons` performs a preflight -> `requestBookByIsbn` resolves the book -> `requestBook` rechecks authorization, membership/defaulter eligibility, book existence, and duplicate active transactions -> transaction is saved as REQUESTED -> `autoReserveAvailableCopies` reserves it if an available copy and eligible queue request exist.

Checks retained because they protect real invariants:
- Required phone, ISBN and caller.
- Book exists.
- Caller is the owner or authorized staff.
- Target account exists and has MEMBER role.
- Member is active, has valid membership, has no outstanding fine/overdue loan.
- No active transaction already exists for this member/book.
- Copy and transaction states are valid before issue/return/cancel.

### Cancellation
`cancelRequest(phone, isbn, caller)` searches the member's transactions for cancellable states (`REQUESTED`, `RESERVED`, `READY_FOR_PICKUP`). It refuses to cancel if none or more than one match exists, so it does not arbitrarily select a transaction if data violates the one-active-transaction-per-member/book rule. The transaction-ID overload rechecks status and authorization, releases a reserved copy when applicable, records the event, notifies the member, and runs automatic allocation for the freed copy.

### Renewal
Renewal requires an existing `ISSUED` transaction, a due date, a non-overdue loan, an authorized owner/staff caller, and borrowing eligibility (including membership/account/fine/overdue policy). `Transaction.renew()` additionally enforces that the new due date is later than the current due date. The UI resolves exactly one issued loan for the member and selected book before renewing.

## Fixes made during this audit
1. `getRequestFailureReasons()` now reports an existing active request/loan for the same book before the UI attempts submission. Previously, the actual request operation rejected it but the preflight could still claim there were no blockers.
2. `PolicyService.getBorrowingEligibilityFailureReasonsForValidPhone()` now uses the same family-aware membership lookup as `hasActiveMembership()`. Previously, a family-plan member whose membership is shared through the family group could pass the actual eligibility check but be incorrectly told in the failure-reason flow that they had no active membership.
3. `PolicyService.isDefaulter()` now handles issued transactions with a null due date safely. Previously, `LocalDate.now().isAfter(null)` could throw a `NullPointerException`.
4. `getRenewFailureReason()` now reports a missing due date as a data-integrity/staff-review problem instead of misleadingly saying the loan is overdue by zero days.

## Useful checks vs redundancy
- The preflight reason methods and mutation methods intentionally both check key rules. This is not redundant in a harmful sense: the preflight gives the UI a useful message, while the mutation method must remain safe when called directly or when state changes between preflight and mutation.
- Duplicate-active-transaction detection is required in the actual request method and in the preflight for accurate feedback.
- Copy-status, book-copy/book identity, transaction-status and caller authorization checks are required in mutation methods.
- The ISBN and phone trim operations at public service boundaries are appropriate; they make service methods safe when called independently of the UI.
- `canRequestBook()` does not enforce the maximum currently-issued-book limit. This is deliberate in the current workflow because a member may join the request queue while all copies/borrowing slots are occupied; `canIssueBook()` enforces the borrowing limit at issue time. If product policy instead forbids placing requests while at the borrowing limit, that would be a separate business-rule change.

## Remaining caveats
- No automated test sources were present in the project archive.
- Maven and the actual BCrypt dependency were unavailable in this environment. All Java sources compiled successfully with a temporary stub exposing the BCrypt API, which validates Java syntax and internal type consistency but not real password-hashing integration.
- One existing compiler warning remains in `model/Book.java`: possible `this` escape during constructor execution when calling `addAuthor`.
- Full runtime tests should still cover: direct/member and staff-on-behalf requests; duplicate requests; family-shared membership; no membership/inactive user/fines/overdue loan; reservation queue allocation; cancellation with/without reserved copy; duplicate-data cancellation refusal; renewal overdue/missing due date/fine/inactive membership; and issue/return copy-state mismatches.

## Result
The reviewed request/cancel/renew flow is internally coherent after the fixes above. A complete claim that every runtime path is error-free is not possible without a dependency-resolved build and end-to-end tests.
