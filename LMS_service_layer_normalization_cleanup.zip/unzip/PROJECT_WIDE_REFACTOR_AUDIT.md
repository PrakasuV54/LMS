# Project-wide service-layer refactor audit

This pass continues the earlier audit-pass ZIP and addresses the remaining high-priority service-layer items identified there.

## Changes in this pass

- Added `FamilyAccountService` to own family-account creation, primary-account eligibility, join-code generation and rotation, join requests, request approval/rejection, member linking, capacity checks, and duplicate pending-request checks.
- Updated `Member.java` family workflows to collect input, display results, and call `FamilyAccountService`; removed direct family-join-request datastore access, inline BCrypt operations, and duplicate family-linking business logic from the UI.
- Moved successful payment totals and total-user count from `Admin.handleDashboard()` to `AnalyticsService`.
- Added `AuditService.findFiltered(...)` to own date/role filtering and chronological sorting of audit logs; `Main` now gathers filter criteria and renders results.
- Added user lookup, existence, and registration-detail update operations to `UserService`; `Member`, `Librarian`, and `Main` no longer call repository methods directly for user lookup or write.
- Added `BookTransactionService.findTransactionById(...)` and routed member fine-history transaction lookups through the service rather than directly through `TransactionRepository`.
- Removed duplicate fine-status and amount checks from the librarian UI where `PaymentService`/`FineService` already enforce the business rules. The UI now collects input and reports service-level failure reasons.
- Kept user prompts and rendering in UI classes. Read-only presentation lookups (for example, resolving a member name to display a pending family request) go through `UserService`.

## Architecture boundary

`Admin.java`, `Librarian.java`, and `Member.java` should focus on menu navigation, input, and rendering. Business rules, eligibility checks, persistence, family-account linking, transaction selection, and reporting calculations are handled by services. `Main` retains application wiring and interactive prompts, while audit filtering is delegated to `AuditService`.

## Verification

- Compiled all Java sources successfully with `javac` using a temporary BCrypt stub solely to check Java syntax and project-internal type consistency. The stub was not included in the project ZIP and does not replace the real BCrypt dependency.
- A real dependency-resolved build and runtime test suite were not run. Run `mvn test` (or the project's configured build command) in an environment with the declared dependencies before treating this as release-ready.
