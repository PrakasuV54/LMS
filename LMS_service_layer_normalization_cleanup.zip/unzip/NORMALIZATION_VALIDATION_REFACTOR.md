# Normalization and Validation Refactor — Pass 2

## Approach

- No shared normalization helper class is used. `src/service/ServiceInput.java` was removed.
- Public service methods normalize raw string inputs at their boundary when normalization is required.
- Internal methods receive canonical values and avoid repeating the same transformation.
- Validation of an input is not repeated solely because it is passed to an internal method.
- Business-state and authorization checks remain at the operation that reads or changes state. UI preflight/failure-reason methods are not treated as substitutes for enforcing a rule during the actual operation.
- Passwords are not trimmed or case-normalized.

## Changes in this pass

- Removed `ServiceInput.java` and replaced its usage with straightforward local normalization in `UserService`, `AuthService`, `MembershipPlanService`, and `BookTransactionService`.
- Kept request-by-ISBN and request-by-book-ID flows on a shared internal request path, so the phone is normalized at the public entry point rather than again in the internal workflow.
- Refactored cancellation by phone/ISBN to pass the normalized phone and resolved book into an internal method instead of re-normalizing them in the transaction-selection flow.
- Reused normalized phone values in several `FamilyAccountService` and `FineService` workflows instead of calling `trim()` repeatedly within the same method.
- Preserved contextual authorization, active membership, loan/request state, and other business checks.

## Scope note

This is a targeted cleanup of the most obvious service-layer duplication, not a claim that every repeated trim or validation across every service, model, repository, and UI class has been removed. Some methods are separate public entry points and must independently validate their own raw input. Some model/repository defensive behavior remains because the migration of every caller and the data-integrity consequences have not been exhaustively regression-tested. Further cleanup should continue method-by-method with workflow tests, rather than deleting checks globally.

## Verification

- All Java source files compiled with `javac -Xlint:all` using a temporary BCrypt API stub. Compilation succeeded with one warning in `src/model/Book.java` about possible `this` escape during construction.
- Application startup/exit smoke test passed (`ui.Main`, selecting Exit).
- Maven build and real BCrypt integration were not verified because Maven and the real dependency were unavailable in this environment.
- No automated test suite was present in the source archive; this compile/smoke test is not proof of every workflow.
