# Authorization and use-case simplification

## Changes made

- Removed `canAccessAccount()` entirely from the project.
- Removed member self-service authorization wrappers that only delegated to another method.
- Membership activation, membership renewal, active-membership lookup, currently borrowed books, borrowing history, and issued-loan lookup now use the target member phone supplied by the UI workflow, without an extra owner-or-staff helper check.
- Updated `Member` UI to call the direct service methods.
- Fine lookups no longer use `canAccessAccount()`. They retain direct owner-phone comparison for member access and staff authorization for staff-wide queries.
- Retained role checks for genuinely staff-only operations: inventory changes, issuing/returning books, and suspending/reactivating memberships.
- Admin and librarian already share the same implementations for common staff workflows: `Admin` delegates those menu options to the handlers in `Librarian`. Those handlers were not duplicated.

## Verification

- Compiled all Java source files with `javac -Xlint:all` using a temporary BCrypt API stub because the real BCrypt dependency/Maven build was unavailable in this environment.
- Compilation passed. One existing warning remains in `model/Book.java:44` about possible `this` escape during construction.
- This is compile verification only; no runtime or integration tests were run.

## Design boundary

The member-facing console workflow supplies the current operation member's phone. Since the `canAccessAccount()` helper has been removed as requested, service methods that accept a target phone rely on the caller/UI workflow to choose the correct member except where staff-only permissions or fine ownership are explicitly checked. If these services are later exposed through an API, authorization should be enforced at the API/service boundary.
