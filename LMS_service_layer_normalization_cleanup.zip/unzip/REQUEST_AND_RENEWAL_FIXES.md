# Request and Renewal Workflow Corrections

## Source used
- The request-book UI method was copied from `LMS-master/src/ui/Member.java` as requested. No other source from the master archive was merged.
- The current project was otherwise retained and changes were made only to its `src` Java files, plus this note.

## Request-book behavior
- Restored the master workflow: use `PolicyService.getBorrowingEligibilityFailureReasons()` for eligibility preflight.
- If the service returns `null`, show the master's concise failure message for an existing request/loan or a request that could not be saved.
- `BookTransactionService.requestBook()` now returns `null` for an existing active transaction rather than throwing an uncaught `IllegalStateException`, matching the master request flow.

## Renewal behavior
- The member UI looks up issued books for the currently selected/logged-in member and only renews a matching book that is currently issued.
- Removed any owner-or-staff check from the renewal eligibility path.
- `getRenewFailureReason()` verifies the transaction is issued, the loan has not already been renewed, and its associated copy is recorded as ISSUED for the same book.
- `renewBook()` repeats the critical renewal-limit and copy-state checks before mutation.
- `Transaction.renew()` records the first renewal and rejects subsequent renewals.

## Verification
- `javac -Xlint:all` compiled all 73 Java source files successfully using a temporary BCrypt API stub.
- One existing warning remains in `model/Book.java` about a possible `this` escape during construction.
- Real BCrypt/Maven build and runtime/integration tests were not run in this environment.
