package ui;
import model.*;
import enums.*;
import service.AnalyticsService;
import service.AuthService;
import service.BookService;
import service.BookTransactionService;

import java.util.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.YearMonth;

import repository.*;
import service.*;
import authentication.*;
import paymentStrategy.*;

import  repository.SyntheticData.*;

public class Main {

    static Scanner sc = new Scanner(System.in);
    static User currentUser = null;

    public static int readInt() {
        while (true) {
            String line = sc.nextLine().trim();
            if (line.isEmpty()) continue;
            try {
                return Integer.parseInt(line);
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a valid number:");
            }
        }
    }

    public static double readDouble() {
        while (true) {
            String line = sc.nextLine().trim();
            if (line.isEmpty()) continue;
            try {
                return Double.parseDouble(line);
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a valid amount:");
            }
        }
    }



    public static boolean isBackCommand(String input) {
        if (input == null) return false;
        String t = input.trim();
        return t.equalsIgnoreCase("back");
    }

    public static boolean isHomeCommand(String input) {
        if (input == null) return false;
        String t = input.trim();
        return t.equalsIgnoreCase("home");
    }

    public static void goHome() {
        throw new GoHomeException();
    }

    public static void main(String[] args) {
        SyntheticData data = new SyntheticData(userRepository, membershipPlanRepository, bookService,
                authorRepository, genreRepository, membershipRepository, transactionRepository, fineRepository,
                paymentRepository, auditLogRepository, categoryRepository, bookCopyRepository);
        data.syntheticData();
        while (true) {
            try {
                System.out.println("\nSelect User");
                System.out.println("1.Member");
                System.out.println("2.Librarian");
                System.out.println("3.Admin");
                System.out.println("4.Exit");
                System.out.println();
                int userChoice = readInt();
                switch (userChoice) {
                    case 1:
                        Member.member();
                        break;
                    case 2:
                        if (staffLogin(UserRole.LIBRARIAN)) {
                            if (currentUser != null && currentUser.getRole() == UserRole.ADMIN) {
                                Admin.admin();
                            } else {
                                Librarian.librarian();
                            }
                        }
                        break;
                    case 3:
                        if (staffLogin(UserRole.ADMIN)) {
                            Admin.admin();
                        }
                        break;
                    case 4:
                        System.out.println("Exiting Library Management System. Goodbye!");
                        return;
                    default:
                        System.out.println("Invalid Choice");
                }
            } catch (GoHomeException e) {
                // Return to initial user-selection menu
            }
        }
    }

    public static void handleViewAuditLogs() {
        UserRole roleFilter = null;
        Integer selectedYear = null;
        Integer selectedMonth = null;

        displayAuditRecords(getFilteredAuditLogs(selectedYear, selectedMonth, roleFilter));

        while (true) {
            System.out.println("\nAudit Logs");
            System.out.println("1. Filter by role");
            System.out.println("2. Filter by year");
            if (selectedYear != null) {
                System.out.println("3. Filter by month");
                System.out.println("4. Clear filters");
                System.out.println("5. Back");
                System.out.println("0. Go to Home");
            } else {
                System.out.println("3. Clear filters");
                System.out.println("4. Back");
                System.out.println("0. Go to Home");
            }
            System.out.println("Enter choice:");
            int choice = readInt();
            if (choice == 0) {
                goHome();
            }
            if ((selectedYear != null && choice == 5) || (selectedYear == null && choice == 4)) {
                return;
            }

            if (choice == 1) {
                System.out.println("Role: 1.Member  2.Librarian  3.Admin");
                int roleChoice = readInt();
                if (roleChoice < 1 || roleChoice > 3) {
                    System.out.println("Invalid role.");
                    continue;
                }
                roleFilter = roleChoice == 1 ? UserRole.MEMBER
                        : roleChoice == 2 ? UserRole.LIBRARIAN : UserRole.ADMIN;
                displayAuditRecords(getFilteredAuditLogs(selectedYear, selectedMonth, roleFilter));
            } else if (choice == 2) {
                while (true) {
                    System.out.println("Year (YYYY):");
                    String line = sc.nextLine().trim();
                    if (isBackCommand(line) || line.equals("0")) {
                        break;
                    }
                    try {
                        int year = Integer.parseInt(line);
                        if (year < 1900 || year > 2100) {
                            System.out.println("Invalid year. Please enter a valid 4-digit year:");
                            continue;
                        }
                        selectedYear = year;
                        selectedMonth = null;
                        displayAuditRecords(getFilteredAuditLogs(selectedYear, selectedMonth, roleFilter));
                        break;
                    } catch (NumberFormatException e) {
                        System.out.println("Invalid year. Please enter a valid 4-digit year:");
                    }
                }
            } else if (selectedYear != null && choice == 3) {
                while (true) {
                    System.out.println("Select Month:");
                    for (int i = 0; i < AnalyticsDashboard.MONTH_NAMES.length; i++) {
                        System.out.println((i + 1) + ". " + AnalyticsDashboard.MONTH_NAMES[i]);
                    }
                    System.out.println("Enter month (1-12) (0 to cancel):");
                    int monthChoice = readInt();
                    if (monthChoice == 0) {
                        break;
                    }
                    if (monthChoice < 1 || monthChoice > 12) {
                        System.out.println("Invalid month. Please enter a number between 1 and 12:");
                        continue;
                    }
                    selectedMonth = monthChoice;
                    displayAuditRecords(getFilteredAuditLogs(selectedYear, selectedMonth, roleFilter));
                    break;
                }
            } else if ((selectedYear != null && choice == 4) || (selectedYear == null && choice == 3)) {
                roleFilter = null;
                selectedYear = null;
                selectedMonth = null;
                displayAuditRecords(getFilteredAuditLogs(selectedYear, selectedMonth, roleFilter));
            } else {
                System.out.println("Invalid choice.");
            }
        }
    }

    private static List<Audit> getFilteredAuditLogs(Integer year, Integer month, UserRole role) {
        LocalDateTime start = null;
        LocalDateTime end = null;
        if (year != null) {
            if (month != null) {
                start = LocalDate.of(year, month, 1).atStartOfDay();
                end = YearMonth.of(year, month).plusMonths(1).atDay(1).atStartOfDay();
            } else {
                start = LocalDate.of(year, 1, 1).atStartOfDay();
                end = LocalDate.of(year + 1, 1, 1).atStartOfDay();
            }
        }
        return auditService.findFiltered(start, end, role);
    }

    private static void displayAuditRecords(List<Audit> filtered) {
        if (filtered == null || filtered.isEmpty()) {
            System.out.println("No audit records found.");
            return;
        }

        System.out.printf("%-7s %-20s %-12s %-18s %-20s %-19s %s%n",
                "ID", "Actor phone", "Role", "Action", "Entity", "Timestamp", "Details");
        for (Audit audit : filtered) {
            User actor = audit.getUserPhone() == null ? null : userService.findByPhone(audit.getUserPhone());
            String actorRole = actor == null ? "UNKNOWN" : actor.getRole().name();
            String entity = audit.getEntityType() + (audit.getEntityId() == null ? "" : "#" + audit.getEntityId());
            System.out.printf("%-7d %-20s %-12s %-18s %-20s %-19s %s%n",
                    audit.getAuditId(),
                    audit.getUserPhone() == null ? "-" : audit.getUserPhone(),
                    actorRole,
                    truncateAudit(audit.getAction(), 17),
                    truncateAudit(entity, 19),
                    audit.getTimestamp().toString().replace('T', ' '),
                    audit.getDetails() == null ? "-" : audit.getDetails());
        }
        System.out.println("Records: " + filtered.size());
    }

    private static String truncateAudit(String value, int maxLength) {
        if (value == null) return "-";
        return value.length() <= maxLength ? value : value.substring(0, maxLength - 1) + "…";
    }

    public static boolean staffLogin(UserRole requiredRole) {
        while (true) {
            System.out.println("Enter phone or email");
            String identifier = sc.nextLine().trim();
            if (isHomeCommand(identifier) || identifier.equals("0") || isBackCommand(identifier)) {
                return false;
            }
            if (identifier.isEmpty()) {
                System.out.println("Login Failed: Phone/Email cannot be empty. Please enter your credentials.");
                continue;
            }

            while (true) {
                System.out.println("Enter password");
                String password = sc.nextLine();
                if (isBackCommand(password)) {
                    break;
                }
                if (password.isEmpty()) {
                    System.out.println("Login Failed: Password cannot be empty. Please enter your credentials.");
                    continue;
                }

                User user = authService.login(identifier, password);
                if (user == null) {
                    User existing = userService.findByPhone(identifier);
                    if (existing == null) existing = userService.findByEmail(identifier);
                    if (existing != null && existing.getStatus() == UserStatus.INACTIVE) {
                        System.out.println("Login Failed: Your account has been deactivated. Please contact the administrator.");
                        return false;
                    } else {
                        System.out.println("Login Failed: Invalid credentials. Please check your phone/email and password.");
                    }
                    continue;
                }

                if (user.getStatus() != UserStatus.ACTIVE) {
                    currentUser = null;
                    System.out.println("Login Failed: Your account has been deactivated. Please contact the administrator.");
                    return false;
                }

                if (user.getRole() == UserRole.MEMBER) {
                    currentUser = null;
                    System.out.println("Login Failed: This account is registered as MEMBER. Please log in via the Member menu.");
                    return false;
                }

                if (requiredRole == UserRole.ADMIN && user.getRole() != UserRole.ADMIN) {
                    currentUser = null;
                    System.out.println("Login Failed: This account is registered as " + user.getRole() + ". Administrator privileges required.");
                    return false;
                }

                currentUser = user;
                System.out.println("Login successful");
                return true;
            }
        }
    }



    




    static DataStore dataStore = new DataStore();
    static UserRepository userRepository = new InMemoryUserRepository(dataStore);
    static AuthorRepository authorRepository = new InMemoryAuthorRepository(dataStore);
    static GenreRepository genreRepository = new InMemoryGenreRepository(dataStore);
    static BookRepository bookRepository = new InMemoryBookRepository(dataStore);
    static BookCopyRepository bookCopyRepository = new InMemoryBookCopyRepository(dataStore);
    static TransactionRepository transactionRepository = new InMemoryTransactionRepository(dataStore);
    static MembershipRepository membershipRepository = new InMemoryMembershipRepository(dataStore);
    static FineRepository fineRepository = new InMemoryFineRepository(dataStore);
    static PaymentRepository paymentRepository = new InMemoryPaymentRepository(dataStore);
    static MembershipPlanRepository membershipPlanRepository = new InMemoryMembershipPlanRepository(dataStore);
    static AuditLogRepository auditLogRepository = new InMemoryAuditLogRepository(dataStore);
    static CategoryRepository categoryRepository = new InMemoryCategoryRepository(dataStore);
    static AuditService auditService = new AuditService(auditLogRepository, userRepository);
    static NotificationService notificationService = new NotificationService();
    static PolicyService policyService = new PolicyService(userRepository, membershipRepository, transactionRepository, fineRepository, auditService, membershipPlanRepository);
    static FineService fineService = new FineService(fineRepository, transactionRepository, policyService, auditService);
    static UserService userService = new UserService(userRepository, auditService);
    static AuthService authService = new AuthService(userService, userRepository, new PasswordAuthentication(), auditService);
    static BookService bookService = new BookService(bookRepository, bookCopyRepository, transactionRepository,
            auditService, authorRepository, genreRepository);
    static BookTransactionService bookTransactionService = new BookTransactionService(bookRepository, bookCopyRepository, transactionRepository, policyService, auditService, notificationService, fineService, userRepository);
    static PaymentService paymentService = new PaymentService(paymentRepository, fineRepository, new Razorpay(), auditService, membershipRepository, transactionRepository);
    static MembershipPlanService membershipPlanService = new MembershipPlanService(membershipPlanRepository, userRepository);
    static MembershipService membershipService = new MembershipService(userRepository, membershipRepository, membershipPlanService, paymentRepository, new Razorpay(), auditService, notificationService);
    static AnalyticsService analyticsService = new AnalyticsService(bookRepository, transactionRepository, userRepository, paymentRepository, bookCopyRepository, membershipRepository, fineRepository, membershipPlanRepository);

}
