package ui;

import enums.PaymentMethod;
import enums.PaymentStatus;
import enums.TransactionStatus;
import enums.UserRole;
import enums.UserStatus;
import model.*;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import service.AuthService;
import java.util.*;

public class Member extends Main {



    public static void member() {
        System.out.println("1.Login or 2.Register or 3.Exit");
        int loginChoice = readInt();

        switch (loginChoice) {
            case 1: {
                User identifiedUser;
                String identifier;
                while (true) {
                    System.out.println("Enter Mobile or Email (0 to go back to user selection)");
                    identifier = sc.nextLine().trim();
                    if (identifier.equals("0")) return;

                    identifiedUser = findUserByIdentifier(identifier);
                    if (identifiedUser == null) {
                        System.out.println("No account found with that phone number or email. Please try again.");
                        continue;
                    }
                    break;
                }

                if (identifiedUser.getRole() != UserRole.MEMBER) {
                    System.out.println("This account is registered as " + identifiedUser.getRole()
                            + ". Please log in via the Librarian or Admin menu.");
                    break;
                }
                if (identifiedUser.getStatus() != UserStatus.ACTIVE) {
                    System.out.println("Login Failed: Your account has been deactivated. Please contact the librarian for reactivation.");
                    break;
                }

                User user;
                while (true) {
                    System.out.println("Enter Password (0 to go back to user selection)");
                    String loginPassword = sc.nextLine();
                    if (loginPassword.equals("0")) return;

                    user = authService.login(identifier, loginPassword);
                    if (user != null) break;
                    System.out.println("Incorrect password. Please enter your password again, or enter 0 to go back.");
                }

                currentUser = user;
                System.out.println("Login Success");
                memberMenu();
                break;
            }

            case 2:
                registerMember();
                break;

            case 3:
                return;

            default:
                System.out.println("Invalid Input");
        }
    }

    private static String readRegistrationValue(String prompt) {
        System.out.println(prompt + " (0 to cancel registration)");
        String value = sc.nextLine().trim();
        return value.equals("0") ? null : value;
    }

    private static void registerMember() {
        String name = readRegistrationValue("Enter your name");
        if (name == null) {
            System.out.println("Registration cancelled.");
            return;
        }
        if (name.isEmpty()) {
            System.out.println("Registration failed: Name cannot be empty.");
            return;
        }

        String phone = readRegistrationValue("Enter your phone number");
        if (phone == null) {
            System.out.println("Registration cancelled.");
            return;
        }
        if (!phone.matches("\\d{10}")) {
            System.out.println("Registration failed: Phone number must be a valid 10-digit number.");
            return;
        }
        if (userService.phoneExists(phone)) {
            System.out.println("Registration failed: An account with phone number " + phone + " already exists. Please log in or use a different phone number.");
            return;
        }

        String email = readRegistrationValue("Enter your email");
        if (email == null) {
            System.out.println("Registration cancelled.");
            return;
        }
        if (!email.matches("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$")) {
            System.out.println("Registration failed: Invalid email format. Please provide a valid email address (e.g. user@example.com).");
            return;
        }
        if (userService.emailExists(email)) {
            System.out.println("Registration failed: An account with email address " + email + " already exists. Please log in or use a different email address.");
            return;
        }

        String ageInput = readRegistrationValue("Enter your age");
        if (ageInput == null) {
            System.out.println("Registration cancelled.");
            return;
        }
        int age;
        try {
            age = Integer.parseInt(ageInput);
        } catch (NumberFormatException ex) {
            System.out.println("Registration failed: Enter a valid age.");
            return;
        }
        if (age < 1 || age > 120) {
            System.out.println("Registration failed: Age must be between 1 and 120.");
            return;
        }

        System.out.println("Select your gender (0 to cancel registration):");
        System.out.println("1. MALE");
        System.out.println("2. FEMALE");
        System.out.println("3. NON_BINARY");
        System.out.println("4. OTHER");
        System.out.println("5. PREFER_NOT_TO_SAY");
        String genderInput = sc.nextLine().trim();
        if (genderInput.equals("0")) {
            System.out.println("Registration cancelled.");
            return;
        }
        int genderChoice;
        try {
            genderChoice = Integer.parseInt(genderInput);
        } catch (NumberFormatException ex) {
            System.out.println("Registration failed: Choose a valid gender option.");
            return;
        }
        String gender;
        switch (genderChoice) {
            case 1: gender = "MALE"; break;
            case 2: gender = "FEMALE"; break;
            case 3: gender = "NON_BINARY"; break;
            case 4: gender = "OTHER"; break;
            case 5: gender = "PREFER_NOT_TO_SAY"; break;
            default:
                System.out.println("Registration failed: Choose a valid gender option.");
                return;
        }

        String registerPassword;
        while (true) {
            System.out.println("Enter your password (0 to cancel registration)");
            registerPassword = sc.nextLine();
            if (registerPassword.equals("0")) {
                System.out.println("Registration cancelled.");
                return;
            }

            String regReason = userService.getRegistrationFailureReason(name, email, phone, registerPassword);
            if (regReason != null) {
                System.out.println("Registration failed: " + regReason);
                System.out.println("Please enter your password again.");
                continue;
            }

            System.out.println("Enter your password again (0 to cancel registration)");
            String confirmPassword = sc.nextLine();
            if (confirmPassword.equals("0")) {
                System.out.println("Registration cancelled.");
                return;
            }
            if (!registerPassword.equals(confirmPassword)) {
                System.out.println("Passwords do not match. Please enter your password again.");
                continue;
            }
            break;
        }

        authService.register(name, email, phone, registerPassword);
        System.out.println("Registration successful. Your account and profile details have been saved.");
    }

    public static void memberMenu() {
        while (true) {
            System.out.println("\n1.View All Books");
            System.out.println("2.Search Books");
            System.out.println("3.Request Book");
            System.out.println("4.Cancel Request");
            System.out.println("5.Renew Book");
            System.out.println("6.Activate Membership");
            System.out.println("7.Renew Membership");
            System.out.println("8.View Currently Rented Books");
            System.out.println("9.View Borrowing History");
            System.out.println("10.Manage Fines");
            System.out.println("11.Update Profile");
            System.out.println("12.Logout");
            System.out.println("Enter Your Choice");

            int choice = readInt();

            try {
                switch (choice) {
                    case 1:
                        handleViewAllBooks();
                        break;
                    case 2:
                        handleSearchBooks();
                        break;
                    case 3:
                        handleRequestBook();
                        break;
                    case 4:
                        handleCancelRequest();
                        break;
                    case 5:
                        handleRenewBook();
                        break;
                    case 6:
                        handleActivateMembership();
                        break;
                    case 7:
                        handleRenewMembership();
                        break;
                    case 8:
                        handleViewCurrentlyRentedBooks();
                        break;
                    case 9:
                        handleViewBorrowingHistory();
                        break;
                    case 10:
                        handleManageFines();
                        break;
                    case 11:
                        handleUpdateProfile();
                        break;
                    case 12:
                        currentUser = null;
                        System.out.println("Logged out successfully");
                        return;
                    default:
                        System.out.println("Invalid Choice");
                }
            } catch (RuntimeException e) {
                if (e != GO_HOME) throw e;
            }
        }
    }

    public static void handleViewAllBooks() {
        List<Book> allBooks = new ArrayList<>();
        for (Book book : bookService.getAllBooks()) {
            if (book.getStatus() == enums.BookStatus.ACTIVE) {
                allBooks.add(book);
            }
        }
        if (allBooks.isEmpty()) {
            System.out.println("No active books found.");
            return;
        }
        UiHelpers.handleBookListInteraction(allBooks);
    }

    public static void handleSearchBooks() {
        UiHelpers.searchBooks();
    }

    public static void handleRequestBook() {
        while (true) {
            System.out.println("\n--- Request a Book ---");
            System.out.println("1. Request directly by ISBN");
            System.out.println("2. Search books and request from results");
            System.out.println("3. Browse catalogue and request a book");
            System.out.println("4. Back");
            System.out.println("0. Go to Home");
            System.out.println("Enter choice:");
            int choice = readInt();
            if (choice == 0) goHome();
            switch (choice) {
                case 1:
                    System.out.println("Enter ISBN (0 to cancel):");
                    String requestIsbn = sc.nextLine().trim();
                    if (requestIsbn.equals("0")) break;
                    submitBookRequestByIsbn(requestIsbn);
                    break;
                case 2:
                    UiHelpers.searchBooks();
                    break;
                case 3:
                    List<Book> allBooks = bookService.getAllBooks();
                    if (allBooks.isEmpty()) System.out.println("The catalogue is empty.");
                    else UiHelpers.handleBookListInteraction(allBooks);
                    break;
                case 4:
                    return;
                default:
                    System.out.println("Invalid choice. Select 1-4.");
            }
        }
    }

    public static void requestBookForSelectedBook(Book book) {
        if (book == null || currentUser == null) {
            submitBookRequest(book);
            return;
        }
        if (currentUser.getRole() != UserRole.MEMBER && operationTargetUser == null) {
            runForTargetMember(() -> submitBookRequest(book));
        } else {
            submitBookRequest(book);
        }
    }

    private static void submitBookRequest(Book book) {
        submitBookRequestByIsbn(book == null ? null : book.getIsbn());
    }

    private static void submitBookRequestByIsbn(String isbn) {
        User requestingMember = getOperationUser();
        Transaction requested;
        try {
            requested = bookTransactionService.requestBookByIsbn(
                    requestingMember == null ? null : requestingMember.getPhone(), isbn, currentUser);
        } catch (IllegalStateException e) {
            List<String> reasons = java.util.Arrays.asList(e.getMessage().split("\\n- "));
            System.out.println("Cannot request this book"
                    + (requestingMember == null ? "" : " for " + requestingMember.getName()) + ":");
            for (String reason : reasons) System.out.println("- " + reason);
            String advice = policyService.getBorrowingResolutionAdvice(reasons);
            if (!advice.isEmpty()) System.out.println("\n" + advice);
            return;
        }
        Book requestedBook =  bookService.getBookByIsbn(isbn);
        if (requested != null) {
            System.out.println("Book request submitted successfully.");
            System.out.println("Book: " + requestedBook.getTitle() + " | ISBN: " + requestedBook.getIsbn());
            System.out.println("Member: " + requestingMember.getName());
            System.out.println("Request status: " + requested.getStatus());
        }
    }

    public static void handleCancelRequest() {
        User targetMember = getOperationUser();
        if (targetMember == null) {
            System.out.println("A valid member account is required to cancel a request.");
            return;
        }

        List<Transaction> history = bookTransactionService.getBorrowingHistory(targetMember.getPhone());
        List<Transaction> cancellableRequests = new ArrayList<>();
        for (Transaction transaction : history) {
            TransactionStatus status = transaction.getStatus();
            if (status == TransactionStatus.REQUESTED
                    || status == TransactionStatus.RESERVED
                    || status == TransactionStatus.READY_FOR_PICKUP) {
                cancellableRequests.add(transaction);
            }
        }

        if (cancellableRequests.isEmpty()) {
            System.out.println("You have no book requests that can be cancelled.");
            return;
        }

        System.out.println("Book requests that can be cancelled:");
        for (int i = 0; i < cancellableRequests.size(); i++) {
            Transaction transaction = cancellableRequests.get(i);
            Book requestedBook = bookService.getBookById(transaction.getBookId());
            System.out.println((i + 1) + ". "
                    + "Title: " + (requestedBook == null ? "Unavailable" : requestedBook.getTitle())
                    + " | ISBN: " + (requestedBook == null ? "Unavailable" : requestedBook.getIsbn())
                    + " | Status: " + transaction.getStatus()
                    + " | Transaction ID: " + transaction.getTransactionId());
        }

        System.out.println("Enter the ISBN of the request you want to cancel");
        String cancelIsbn = sc.nextLine().trim();
        boolean listedIsbn = false;
        for (Transaction transaction : cancellableRequests) {
            Book requestedBook = bookService.getBookById(transaction.getBookId());
            if (requestedBook != null && requestedBook.getIsbn().equalsIgnoreCase(cancelIsbn)) {
                listedIsbn = true;
                break;
            }
        }
        if (!listedIsbn) {
            System.out.println("Please enter an ISBN from the list of cancellable requests.");
            return;
        }

        try {
            bookTransactionService.cancelRequest(targetMember.getPhone(), cancelIsbn, currentUser);
            System.out.println("Request cancelled successfully");
        } catch (IllegalStateException ex) {
            System.out.println("Cancellation failed:");
            for (String reason : ex.getMessage().split("\\R- ")) {
                System.out.println("- " + reason);
            }
        }
    }

    public static void handleRenewBook() {
        System.out.println("Enter ISBN to renew");
        String renewIsbn = sc.nextLine().trim();
        User targetMember = getOperationUser();
        try {
            if (bookTransactionService.renewBook(
                    targetMember == null ? null : targetMember.getPhone(), renewIsbn, currentUser)) {
                System.out.println("Book renewed successfully");
            } else {
                System.out.println("Renewal failed: Unable to renew loan. Please contact library staff.");
            }
        } catch (IllegalStateException ex) {
            System.out.println("Renewal failed:");
            for (String reason : ex.getMessage().split("\\R- ")) {
                System.out.println("- " + reason);
            }
        }
    }

    public static void handleActivateMembership() {
        User operationUser = getOperationUser();
        if (operationUser == null) {
            System.out.println("Membership activation failed: A valid logged-in member account is required.");
            return;
        }

        Membership existingMembership = membershipService.getActiveMembership(operationUser.getPhone());
        if (existingMembership != null
                && (existingMembership.getEndDate() == null
                || !LocalDate.now().isAfter(existingMembership.getEndDate()))) {
            System.out.println("You already have an active membership. Please use Renew Membership instead.");
            return;
        }

        List<MembershipPlan> plans = membershipPlanService.getAllPlans();
        if (plans.isEmpty()) {
            System.out.println("No membership plans available");
            return;
        }

        for (MembershipPlan plan : plans) {
            System.out.println(plan.getPlanId() + ". " + plan.getPlanName()
                    + " - Rs." + plan.getAmount());
        }

        System.out.println("Enter Plan ID");
        int planId = readInt();
        MembershipPlan selectedPlan = membershipPlanService.findById(planId);
        System.out.println("Enter duration in months");
        int duration = readInt();

        if (selectedPlan != null) {
            double totalCost = selectedPlan.getAmount() * duration;
            System.out.println("Selected Plan: " + selectedPlan.getPlanName());
            System.out.println("Monthly Price: ₹" + selectedPlan.getAmount());
            System.out.println("Duration: " + duration + " months");
            System.out.println("Total Amount: ₹" + totalCost);
        }

        PaymentMethod membershipMethod = UiHelpers.choosePaymentMethod();
        if (membershipMethod == null) {
            return;
        }

        try {
            membershipService.purchaseMembership(
                    operationUser.getPhone(), planId, duration, membershipMethod);
        } catch (IllegalArgumentException ex) {
            System.out.println("Membership activation failed:");
            for (String reason : ex.getMessage().split("\\R")) {
                if (!reason.isBlank()) {
                    System.out.println("- " + reason);
                }
            }
            return;
        }


            Membership activeMem = membershipService.getActiveMembership(operationUser.getPhone());
            System.out.println("Payment Status: SUCCESS");
            System.out.println("Membership Status: " + (activeMem != null ? activeMem.getStatus() : "Unable to reload membership status"));
            if (activeMem != null && activeMem.getEndDate() != null) {
                System.out.println("Membership Expiry Date: " + activeMem.getEndDate());
            }
            System.out.println("Membership activated successfully");

    }

    public static void handleRenewMembership() {
        User operationUser = getOperationUser();
        if (operationUser == null) {
            System.out.println("Membership renewal failed: A valid logged-in member account is required.");
            return;
        }

        Membership currentMembership = membershipService.getActiveMembership(operationUser.getPhone());
        if (currentMembership == null) {
            System.out.println("You do not have an active membership to renew. Please use Activate Membership.");
            return;
        }

        MembershipPlan currentPlan = membershipPlanService.findById(currentMembership.getPlanId());
        System.out.println("You already have an active membership.");
        System.out.println("Current Plan: " + (currentPlan == null ? "Unknown" : currentPlan.getPlanName()));
        System.out.println("Current Membership Expiry: " + currentMembership.getEndDate());
        System.out.println("Renewal duration will be added after the current membership period ends.");
        System.out.println("If you select a different plan, it will become active only after the current plan ends.");

        List<MembershipPlan> renewalPlans = membershipPlanService.getAllPlans();
        if (renewalPlans.isEmpty()) {
            System.out.println("No membership plans available");
            return;
        }

        for (MembershipPlan plan : renewalPlans) {
            System.out.println(plan.getPlanId() + ". " + plan.getPlanName()
                    + " - Rs." + plan.getAmount());
        }

        System.out.println("Enter Plan ID");
        int renewalPlanId = readInt();
        MembershipPlan selectedRenewalPlan = membershipPlanService.findById(renewalPlanId);

        System.out.println("Enter duration in months");
        int renewalDuration = readInt();

        if (selectedRenewalPlan != null) {
            double renewalTotalCost = selectedRenewalPlan.getAmount() * renewalDuration;
            System.out.println("Selected Plan: " + selectedRenewalPlan.getPlanName());
            System.out.println("Monthly Price: ₹" + selectedRenewalPlan.getAmount());
            System.out.println("Duration: " + renewalDuration + " months");
            System.out.println("Total Amount: ₹" + renewalTotalCost);
        }

        PaymentMethod renewalMethod = UiHelpers.choosePaymentMethod();
        if (renewalMethod == null) {
            return;
        }


        try {
            membershipService.renewMembership(operationUser.getPhone(), renewalPlanId, renewalDuration, renewalMethod);
        } catch (IllegalArgumentException ex) {
            System.out.println("Membership renewal failed:");
            for (String reason : ex.getMessage().split("\\R")) {
                if (!reason.isBlank()) {
                    System.out.println("- " + reason);
                }
            }
            return;
        }

            Membership activeMem = membershipService.getActiveMembership(operationUser.getPhone());
            System.out.println("Payment Status: SUCCESS");
            System.out.println("Membership Status: " + (activeMem != null ? activeMem.getStatus() : "Unable to reload membership status"));
            if (activeMem != null && activeMem.getEndDate() != null) {
                System.out.println("Membership Expiry Date: " + activeMem.getEndDate());
            }
            if (activeMem != null && activeMem.getPendingPlanId() > 0
                    && activeMem.getPendingPlanStartDate() != null
                    && LocalDate.now().isBefore(activeMem.getPendingPlanStartDate())) {
                MembershipPlan pendingPlan = membershipPlanService.findById(activeMem.getPendingPlanId());
                System.out.println("Next Plan: " + (pendingPlan == null ? "Unknown" : pendingPlan.getPlanName()));
                System.out.println("Next Plan Activation Date: " + activeMem.getPendingPlanStartDate());
                System.out.println("Your current plan remains active until its existing period ends.");
            }
            System.out.println("Membership renewed successfully");

    }

        public static void handleViewCurrentlyRentedBooks() {
        List<Transaction> borrowed =
                bookTransactionService.getCurrentlyBorrowedBooks(getOperationUser().getPhone());
        if (borrowed.isEmpty()) {
            System.out.println("You have no currently issued books");
            return;
        }

        for (Transaction t : borrowed) {
            Book borrowedBook = bookService.getBookById(t.getBookId());
            if (borrowedBook != null) {
                System.out.println("ISBN: " + borrowedBook.getIsbn());
                System.out.println("Title: " + borrowedBook.getTitle());
                System.out.println("Status: " + t.getStatus());
                System.out.println("Due Date: " + t.getDueDate());
                System.out.println("--------------------");
            }
        }
    }

    public static void handleViewBorrowingHistory() {
        List<Transaction> history =
                bookTransactionService.getBorrowingHistory(getOperationUser().getPhone());
        if (history.isEmpty()) {
            System.out.println("No borrowing history found");
            return;
        }

        for (Transaction t : history) {
            Book historyBook = bookService.getBookById(t.getBookId());
            if (historyBook != null) {
                System.out.println("ISBN: " + historyBook.getIsbn());
                System.out.println("Title: " + historyBook.getTitle());
                System.out.println("Status: " + t.getStatus());
                System.out.println("Request Date: " + t.getRequestDate());
                System.out.println("Due Date: " + t.getDueDate());
                System.out.println("--------------------");
            }
        }
    }

    public static void handleManageFines() {
        List<Fine> fineHistory = fineService.getFineHistory(getOperationUser().getPhone(), currentUser);
        if (fineHistory.isEmpty()) {
            System.out.println("No fines found");
            return;
        }

        List<Fine> outstandingFines = fineService.findOutstandingFines(getOperationUser().getPhone());
        for (int i = 0; i < fineHistory.size(); i++) {
            Fine fine = fineHistory.get(i);
            Transaction fineTransaction = bookTransactionService.findTransactionById(fine.getTransactionId());
            Book fineBook = fineTransaction == null ? null
                    : bookService.getBookById(fineTransaction.getBookId());

            System.out.println((i + 1) + ". ISBN: "
                    + (fineBook == null ? "Unavailable" : fineBook.getIsbn())
                    + ", Type: " + fine.getType()
                    + ", Amount: Rs." + fine.getAmount()
                    + ", Paid: Rs." + fine.getAmountPaid()
                    + ", Remaining: Rs." + fine.getRemainingAmount()
                    + ", Status: " + fine.getStatus());
        }

        if (outstandingFines.isEmpty()) {
            System.out.println("No outstanding fines to pay");
            return;
        }

        System.out.println("Enter the ISBN for the fine you want to pay");
        String fineIsbn = sc.nextLine().trim();
        if (fineIsbn.isEmpty()) {
            System.out.println("ISBN cannot be empty");
            return;
        }

        Fine activeFine= null;
        for (Fine fine : outstandingFines) {
            Transaction t = bookTransactionService.findTransactionById(fine.getTransactionId());
            Book fineBook = t == null ? null : bookService.getBookById(t.getBookId());
            if (fineBook != null && fineBook.getIsbn().equalsIgnoreCase(fineIsbn)) {
                activeFine=fine;
                break;
            }
        }

        if (activeFine==null) {
            System.out.println("No outstanding fine found for ISBN: " + fineIsbn);
            return;
        }



        System.out.println("Remaining amount: Rs." + activeFine.getRemainingAmount());
        System.out.println("Enter amount to pay");
        String amountInput = sc.nextLine().trim();
        double amount;
        try {
            amount = Double.parseDouble(amountInput);
        } catch (NumberFormatException ex) {
            System.out.println("Invalid payment amount: Enter a numeric amount, for example 100 or 100.50.");
            return;
        }
        if (!Double.isFinite(amount)) {
            System.out.println("Invalid payment amount: Enter a valid finite amount.");
            return;
        }
        if (amount <= 0) {
            System.out.println("Invalid payment amount: Amount must be greater than zero.");
            return;
        }
        if (amount > activeFine.getRemainingAmount()) {
            System.out.println("Invalid payment amount: Rs." + amount + " exceeds the remaining fine balance of Rs." + activeFine.getRemainingAmount() + ".");
            return;
        }

        PaymentMethod fineMethod = UiHelpers.choosePaymentMethod();
        if (fineMethod == null) {
            System.out.println("Payment method not found");
            return;
        }

        Payment payment = paymentService.payFine(getOperationUser().getPhone(),
                    activeFine.getFineId(), amount, fineMethod);

        if (payment != null && payment.getStatus() == PaymentStatus.SUCCESS) {
            System.out.println("Fine payment successful");
        } else if (payment != null && payment.getStatus() == PaymentStatus.FAILED) {
            System.out.println("Fine payment failed: The payment gateway did not complete the transaction. Please verify your fine balance before trying again.");
        }
    }

    public static void handleUpdateProfile() {
        System.out.println("1.Update Name");
        System.out.println("2.Update Email");
        System.out.println("3.Update Phone");
        System.out.println("4.Change Password");
        System.out.println("5.Back");
        System.out.println("Enter choice");
        int profileChoice = readInt();

        switch (profileChoice) {
            case 1:
                System.out.println("Enter new name");
                String newName = sc.nextLine().trim();
                if (newName.isEmpty()) {
                    System.out.println("Name cannot be empty");
                } else if (newName.equals(currentUser.getName())) {
                    System.out.println("Unable to update name: New name is identical to your current name.");
                } else if (userService.updateNameForPhone(newName, getOperationUser().getPhone())) {
                    System.out.println("Name updated successfully");
                } else {
                    System.out.println("User not found.");
                }
                break;

            case 2:
                System.out.println("Enter new email");
                String newEmail = sc.nextLine().trim();
                if (!newEmail.matches("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$")) {
                    System.out.println("Invalid email format. Please enter a valid email address (e.g., user@example.com).");
                } else if (newEmail.equalsIgnoreCase(currentUser.getEmail())) {
                    System.out.println("Unable to update email: New email is identical to your current email.");
                } else if (userService.findByEmail(newEmail) != null) {
                    System.out.println("Unable to update email: The email address '" + newEmail + "' is already registered to another account.");
                } else if (userService.changeEmailForPhone(newEmail, getOperationUser().getPhone())) {
                    System.out.println("Email updated successfully");
                } else {
                    System.out.println("Unable to update email: User not found.");
                }
                break;

            case 3:
                System.out.println("Enter new phone number");
                String newPhone = sc.nextLine().trim();
                if (!newPhone.matches("\\d{10}")) {
                    System.out.println("Enter a valid 10-digit phone number");
                } else if (newPhone.equals(currentUser.getPhone())) {
                    System.out.println("Unable to update phone: New phone number is identical to your current phone number.");
                } else if (userService.findByPhone(newPhone) != null) {
                    System.out.println("Unable to update phone: The phone number '" + newPhone + "' is already registered to another account.");
                } else if (userService.changePhoneForPhone(currentUser.getPhone(), newPhone)) {
                    System.out.println("Phone updated successfully");
                } else {
                    System.out.println("Unable to update phone: User not found.");
                }
                break;

            case 4:
                System.out.println("Enter current password");
                String oldPassword = sc.nextLine();
                System.out.println("Enter new password");
                String newPassword = sc.nextLine();
                if (!isValidPassword(newPassword)) {
                    System.out.println("Password must be at least 8 characters and include an uppercase letter, a number, and a special character.");
                } else if (!AuthService.verifyPassword(oldPassword, currentUser.getPasswordHash())) {
                    System.out.println("Password change failed: Current password is incorrect.");
                } else if (AuthService.verifyPassword(newPassword, currentUser.getPasswordHash())) {
                    System.out.println("Password change failed: New password cannot be the same as your current password.");
                } else if (userService.changePasswordForPhone(
                        getOperationUser().getPhone(), oldPassword, newPassword)) {
                    System.out.println("Password changed successfully");
                } else {
                    System.out.println("Password change failed: User not found.");
                }
                break;

            case 5:
                break;

            default:
                System.out.println("Invalid choice");
        }
    }
    private static boolean isValidPassword(String password) {
        return password != null && password.length() >= 8
                && password.matches(".*[A-Z].*")
                && password.matches(".*\\d.*")
                && password.matches(".*[^A-Za-z0-9].*");
    }

    public static void runForTargetMember(Runnable operation) {
        if (currentUser == null || operation == null) {
            System.out.println("Please log in before performing this operation.");
            return;
        }
        System.out.println("Enter the member's phone number or email (0 to cancel):");
        String identifier = sc.nextLine().trim();
        if (identifier.isEmpty() || identifier.equals("0")) return;

        User target = userService.findByPhone(identifier);
        if (target == null && identifier.contains("@")) {
            target = userService.findByEmail(identifier);
        }
        if (target == null) {
            System.out.println("No account found for that phone number or email.");
            return;
        }
        if (target.getRole() != UserRole.MEMBER) {
            System.out.println("This operation is for member accounts only. The selected account is " + target.getRole() + ".");
            return;
        }
        if (target.getStatus() != UserStatus.ACTIVE) {
            System.out.println("This member account is not active. Activate the account before continuing.");
            return;
        }

        operationTargetUser = target;
        try {
            System.out.println("Selected member: " + target.getName() + " | Phone: " + target.getPhone() + " | Email: " + target.getEmail());
            operation.run();
        } finally {
            operationTargetUser = null;
        }
    }
    private static User operationTargetUser;

    private static User getOperationUser() {

        return operationTargetUser != null ? operationTargetUser : currentUser;
    }
}
