package repository;

import enums.*;
import model.*;
import service.AuthService;
import service.BookService;
import service.MembershipPlanService;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Objects;

public class SyntheticData {

    private final UserRepository userRepository;
    private final MembershipPlanRepository membershipPlanRepository;
    private final BookService bookService;
    private final AuthorRepository authorRepository;
    private final GenreRepository genreRepository;
    private final MembershipRepository membershipRepository;
    private final TransactionRepository transactionRepository;
    private final FineRepository fineRepository;
    private final PaymentRepository paymentRepository;
    private final AuditLogRepository auditLogRepository;
    private final BookCopyRepository bookCopyRepository;

    public SyntheticData(UserRepository userRepository, MembershipPlanRepository membershipPlanRepository, BookService bookService,
                         AuthorRepository authorRepository, GenreRepository genreRepository,
                         MembershipRepository membershipRepository, TransactionRepository transactionRepository,
                         FineRepository fineRepository, PaymentRepository paymentRepository,
                         AuditLogRepository auditLogRepository,
                         BookCopyRepository bookCopyRepository) {
        this.userRepository = Objects.requireNonNull(userRepository, "userRepository must not be null");
        this.membershipPlanRepository = Objects.requireNonNull(membershipPlanRepository, "membershipPlanRepository must not be null");
        this.bookService = Objects.requireNonNull(bookService, "bookService must not be null");
        this.authorRepository = Objects.requireNonNull(authorRepository, "authorRepository must not be null");
        this.genreRepository = Objects.requireNonNull(genreRepository, "genreRepository must not be null");
        this.membershipRepository = Objects.requireNonNull(membershipRepository, "membershipRepository must not be null");
        this.transactionRepository = Objects.requireNonNull(transactionRepository, "transactionRepository must not be null");
        this.fineRepository = Objects.requireNonNull(fineRepository, "fineRepository must not be null");
        this.paymentRepository = Objects.requireNonNull(paymentRepository, "paymentRepository must not be null");
        this.auditLogRepository = Objects.requireNonNull(auditLogRepository, "auditLogRepository must not be null");
        this.bookCopyRepository = Objects.requireNonNull(bookCopyRepository, "bookCopyRepository must not be null");
    }

    public void syntheticData() {
        if (userRepository.findByPhone("9870000001") != null) {
            return;
        }

        User admin = userRepository.findByPhone("9999999999");
        if (admin == null) {
            admin = new User("System Admin", "admin@library.com", "9999999999",
                    AuthService.hashPassword("admin123"), UserRole.ADMIN, UserStatus.ACTIVE);
            userRepository.save(admin);
        }

        User librarian = userRepository.findByPhone("8888888888");
        if (librarian == null) {
            librarian = new User("Head Librarian", "librarian@library.com", "8888888888",
                    AuthService.hashPassword("lib123"), UserRole.LIBRARIAN, UserStatus.ACTIVE);
            userRepository.save(librarian);
        }

        User lib2 = new User("Sarah Librarian", "sarah.lib@library.com", "8888888881",
                AuthService.hashPassword("lib123"), UserRole.LIBRARIAN, UserStatus.ACTIVE);
        userRepository.save(lib2);

        User admin2 = new User("Michael Admin", "michael.admin@library.com", "9999999991",
                AuthService.hashPassword("admin123"), UserRole.ADMIN, UserStatus.ACTIVE);
        userRepository.save(admin2);

        MembershipPlan planStandard = membershipPlanRepository.findByName("Standard Plan");
        if (planStandard == null) {
            planStandard = new MembershipPlan(DataStore.getMembershipPlanId(), "Standard Plan", MembershipPlanService.DEFAULT_STANDARD_PLAN_PRICE);
            membershipPlanRepository.save(planStandard);
        }
        MembershipPlan planPremium = membershipPlanRepository.findByName("Premium Plan");
        if (planPremium == null) {
            planPremium = new MembershipPlan(DataStore.getMembershipPlanId(), "Premium Plan", 599.0);
            membershipPlanRepository.save(planPremium);
        }

        Author authorMartin = new Author(DataStore.getAuthorId(), "Robert C. Martin");
        authorRepository.save(authorMartin);

        Author authorGamma = new Author(DataStore.getAuthorId(), "Erich Gamma");
        authorRepository.save(authorGamma);

        Author authorHelm = new Author(DataStore.getAuthorId(), "Richard Helm");
        authorRepository.save(authorHelm);

        Author authorJohnson = new Author(DataStore.getAuthorId(), "Ralph Johnson");
        authorRepository.save(authorJohnson);

        Author authorVlissides = new Author(DataStore.getAuthorId(), "John Vlissides");
        authorRepository.save(authorVlissides);

        Author authorOrwell = new Author(DataStore.getAuthorId(), "George Orwell");
        authorRepository.save(authorOrwell);

        Author authorFitzgerald = new Author(DataStore.getAuthorId(), "F. Scott Fitzgerald");
        authorRepository.save(authorFitzgerald);

        Author authorFowler = new Author(DataStore.getAuthorId(), "Martin Fowler");
        authorRepository.save(authorFowler);

        Author authorBloch = new Author(DataStore.getAuthorId(), "Joshua Bloch");
        authorRepository.save(authorBloch);

        Author authorHunt = new Author(DataStore.getAuthorId(), "Andrew Hunt");
        authorRepository.save(authorHunt);

        Genre genreSoftwareEngineering = new Genre(DataStore.getGenreId(), "Software Engineering");
        genreRepository.save(genreSoftwareEngineering);

        Genre genreProgramming = new Genre(DataStore.getGenreId(), "Programming");
        genreRepository.save(genreProgramming);

        Genre genreArchitecture = new Genre(DataStore.getGenreId(), "Architecture");
        genreRepository.save(genreArchitecture);

        Genre genreClassic = new Genre(DataStore.getGenreId(), "Classic");
        genreRepository.save(genreClassic);

        Genre genreDystopian = new Genre(DataStore.getGenreId(), "Dystopian");
        genreRepository.save(genreDystopian);

        Genre genreLiterature = new Genre(DataStore.getGenreId(), "Literature");
        genreRepository.save(genreLiterature);

        Genre genreComputerScience = new Genre(DataStore.getGenreId(), "Computer Science");
        genreRepository.save(genreComputerScience);

        Book book1 = new Book("978-0132350884", "Clean Code", "Prentice Hall", 2008, "Handbook of Agile Software Craftsmanship");
        book1.addAuthor(authorMartin);
        book1.addGenre(genreSoftwareEngineering);
        book1.addGenre(genreProgramming);
        bookService.addBook(book1, 3, librarian);

        Book book2 = new Book("978-0134494166", "Clean Architecture", "Prentice Hall", 2017, "A Craftsman's Guide to Software Structure and Design");
        book2.addAuthor(authorMartin);
        book2.addGenre(genreSoftwareEngineering);
        book2.addGenre(genreArchitecture);
        bookService.addBook(book2, 2, librarian);

        Book book3 = new Book("978-0201633610", "Design Patterns", "Addison-Wesley", 1994, "Elements of Reusable Object-Oriented Software");
        book3.addAuthor(authorGamma);
        book3.addAuthor(authorHelm);
        book3.addAuthor(authorJohnson);
        book3.addAuthor(authorVlissides);
        book3.addGenre(genreSoftwareEngineering);
        book3.addGenre(genreProgramming);
        bookService.addBook(book3, 2, librarian);

        Book book4 = new Book("978-0451524935", "1984", "Secker & Warburg", 1950, "Classic Dystopian Novel");
        book4.addAuthor(authorOrwell);
        book4.addGenre(genreClassic);
        book4.addGenre(genreDystopian);
        bookService.addBook(book4, 2, librarian);

        Book book5 = new Book("978-0743273565", "The Great Gatsby", "Charles Scribner's Sons", 1925, "Classic 1920s Novel");
        book5.addAuthor(authorFitzgerald);
        book5.addGenre(genreClassic);
        book5.addGenre(genreLiterature);
        bookService.addBook(book5, 2, librarian);

        Book book6 = new Book("978-0201485677", "Refactoring", "Addison-Wesley", 1999, "Improving the Design of Existing Code");
        book6.addAuthor(authorFowler);
        book6.addGenre(genreSoftwareEngineering);
        bookService.addBook(book6, 2, librarian);

        Book book7 = new Book("978-0134685991", "Effective Java", "Addison-Wesley", 2018, "Best practices for the Java platform");
        book7.addAuthor(authorBloch);
        book7.addGenre(genreProgramming);
        bookService.addBook(book7, 2, librarian);

        Book book8 = new Book("978-0201616224", "The Pragmatic Programmer", "Addison-Wesley", 1999, "From Journeyman to Master");
        book8.addAuthor(authorHunt);
        book8.addGenre(genreSoftwareEngineering);
        bookService.addBook(book8, 2, librarian);

        User member1 = new User("James Smith", "member01@library.com", "9870000001",
                AuthService.hashPassword("MemberPass123!"), UserRole.MEMBER, UserStatus.ACTIVE, 28, "MALE");
        userRepository.save(member1);

        User member2 = new User("Emily Johnson", "member02@library.com", "9870000002",
                AuthService.hashPassword("MemberPass123!"), UserRole.MEMBER, UserStatus.ACTIVE, 24, "FEMALE");
        userRepository.save(member2);

        User member3 = new User("Michael Brown", "member03@library.com", "9870000003",
                AuthService.hashPassword("MemberPass123!"), UserRole.MEMBER, UserStatus.ACTIVE, 35, "MALE");
        userRepository.save(member3);

        User member4 = new User("Emma Davis", "member04@library.com", "9870000004",
                AuthService.hashPassword("MemberPass123!"), UserRole.MEMBER, UserStatus.ACTIVE, 31, "FEMALE");
        userRepository.save(member4);

        User member5 = new User("Daniel Wilson", "member05@library.com", "9870000005",
                AuthService.hashPassword("MemberPass123!"), UserRole.MEMBER, UserStatus.ACTIVE, 42, "MALE");
        userRepository.save(member5);

        User member6 = new User("Sophia Taylor", "member06@library.com", "9870000006",
                AuthService.hashPassword("MemberPass123!"), UserRole.MEMBER, UserStatus.INACTIVE, 22, "FEMALE");
        userRepository.save(member6);

        User prakasu = new User("Prakasu V", "prakasuvelmurugan@gmail.com", "8940404036",
                AuthService.hashPassword("prakash123"), UserRole.MEMBER, UserStatus.ACTIVE, 21, "MALE");
        userRepository.save(prakasu);

        LocalDate today = LocalDate.now();
        int stdPlanId = planStandard.getPlanId();
        int premPlanId = planPremium.getPlanId();

        Membership mem1 = new Membership(DataStore.getMembershipId(), member1.getUserId(), stdPlanId,
                today.minusDays(30), today.plusDays(335), MembershipStatus.ACTIVE, 2001);
        membershipRepository.save(mem1);

        Membership mem2 = new Membership(DataStore.getMembershipId(), member2.getUserId(), premPlanId,
                today.minusDays(20), today.plusDays(345), MembershipStatus.ACTIVE, 2002);
        membershipRepository.save(mem2);

        Membership mem3 = new Membership(DataStore.getMembershipId(), member3.getUserId(), stdPlanId,
                today.minusDays(15), today.plusDays(350), MembershipStatus.ACTIVE, 2003);
        membershipRepository.save(mem3);

        Membership mem4 = new Membership(DataStore.getMembershipId(), member4.getUserId(), premPlanId,
                today.minusDays(90), today.minusDays(10), MembershipStatus.EXPIRED, 2004);
        membershipRepository.save(mem4);

        Membership mem5 = new Membership(DataStore.getMembershipId(), member5.getUserId(), stdPlanId,
                today.minusDays(40), today.plusDays(325), MembershipStatus.SUSPENDED, 2005);
        membershipRepository.save(mem5);

        Membership memPrakasu = new Membership(DataStore.getMembershipId(), prakasu.getUserId(), premPlanId,
                today.minusDays(10), today.plusDays(355), MembershipStatus.ACTIVE, 2006);
        membershipRepository.save(memPrakasu);

        List<BookCopy> book1Copies = bookCopyRepository.findByBookId(book1.getBookId());
        List<BookCopy> book2Copies = bookCopyRepository.findByBookId(book2.getBookId());
        List<BookCopy> book3Copies = bookCopyRepository.findByBookId(book3.getBookId());
        List<BookCopy> book4Copies = bookCopyRepository.findByBookId(book4.getBookId());
        List<BookCopy> book5Copies = bookCopyRepository.findByBookId(book5.getBookId());
        List<BookCopy> book6Copies = bookCopyRepository.findByBookId(book6.getBookId());
        List<BookCopy> book7Copies = bookCopyRepository.findByBookId(book7.getBookId());

        BookCopy copy1 = book1Copies.get(0);
        BookCopy copy2 = book1Copies.get(1);
        BookCopy copy4 = book2Copies.get(0);
        BookCopy copy5 = book2Copies.get(1);
        BookCopy copy6 = book3Copies.get(0);
        BookCopy copy8 = book4Copies.get(0);
        BookCopy copy10 = book5Copies.get(0);
        BookCopy copy12 = book6Copies.get(0);
        BookCopy copy14 = book7Copies.get(0);

        LocalDateTime now = LocalDateTime.now();

        Transaction tx1 = new Transaction(DataStore.getTransactionId(), "9870000001", book1.getBookId(), copy1.getBookCopyId(),
                TransactionStatus.RETURNED, now.minusDays(40), now.minusDays(38), today.minusDays(24), now.minusDays(20));
        transactionRepository.save(tx1);

        Transaction tx2 = new Transaction(DataStore.getTransactionId(), "9870000002", book2.getBookId(), copy4.getBookCopyId(),
                TransactionStatus.RETURNED, now.minusDays(30), now.minusDays(28), today.minusDays(14), now.minusDays(10));
        transactionRepository.save(tx2);

        Transaction tx3 = new Transaction(DataStore.getTransactionId(), "8940404036", book3.getBookId(), copy6.getBookCopyId(),
                TransactionStatus.RETURNED, now.minusDays(25), now.minusDays(24), today.minusDays(10), now.minusDays(8));
        transactionRepository.save(tx3);

        copy2.reserve();
        copy2.issue();
        bookCopyRepository.save(copy2);
        Transaction tx4 = new Transaction(DataStore.getTransactionId(), "9870000001", book1.getBookId(), copy2.getBookCopyId(),
                TransactionStatus.ISSUED, now.minusDays(3), now.minusDays(3), today.plusDays(11), null);
        transactionRepository.save(tx4);

        copy5.reserve();
        copy5.issue();
        bookCopyRepository.save(copy5);
        Transaction tx5 = new Transaction(DataStore.getTransactionId(), "9870000003", book2.getBookId(), copy5.getBookCopyId(),
                TransactionStatus.ISSUED, now.minusDays(25), now.minusDays(25), today.minusDays(5), null);
        transactionRepository.save(tx5);

        copy8.reserve();
        bookCopyRepository.save(copy8);
        Transaction tx6 = new Transaction(DataStore.getTransactionId(), "9870000004", book4.getBookId(), copy8.getBookCopyId(),
                TransactionStatus.RESERVED, now.minusDays(2), null, null, null);
        transactionRepository.save(tx6);

        copy10.reserve();
        bookCopyRepository.save(copy10);
        Transaction tx7 = new Transaction(DataStore.getTransactionId(), "9870000005", book5.getBookId(), copy10.getBookCopyId(),
                TransactionStatus.READY_FOR_PICKUP, now.minusDays(1), null, null, null);
        transactionRepository.save(tx7);

        Transaction tx8 = new Transaction(DataStore.getTransactionId(), "9870000002", book6.getBookId(), 0,
                TransactionStatus.CANCELLED, now.minusDays(10), null, null, null);
        transactionRepository.save(tx8);

        copy12.markLost();
        bookCopyRepository.save(copy12);
        Transaction tx9 = new Transaction(DataStore.getTransactionId(), "9870000003", book6.getBookId(), copy12.getBookCopyId(),
                TransactionStatus.LOST, now.minusDays(20), now.minusDays(18), today.minusDays(4), null);
        transactionRepository.save(tx9);

        copy14.markDamaged();
        bookCopyRepository.save(copy14);
        Transaction tx10 = new Transaction(DataStore.getTransactionId(), "8940404036", book7.getBookId(), copy14.getBookCopyId(),
                TransactionStatus.DAMAGED, now.minusDays(15), now.minusDays(14), today.minusDays(2), now.minusDays(1));
        transactionRepository.save(tx10);

        Transaction tx11 = new Transaction(DataStore.getTransactionId(), "9870000001", book4.getBookId());
        transactionRepository.save(tx11);

        Fine fine1 = new Fine(DataStore.getFineId(), tx2.getUserPhone(), tx2.getTransactionId(), 40.0, FineType.OVERDUE);
        fine1.applyPayment(40.0);
        fineRepository.save(fine1);

        Fine fine2 = new Fine(DataStore.getFineId(), tx5.getUserPhone(), tx5.getTransactionId(), 50.0, FineType.OVERDUE);
        fine2.applyPayment(25.0);
        fineRepository.save(fine2);

        Fine fine3 = new Fine(DataStore.getFineId(), tx2.getUserPhone(), tx2.getTransactionId(), 30.0, FineType.OVERDUE);
        fineRepository.save(fine3);

        Fine fine4 = new Fine(DataStore.getFineId(), tx1.getUserPhone(), tx1.getTransactionId(), 20.0, FineType.OVERDUE);
        fine4.waive();
        fineRepository.save(fine4);

        Fine fine5 = new Fine(DataStore.getFineId(), tx9.getUserPhone(), tx9.getTransactionId(), 500.0, FineType.LOST_BOOK);
        fineRepository.save(fine5);

        Fine fine6 = new Fine(DataStore.getFineId(), tx10.getUserPhone(), tx10.getTransactionId(), 100.0, FineType.DAMAGED_BOOK);
        fine6.applyPayment(100.0);
        fineRepository.save(fine6);

        Payment payFine1 = new Payment(DataStore.getPaymentId(), fine1.getFineId(), fine1.getUserPhone(), 40.0, PaymentMethod.UPI);
        payFine1.markSuccess("REF_FINE_2001");
        paymentRepository.save(payFine1);

        Payment payFine2 = new Payment(DataStore.getPaymentId(), fine2.getFineId(), fine2.getUserPhone(), 25.0, PaymentMethod.CARD);
        payFine2.markSuccess("REF_FINE_2002");
        paymentRepository.save(payFine2);

        Payment payFine3 = new Payment(DataStore.getPaymentId(), fine6.getFineId(), fine6.getUserPhone(), 100.0, PaymentMethod.NET_BANKING);
        payFine3.markSuccess("REF_FINE_2003");
        paymentRepository.save(payFine3);

        Payment payMem1 = Payment.forMembership(DataStore.getPaymentId(), mem1.getMembershipId(), member1.getPhone(), 399.0, PaymentMethod.UPI);
        payMem1.markSuccess("REF_MEM_1001");
        paymentRepository.save(payMem1);

        Payment payMem2 = Payment.forMembership(DataStore.getPaymentId(), mem2.getMembershipId(), member2.getPhone(), 599.0, PaymentMethod.CARD);
        payMem2.markSuccess("REF_MEM_1002");
        paymentRepository.save(payMem2);

        Payment payMem3 = Payment.forMembership(DataStore.getPaymentId(), mem3.getMembershipId(), member3.getPhone(), 399.0, PaymentMethod.NET_BANKING);
        payMem3.markSuccess("REF_MEM_1003");
        paymentRepository.save(payMem3);

        Payment payMem4 = Payment.forMembership(DataStore.getPaymentId(), memPrakasu.getMembershipId(), prakasu.getPhone(), 599.0, PaymentMethod.UPI);
        payMem4.markSuccess("REF_MEM_1004");
        paymentRepository.save(payMem4);

        Audit audit1 = new Audit(DataStore.getAuditId(), "8888888888", "BOOK_ADDED", "BOOK", "1", "Librarian added book Clean Code");
        auditLogRepository.save(audit1);

        Audit audit2 = new Audit(DataStore.getAuditId(), "8888888888", "BOOK_ADDED", "BOOK", "2", "Librarian added book Clean Architecture");
        auditLogRepository.save(audit2);

        Audit audit3 = new Audit(DataStore.getAuditId(), "9870000001", "MEMBERSHIP_ACTIVATED", "MEMBERSHIP", "1", "Member activated Standard Plan");
        auditLogRepository.save(audit3);

        Audit audit4 = new Audit(DataStore.getAuditId(), "9870000001", "BOOK_ISSUED", "BOOK", "1", "Issued Clean Code copy to member");
        auditLogRepository.save(audit4);

        Audit audit5 = new Audit(DataStore.getAuditId(), "9870000002", "BOOK_RETURNED", "BOOK", "2", "Member returned Clean Architecture copy");
        auditLogRepository.save(audit5);

        Audit audit6 = new Audit(DataStore.getAuditId(), "8888888888", "FINE_CREATED", "FINE", "1", "Overdue fine assessed for late return");
        auditLogRepository.save(audit6);

        Audit audit7 = new Audit(DataStore.getAuditId(), "9870000002", "FINE_PAYMENT_SUCCEEDED", "PAYMENT", "1", "Paid overdue fine via UPI");
        auditLogRepository.save(audit7);
    }
}
