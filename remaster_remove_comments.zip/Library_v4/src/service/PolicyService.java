package service;

import enums.TransactionStatus;
import enums.UserRole;
import enums.UserStatus;
import model.Fine;
import model.MembershipPlan;
import model.Transaction;
import model.User;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import repository.FineRepository;
import repository.MembershipPlanRepository;
import repository.MembershipRepository;
import repository.TransactionRepository;
import repository.UserRepository;

public class PolicyService {
    private static final int DEFAULT_MAX_BOOKS = 3;
    private static final int DEFAULT_LOAN_DAYS = 14;
    private static final double DEFAULT_FINE_PER_DAY = 10.0;
    private static final double DEFAULT_LOST_BOOK_CHARGE = 500.0;
    private static final double DEFAULT_DAMAGED_BOOK_CHARGE = 100.0;

    private final UserRepository users;
    private final MembershipRepository memberships;
    private final TransactionRepository transactions;
    private final FineRepository fines;
    private final AuditService auditService;
    private MembershipPlanRepository planRepository;

    private int maxBooksBorrowed = DEFAULT_MAX_BOOKS;
    private int loanPeriodDays = DEFAULT_LOAN_DAYS;
    private double finePerDay = DEFAULT_FINE_PER_DAY;
    private double lostBookCharge = DEFAULT_LOST_BOOK_CHARGE;
    private double damagedBookCharge = DEFAULT_DAMAGED_BOOK_CHARGE;


    public PolicyService(UserRepository users, MembershipRepository memberships,
                         TransactionRepository transactions, FineRepository fines,
                         AuditService auditService, MembershipPlanRepository planRepository) {
        this.users = users;
        this.memberships = memberships;
        this.transactions = transactions;
        this.fines = fines;
        this.auditService = auditService;
        this.planRepository = planRepository;
    }


    public boolean canManageInventory(User authenticatedUser) {
        if (authenticatedUser == null || authenticatedUser.getStatus() != UserStatus.ACTIVE) return false;
        User currentUser = users.findByPhone(authenticatedUser.getPhone());
        return currentUser != null && currentUser.getUserId() == authenticatedUser.getUserId() && currentUser.getStatus() == UserStatus.ACTIVE && (currentUser.getRole() == UserRole.LIBRARIAN || currentUser.getRole() == UserRole.ADMIN);
    }



    public boolean hasActiveMembership(String phone) {
        if (phone == null || phone.isBlank()) return false;
        model.Membership membership = findMembershipForAccount(phone);
        return membership != null && membership.getEndDate() != null
                && !LocalDate.now().isAfter(membership.getEndDate());
    }

    public int countIssuedBooks(String phone) {
        if (phone == null || phone.isBlank()) return 0;
        return countIssuedBooksForValidPhone(phone.trim());
    }

    private int countIssuedBooksForValidPhone(String phone) {
        int count = 0;
        for (Transaction transaction : transactions.findByUserPhone(phone)) {
            if (transaction.getStatus() == TransactionStatus.ISSUED) count++;
        }
        return count;
    }

    public boolean hasOutstandingFine(String phone) {
        for (Fine fine : fines.findByUserPhone(phone)) {
            if (fine.isPending()) {
                return true;
            }
        }
        return false;
    }

    public boolean isDefaulter(String phone) {
        if (phone == null || phone.isBlank()) return false;

        if (hasOutstandingFine(phone)) return true;

        for (Transaction transaction : transactions.findByUserPhone(phone.trim())) {
            LocalDate dueDate = transaction.getDueDate();
            if (transaction.getStatus() == TransactionStatus.ISSUED
                    && dueDate != null && LocalDate.now().isAfter(dueDate)) {
                return true;
            }
        }
        return false;
    }


    public List<User> getDefaulters(User staff) {
        if (!canManageInventory(staff)) {
            return new ArrayList<>();
        }
        return findDefaulters();
    }





    private List<User> findDefaulters() {
        List<User> result = new ArrayList<>();
        for (User user : users.findAll()) {
            if (isDefaulter(user.getPhone())) {
                result.add(user);
            }
        }
        return result;
    }

    private model.Membership findMembershipForAccount(String phone) {
        User user = users.findByPhone(phone);
        return user == null ? null : memberships.findActiveByUserId(user.getUserId());
    }

    public MembershipPlan getPlanForUser(String phone) {
        if (phone == null || phone.isBlank() || memberships == null) {
            return null;
        }
        model.Membership membership = findMembershipForAccount(phone.trim());
        if (membership == null) {
            return null;
        }
        int planId = membership.getPlanId();
        if (planRepository != null) {
            MembershipPlan p = planRepository.findById(planId);
            if (p != null) return p;
        }
        return memberships.findPlanById(planId);
    }

    public int getMaxBooksForUser(String phone) {
        MembershipPlan plan = getPlanForUser(phone);
        if (plan != null) {
            return plan.getMaxIssuedBooks();
        }
        return maxBooksBorrowed;
    }

    public int getLoanPeriodDaysForUser(String phone) {
        MembershipPlan plan = getPlanForUser(phone);
        return plan != null ? plan.getLoanPeriodDays() : loanPeriodDays;
    }

    public double getFinePerDayForUser(String phone) {
        MembershipPlan plan = getPlanForUser(phone);
        return plan != null ? plan.getFinePerDay() : finePerDay;
    }

    public double getLostBookChargeForUser(String phone) {
        MembershipPlan plan = getPlanForUser(phone);
        return plan != null ? plan.getLostBookCharge() : lostBookCharge;
    }

    public double getDamagedBookChargeForUser(String phone) {
        MembershipPlan plan = getPlanForUser(phone);
        return plan != null ? plan.getDamagedBookCharge() : damagedBookCharge;
    }

    public int getRequestQueuePriority(String phone) {
        MembershipPlan plan = getPlanForUser(phone);
        if (plan == null) {
            return 2; 
        }
        String name = plan.getPlanName().toLowerCase();
        if (name.contains("premium")) {
            return 1; 
        }
        return 2; 
    }

    public boolean canRequestBook(String phone) {
        if (phone == null || phone.isBlank()) {
            return false;
        }
        User user = users.findByPhone(phone);
        return user != null && user.getStatus() == UserStatus.ACTIVE && hasActiveMembership(phone) && !isDefaulter(phone);
    }

    public boolean canIssueBook(String phone) {
        return canRequestBook(phone) && countIssuedBooks(phone) < getMaxBooksForUser(phone);
    }

    public List<String> getBorrowingEligibilityFailureReasons(String phone) {
        if (phone == null || phone.isBlank()) {
            List<String> reasons = new ArrayList<>();
            reasons.add("User phone number is required.");
            return reasons;
        }
        return getEligibilityFailureReasonsForValidPhone(phone.trim(),true);
    }



    private List<String> getEligibilityFailureReasonsForValidPhone(String normalizedPhone, boolean checkBorrowingLimit) {
        List<String> reasons = new ArrayList<>();
        User user = users == null ? null : users.findByPhone(normalizedPhone);
        if (user == null) {
            reasons.add("User account not found.");
            return reasons;
        }
        if (user.getStatus() != UserStatus.ACTIVE) {
            reasons.add("Account is currently inactive or suspended.");
        }

        model.Membership activeMembership = findMembershipForAccount(normalizedPhone);
        MembershipPlan plan = null;
        if (activeMembership != null) {
            plan =  planRepository.findById(activeMembership.getPlanId());
             if (activeMembership.getEndDate() != null && LocalDate.now().isAfter(activeMembership.getEndDate())) {
                reasons.add("Membership expired on " + activeMembership.getEndDate() + ".");
            }
        } else {
            boolean hadMembership = false;

                User member = users.findByPhone(normalizedPhone);
                if (member != null) {
                    for (model.Membership membership : memberships.findByUserId(member.getUserId())) {
                        if (membership.getStatus() == enums.MembershipStatus.EXPIRED
                                || (membership.getEndDate() != null && LocalDate.now().isAfter(membership.getEndDate()))) {
                            hadMembership = true;
                            break;
                        }
                    }
                }

            reasons.add(hadMembership ? "Membership has expired." : "No active membership found.");
        }

        if (fines != null) {
            double totalOutstanding = 0;
            for (Fine fine : fines.findByUserPhone(normalizedPhone)) {
                if (fine.isPending()) totalOutstanding += fine.getRemainingAmount();
            }
            if (totalOutstanding > 0) {
                reasons.add("Outstanding fine: Rs." + String.format( "%.2f", totalOutstanding) + ".");
            }
        }

        int issuedCount = 0;
        if (transactions != null) {
            for (Transaction transaction : transactions.findByUserPhone(normalizedPhone)) {
                if (transaction.getStatus() == TransactionStatus.ISSUED) {
                    issuedCount++;
                    if ( LocalDate.now().isAfter(transaction.getDueDate())) {
                        long overdueDays = java.time.temporal.ChronoUnit.DAYS.between(transaction.getDueDate(), LocalDate.now());
                        reasons.add("Overdue book on loan (Transaction ID " + transaction.getTransactionId()
                                + " is " + overdueDays + " day(s) overdue).");
                    }
                }
            }
        }

        if (plan!=null && checkBorrowingLimit) {
            int maxAllowed =  plan.getMaxIssuedBooks();
            if (issuedCount >= maxAllowed) {
                reasons.add("Borrowing limit reached: Member has already borrowed " + issuedCount
                        + " of " + maxAllowed + " allowed books.");
            }
        }

        return reasons;
    }

    public String getBorrowingResolutionAdvice(List<String> failureReasons) {
        if (failureReasons == null || failureReasons.isEmpty()) return "";
        List<String> actions = new ArrayList<>();
        boolean needMembership = false;
        boolean needFine = false;
        boolean needReturn = false;
        boolean needAccount = false;
        for (String r : failureReasons) {
            String lower = r.toLowerCase();
            if (lower.contains("membership")) needMembership = true;
            if (lower.contains("fine")) needFine = true;
            if (lower.contains("overdue")) needReturn = true;
            if (lower.contains("account")) needAccount = true;
        }
        if (needMembership) actions.add("renew your membership");
        if (needFine) actions.add("settle the outstanding fine");
        if (needReturn) actions.add("return overdue books");
        if (needAccount) actions.add("contact library staff regarding your account status");

        if (actions.isEmpty()) return "";
        return "Please " + String.join(" and ", actions) + ".";
    }

    public List<String> getIssueEligibilityFailureReasons(String phone) {
        if (phone == null || phone.isBlank()) {
            List<String> reasons = new ArrayList<>();
            reasons.add("User phone number is required.");
            return reasons;
        }
        return getEligibilityFailureReasonsForValidPhone(phone.trim(), true);
    }
}
