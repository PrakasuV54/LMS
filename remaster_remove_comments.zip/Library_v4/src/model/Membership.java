package model;

import enums.MembershipStatus;
import java.time.LocalDate;

public class Membership {
    private final int membershipId;
    private final int userId;
    private int planId;
    private int pendingPlanId;
    private LocalDate pendingPlanStartDate;
    private LocalDate currentPlanEndDate;
    private final LocalDate startDate;
    private LocalDate endDate;
    private MembershipStatus status;
    private final int paymentId;
    public Membership(int membershipId, int userId, int planId, LocalDate startDate, LocalDate endDate,
    MembershipStatus status, int paymentId) {
        if (userId <= 0)
            throw new IllegalArgumentException("Valid user ID is required");
        if (startDate == null || endDate == null || endDate.isBefore(startDate))
            throw new IllegalArgumentException("Membership dates are invalid");
        if (status == null)
            throw new IllegalArgumentException("Membership status is required");
        this.membershipId = membershipId;
        this.userId = userId;
        this.planId = planId;
        this.currentPlanEndDate = endDate;
        this.startDate = startDate;
        this.endDate = endDate;
        this.status = status;
        this.paymentId = paymentId;
    }

    public int getMembershipId() {
        return membershipId;
    }

    public int getUserId() {
        return userId;
    }


    public int getPlanId() {
        applyPendingPlanIfEffective();
        return planId;
    }

    private void applyPendingPlanIfEffective() {
        if (pendingPlanId > 0 && pendingPlanStartDate != null
                && !LocalDate.now().isBefore(pendingPlanStartDate)) {
            planId = pendingPlanId;
            pendingPlanId = 0;
            pendingPlanStartDate = null;
            currentPlanEndDate = endDate;
        }
    }

    public void setPlanId(int planId) {
        this.planId = planId;
    }

    public int getPendingPlanId() {
        applyPendingPlanIfEffective();
        return pendingPlanId;
    }

    public LocalDate getPendingPlanStartDate() {
        applyPendingPlanIfEffective();
        return pendingPlanStartDate;
    }

    public LocalDate getCurrentPlanEndDate() {
        return currentPlanEndDate;
    }

    public boolean hasPendingPlanChange() {
        applyPendingPlanIfEffective();
        return pendingPlanId > 0 && pendingPlanStartDate != null
                && LocalDate.now().isBefore(pendingPlanStartDate);
    }

    public void schedulePlanChange(int newPlanId, LocalDate effectiveDate) {
        if (newPlanId <= 0 || effectiveDate == null) {
            throw new IllegalArgumentException("A valid plan and effective date are required");
        }
        pendingPlanId = newPlanId;
        pendingPlanStartDate = effectiveDate;
    }

    public void extendCurrentPlan(LocalDate newEndDate) {
        extend(newEndDate);
        currentPlanEndDate = newEndDate;
        pendingPlanId = 0;
        pendingPlanStartDate = null;
    }

    public LocalDate getStartDate() {
        return startDate;
    }

    public LocalDate getEndDate() {
        return endDate;
    }

    public MembershipStatus getStatus() {
        return status;
    }

    public int getPaymentId() {
        return paymentId;
    }

    public void extend(LocalDate newEndDate) {
        if (newEndDate == null || !newEndDate.isAfter(endDate)) {
            throw new IllegalArgumentException("New end date must be after the current end date");
        }
        if (status != MembershipStatus.ACTIVE) {
            throw new IllegalStateException("Only an active membership can be renewed");
        }
        endDate = newEndDate;
    }

    public void suspend() {
        if (status != MembershipStatus.ACTIVE) throw new IllegalStateException("Only an active membership can be suspended");
        status = MembershipStatus.SUSPENDED;
    }

    public void activate() {
        if (status != MembershipStatus.SUSPENDED) throw new IllegalStateException("Only a suspended membership can be reactivated");
        if (LocalDate.now().isAfter(endDate)) throw new IllegalStateException("Expired membership cannot be activated");
        status = MembershipStatus.ACTIVE;
    }

    public void expire() {
        status = MembershipStatus.EXPIRED;
    }



    public boolean isActive() {
        LocalDate today = LocalDate.now();
        return status == MembershipStatus.ACTIVE && !today.isBefore(startDate) && !today.isAfter(endDate);
    }
}
