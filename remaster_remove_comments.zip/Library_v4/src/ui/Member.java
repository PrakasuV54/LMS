package ui;

import enums.PaymentMethod;
import enums.PaymentStatus;
import enums.TransactionStatus;
import enums.UserRole;
import enums.UserStatus;
import model.*;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import service.AuthService;
import java.util.*;

public class Member extends Main {



    public static void member() {
        System.out.println("1.Login or 2.Register or 3.Exit");
        int loginChoice = readInt();

        switch (loginChoice) {
            case 1: {
                User identifiedUser;
                String identifier;
                while (true) {
                    System.out.println("Enter Mobile or Email (0 to go back to user selection)");
                    identifier = sc.nextLine().trim();
                    if (identifier.equals("0")) return;

                    identifiedUser = findUserByIdentifier(identifier);
                    if (identifiedUser == null) {
                        System.out.println("No account found with that phone number or email. Please try again.");
                        continue;
                    }
                    if (identifiedUser.getRole() != UserRole.MEMBER) {
                        System.out.println("This account is registered as " + identifiedUser.getRole()
                                + ". Please enter a member phone number or email.");
                        continue;
                    }
                    if (identifiedUser.getStatus() != UserStatus.ACTIVE) {
                        System.out.println("Login Failed: Your account has been deactivated. Please enter another phone number or email.");
                        continue;
                    }
                    break;
                }

                User user;
                while (true) {
                    System.out.println("Enter Password (0 to go back to user selection)");
                    String loginPassword = sc.nextLine();
                    if (loginPassword.equals("0")) return;

                    user = authService.login(identifier, loginPassword);
                    if (user != null) break;
                    System.out.println("Incorrect password. Please enter your password again, or enter 0 to go back.");
                }

                currentUser = user;
                System.out.println("Login Success");
                memberMenu();
                break;
            }

            case 2:
                registerMember();
                break;

            case 3:
                return;

            default:
                System.out.println("Invalid Input");
        }
    }

    private static String readRegistrationValue(String prompt) {
        System.out.println(prompt + " (0 to cancel registration)");
        String value = sc.nextLine().trim();
        return value.equals("0") ? null : value;
    }

    public static void registerMember() {
        String name;
        while (true) {
            name = readRegistrationValue("Enter your name (letters and spaces only)");
            if (name == null) {
                System.out.println("Registration cancelled.");
                return;
            }
            if (name.matches("[\\p{L}]+(?: [\\p{L}]+)*")) break;
            System.out.println("Invalid name. Use letters and spaces only. Please enter your name again.");
        }

        String phone;
        while (true) {
            phone = readRegistrationValue("Enter your phone number");
            if (phone == null) {
                System.out.println("Registration cancelled.");
                return;
            }
            if (!phone.matches("\\d{10}")) {
                System.out.println("Invalid phone number. Enter a valid 10-digit number.");
                continue;
            }
            if (userService.phoneExists(phone)) {
                System.out.println("This phone number is already registered. Please enter another phone number.");
                continue;
            }
            break;
        }

        String email;
        while (true) {
            email = readRegistrationValue("Enter your email");
            if (email == null) {
                System.out.println("Registration cancelled.");
                return;
            }
            if (!email.matches("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$")) {
                System.out.println("Invalid email format. Please enter your email again.");
                continue;
            }
            if (userService.emailExists(email)) {
                System.out.println("This email is already registered. Please enter another email address.");
                continue;
            }
            break;
        }

        String ageInput = readRegistrationValue("Enter your age");
        if (ageInput == null) {
            System.out.println("Registration cancelled.");
            return;
        }
        int age;
        try {
            age = Integer.parseInt(ageInput);
        } catch (NumberFormatException ex) {
            System.out.println("Registration failed: Enter a valid age.");
            return;
        }
        if (age < 1 || age > 120) {
            System.out.println("Registration failed: Age must be between 1 and 120.");
            return;
        }

        System.out.println("Select your gender (0 to cancel registration):");
        System.out.println("1. MALE");
        System.out.println("2. FEMALE");
        System.out.println("3. NON_BINARY");
        System.out.println("4. OTHER");
        System.out.println("5. PREFER_NOT_TO_SAY");
        String genderInput = sc.nextLine().trim();
        if (genderInput.equals("0")) {
            System.out.println("Registration cancelled.");
            return;
        }
        int genderChoice;
        try {
            genderChoice = Integer.parseInt(genderInput);
        } catch (NumberFormatException ex) {
            System.out.println("Registration failed: Choose a valid gender option.");
            return;
        }
        String gender;
        switch (genderChoice) {
            case 1: gender = "MALE"; break;
            case 2: gender = "FEMALE"; break;
            case 3: gender = "NON_BINARY"; break;
            case 4: gender = "OTHER"; break;
            case 5: gender = "PREFER_NOT_TO_SAY"; break;
            default:
                System.out.println("Registration failed: Choose a valid gender option.");
                return;
        }

        String registerPassword;
        while (true) {
            System.out.println("Enter your password (0 to cancel registration)");
            registerPassword = sc.nextLine();
            if (registerPassword.equals("0")) {
                System.out.println("Registration cancelled.");
                return;
            }

            String regReason = userService.getRegistrationFailureReason(name, email, phone, registerPassword);
            if (regReason != null) {
                System.out.println("Registration failed: " + regReason);
                System.out.println("Please enter your password again.");
                continue;
            }

            System.out.println("Enter your password again (0 to cancel registration)");
            String confirmPassword = sc.nextLine();
            if (confirmPassword.equals("0")) {
                System.out.println("Registration cancelled.");
                return;
            }
            if (!registerPassword.equals(confirmPassword)) {
                System.out.println("Passwords do not match. Please enter your password again.");
                continue;
            }
            break;
        }

        authService.register(name, email, phone, registerPassword);
        System.out.println("Registration successful. Your account and profile details have been saved.");
    }

    public static void memberMenu() {
        while (true) {
            System.out.println("\n1.View All Books");
            System.out.println("2.Search Books");
            System.out.println("3.Request Book");
            System.out.println("4.Cancel Request");
            System.out.println("5.Renew Book");
            System.out.println("6.Activate Membership");
            System.out.println("7.Renew Membership");
            System.out.println("8.View Currently Rented Books");
            System.out.println("9.View Borrowing History");
            System.out.println("10.Manage Fines");
            System.out.println("11.Update Profile");
            System.out.println("12.Logout");
            System.out.println("Enter Your Choice");

            int choice = readInt();

            try {
                switch (choice) {
                    case 1:
                        handleViewAllBooks();
                        break;
                    case 2:
                        handleSearchBooks();
                        break;
                    case 3:
                        handleRequestBook();
                        break;
                    case 4:
                        handleCancelRequest();
                        break;
                    case 5:
                        handleRenewBook();
                        break;
                    case 6:
                        handleActivateMembership();
                        break;
                    case 7:
                        handleRenewMembership();
                        break;
                    case 8:
                        handleViewCurrentlyRentedBooks();
                        break;
                    case 9:
                        handleViewBorrowingHistory();
                        break;
                    case 10:
                        handleManageFines();
                        break;
                    case 11:
                        handleUpdateProfile();
                        break;
                    case 12:
                        currentUser = null;
                        System.out.println("Logged out successfully");
                        return;
                    default:
                        System.out.println("Invalid Choice");
                }
            } catch (RuntimeException e) {
                if (e != GO_HOME) throw e;
            }
        }
    }

    public static void handleViewAllBooks() {
        List<Book> allBooks = new ArrayList<>();
        for (Book book : bookService.getAllBooks()) {
            if (book.getStatus() == enums.BookStatus.ACTIVE) {
                allBooks.add(book);
            }
        }
        if (allBooks.isEmpty()) {
            System.out.println("No active books found.");
            return;
        }
        UiHelpers.handleBookListInteraction(allBooks);
    }

    public static void handleSearchBooks() {
        UiHelpers.searchBooks();
    }

    public static void handleRequestBook() {
        while (true) {
            System.out.println("\n--- Request a Book ---");
            System.out.println("1. Request directly by ISBN");
            System.out.println("2. Search books and request from results");
            System.out.println("3. Browse catalogue and request a book");
            System.out.println("4. Back");
            System.out.println("0. Go to Home");
            System.out.println("Enter choice:");
            int choice = readInt();
            if (choice == 0) goHome();
            switch (choice) {
                case 1:
                    System.out.println("Enter ISBN (0 to cancel):");
                    String requestIsbn = sc.nextLine().trim();
                    if (requestIsbn.equals("0")) break;
                    submitBookRequestByIsbn(requestIsbn);
                    break;
                case 2:
                    UiHelpers.searchBooks();
                    break;
                case 3:
                    List<Book> allBooks = bookService.getAllBooks();
                    if (allBooks.isEmpty()) System.out.println("The catalogue is empty.");
                    else UiHelpers.handleBookListInteraction(allBooks);
                    break;
                case 4:
                    return;
                default:
                    System.out.println("Invalid choice. Select 1-4.");
            }
        }
    }

    public static void requestBookForSelectedBook(Book book) {
        if (book == null || currentUser == null) {
            submitBookRequest(book);
            return;
        }
        if (currentUser.getRole() != UserRole.MEMBER && operationTargetUser == null) {
            runForTargetMember(() -> submitBookRequest(book));
        } else {
            submitBookRequest(book);
        }
    }

    private static void submitBookRequest(Book book) {
        submitBookRequestByIsbn(book == null ? null : book.getIsbn());
    }

    private static void submitBookRequestByIsbn(String isbn) {
        User requestingMember = getOperationUser();
        Transaction requested;
        try {
            requested = bookTransactionService.requestBookByIsbn(
                    requestingMember == null ? null : requestingMember.getPhone(), isbn, currentUser);
        } catch (IllegalStateException e) {
            List<String> reasons = java.util.Arrays.asList(e.getMessage().split("\\n- "));
            System.out.println("Cannot request this book"
                    + (requestingMember == null ? "" : " for " + requestingMember.getName()) + ":");
            for (String reason : reasons) System.out.println("- " + reason);
            String advice = policyService.getBorrowingResolutionAdvice(reasons);
            if (!advice.isEmpty()) System.out.println("\n" + advice);
            return;
        }
        Book requestedBook =  bookService.getBookByIsbn(isbn);
        if (requested != null) {
            System.out.println("Book request submitted successfully.");
            System.out.println("Book: " + requestedBook.getTitle() + " | ISBN: " + requestedBook.getIsbn());
            System.out.println("Member: " + requestingMember.getName());
            System.out.println("Request status: " + requested.getStatus());
        }
    }

    private static String readMemberWorkflowInput(String prompt) {
        return readMemberWorkflowInput(prompt, true);
    }

    private static String readMemberWorkflowInput(String prompt, boolean allowBack) {
        System.out.println(prompt + (allowBack ? " (-1 to go back, 0 to go to Home)" : " (0 to go to Home)"));
        String value = sc.nextLine().trim();
        if (value.equals("0")) {
            Main.goHome();
        }
        if (value.equals("-1") && allowBack) {
            return null;
        }
        return value;
    }

    private static MembershipPlan readMembershipPlan(String prompt) {
        while (true) {
            System.out.println(prompt + " (-1 to go back, 0 to go to Home)");
            String input = sc.nextLine().trim();
            if (input.equals("0")) {
                Main.goHome();
                return null;
            }
            if (input.equals("-1")) {
                return null;
            }
            int planId;
            try {
                planId = Integer.parseInt(input);
            } catch (NumberFormatException ex) {
                System.out.println("Invalid Plan ID. Please enter a valid Plan ID.");
                continue;
            }
            MembershipPlan plan = membershipPlanService.findById(planId);
            if (plan == null) {
                System.out.println("Invalid Plan ID. Please select a plan from the list.");
                continue;
            }
            return plan;
        }
    }

    public static void handleCancelRequest() {
        User targetMember = getOperationUser();
        if (targetMember == null) {
            System.out.println("A valid member account is required to cancel a request.");
            return;
        }

        while (true) {
            List<Transaction> history = bookTransactionService.getBorrowingHistory(targetMember.getPhone());
            List<Transaction> cancellableRequests = new ArrayList<>();
            for (Transaction transaction : history) {
                TransactionStatus status = transaction.getStatus();
                if (status == TransactionStatus.REQUESTED
                        || status == TransactionStatus.RESERVED
                        || status == TransactionStatus.READY_FOR_PICKUP) {
                    cancellableRequests.add(transaction);
                }
            }

            if (cancellableRequests.isEmpty()) {
                System.out.println("You have no book requests that can be cancelled.");
                return;
            }

            System.out.println("Book requests that can be cancelled:");
            for (int i = 0; i < cancellableRequests.size(); i++) {
                Transaction transaction = cancellableRequests.get(i);
                Book requestedBook = bookService.getBookById(transaction.getBookId());
                System.out.println((i + 1) + ". Title: "
                        + (requestedBook == null ? "Unavailable" : requestedBook.getTitle())
                        + " | ISBN: " + (requestedBook == null ? "Unavailable" : requestedBook.getIsbn())
                        + " | Status: " + transaction.getStatus()
                        + " | Transaction ID: " + transaction.getTransactionId());
            }

            String cancelIsbn = readMemberWorkflowInput("Enter the ISBN of the request to cancel", false);
            if (cancelIsbn == null) {
                return;
            }
            boolean listedIsbn = false;
            for (Transaction transaction : cancellableRequests) {
                Book requestedBook = bookService.getBookById(transaction.getBookId());
                if (requestedBook != null && requestedBook.getIsbn().equalsIgnoreCase(cancelIsbn)) {
                    listedIsbn = true;
                    break;
                }
            }
            if (!listedIsbn) {
                System.out.println("Invalid ISBN. Please enter an ISBN from the list.");
                continue;
            }

            try {
                bookTransactionService.cancelRequest(targetMember.getPhone(), cancelIsbn, currentUser);
                System.out.println("Request cancelled successfully");
                return;
            } catch (IllegalStateException ex) {
                System.out.println("Cancellation failed:");
                for (String reason : ex.getMessage().split("\\R- ")) System.out.println("- " + reason);
            }
        }
    }

    public static void handleRenewBook() {
        User targetMember = getOperationUser();
        if (targetMember == null) {
            System.out.println("A valid member account is required to renew a book.");
            return;
        }

        while (true) {
            List<Transaction> history = bookTransactionService.getBorrowingHistory(targetMember.getPhone());
            List<Transaction> issued = new ArrayList<>();
            for (Transaction transaction : history) {
                if (transaction.getStatus() == TransactionStatus.ISSUED) issued.add(transaction);
            }
            if (issued.isEmpty()) {
                System.out.println("You have no currently issued books to renew.");
                return;
            }

            System.out.println("Currently issued books:");
            for (Transaction transaction : issued) {
                Book book = bookService.getBookById(transaction.getBookId());
                System.out.println("Transaction ID: " + transaction.getTransactionId()
                        + " | ISBN: " + (book == null ? "Unavailable" : book.getIsbn())
                        + " | Title: " + (book == null ? "Unavailable" : book.getTitle())
                        + " | Due date: " + transaction.getDueDate());
            }

            String renewIsbn = readMemberWorkflowInput("Enter ISBN of the book to renew", false);
            if (renewIsbn == null) return;

            boolean listed = false;
            for (Transaction transaction : issued) {
                Book book = bookService.getBookById(transaction.getBookId());
                if (book != null && book.getIsbn().equalsIgnoreCase(renewIsbn)) {
                    listed = true;
                    break;
                }
            }
            if (!listed) {
                System.out.println("Invalid ISBN. Please enter an ISBN from the currently issued list.");
                continue;
            }

            try {
                if (bookTransactionService.renewBook(targetMember.getPhone(), renewIsbn, currentUser)) {
                    System.out.println("Book renewed successfully");
                } else {
                    System.out.println("Renewal failed: Unable to renew loan. Please contact library staff.");
                }
                return;
            } catch (IllegalStateException ex) {
                System.out.println("Renewal failed:");
                for (String reason : ex.getMessage().split("\\R- ")) System.out.println("- " + reason);
            }
        }
    }

    public static void handleActivateMembership() {
        User operationUser = getOperationUser();
        if (operationUser == null) {
            System.out.println("Membership activation failed: A valid logged-in member account is required.");
            return;
        }

        Membership existingMembership = membershipService.getActiveMembership(operationUser.getPhone());
        if (existingMembership != null
                && (existingMembership.getEndDate() == null
                || !LocalDate.now().isAfter(existingMembership.getEndDate()))) {
            System.out.println("You already have an active membership. Please use Renew Membership instead.");
            return;
        }

        List<MembershipPlan> plans = membershipPlanService.getAllPlans();
        if (plans.isEmpty()) {
            System.out.println("No membership plans available");
            return;
        }

        for (MembershipPlan plan : plans) {
            System.out.println(plan.getPlanId() + ". " + plan.getPlanName()
                    + " - Rs." + plan.getAmount());
        }

        MembershipPlan selectedPlan = readMembershipPlan("Enter Plan ID");
        if (selectedPlan == null) {
            return;
        }
        int planId = selectedPlan.getPlanId();

        int duration;
        while (true) {
            System.out.println("Enter duration in months (0 to go to Home)");
            String durationInput = sc.nextLine().trim();
            if (durationInput.equals("0")) {
                Main.goHome();
                return;
            }
            try {
                duration = Integer.parseInt(durationInput);
                if (duration <= 0) {
                    System.out.println("Invalid duration. Enter a number greater than zero.");
                    continue;
                }
                break;
            } catch (NumberFormatException ex) {
                System.out.println("Invalid duration. Please enter a whole number.");
            }
        }

        if (selectedPlan != null) {
            double totalCost = selectedPlan.getAmount() * duration;
            System.out.println("Selected Plan: " + selectedPlan.getPlanName());
            System.out.println("Monthly Price: ₹" + selectedPlan.getAmount());
            System.out.println("Duration: " + duration + " months");
            System.out.println("Total Amount: ₹" + totalCost);
        }

        PaymentMethod membershipMethod = UiHelpers.choosePaymentMethod();
        if (membershipMethod == null) {
            return;
        }

        try {
            membershipService.purchaseMembership(
                    operationUser.getPhone(), planId, duration, membershipMethod);
        } catch (IllegalArgumentException ex) {
            System.out.println("Membership activation failed:");
            for (String reason : ex.getMessage().split("\\R")) {
                if (!reason.isBlank()) {
                    System.out.println("- " + reason);
                }
            }
            return;
        }


            Membership activeMem = membershipService.getActiveMembership(operationUser.getPhone());
            System.out.println("Payment Status: SUCCESS");
            System.out.println("Membership Status: " + (activeMem != null ? activeMem.getStatus() : "Unable to reload membership status"));
            if (activeMem != null && activeMem.getEndDate() != null) {
                System.out.println("Membership Expiry Date: " + activeMem.getEndDate());
            }
            System.out.println("Membership activated successfully");

    }

    public static void handleRenewMembership() {
        User operationUser = getOperationUser();
        if (operationUser == null) {
            System.out.println("Membership renewal failed: A valid logged-in member account is required.");
            return;
        }

        Membership currentMembership = membershipService.getActiveMembership(operationUser.getPhone());
        if (currentMembership == null) {
            System.out.println("You do not have an active membership to renew. Please use Activate Membership.");
            return;
        }

        MembershipPlan currentPlan = membershipPlanService.findById(currentMembership.getPlanId());
        System.out.println("You already have an active membership.");
        System.out.println("Current Plan: " + (currentPlan == null ? "Unknown" : currentPlan.getPlanName()));
        System.out.println("Current Membership Expiry: " + currentMembership.getEndDate());
        System.out.println("Renewal duration will be added after the current membership period ends.");
        System.out.println("If you select a different plan, it will become active only after the current plan ends.");

        List<MembershipPlan> renewalPlans = membershipPlanService.getAllPlans();
        if (renewalPlans.isEmpty()) {
            System.out.println("No membership plans available");
            return;
        }

        for (MembershipPlan plan : renewalPlans) {
            System.out.println(plan.getPlanId() + ". " + plan.getPlanName()
                    + " - Rs." + plan.getAmount());
        }

        MembershipPlan selectedRenewalPlan = readMembershipPlan("Enter Plan ID");
        if (selectedRenewalPlan == null) {
            return;
        }
        int renewalPlanId = selectedRenewalPlan.getPlanId();

        int renewalDuration;
        while (true) {
            System.out.println("Enter duration in months (0 to go to Home)");
            String durationInput = sc.nextLine().trim();
            if (durationInput.equals("0")) {
                Main.goHome();
                return;
            }
            try {
                renewalDuration = Integer.parseInt(durationInput);
                if (renewalDuration <= 0) {
                    System.out.println("Invalid duration. Enter a number greater than zero.");
                    continue;
                }
                break;
            } catch (NumberFormatException ex) {
                System.out.println("Invalid duration. Please enter a whole number.");
            }
        }

        if (selectedRenewalPlan != null) {
            double renewalTotalCost = selectedRenewalPlan.getAmount() * renewalDuration;
            System.out.println("Selected Plan: " + selectedRenewalPlan.getPlanName());
            System.out.println("Monthly Price: ₹" + selectedRenewalPlan.getAmount());
            System.out.println("Duration: " + renewalDuration + " months");
            System.out.println("Total Amount: ₹" + renewalTotalCost);
        }

        PaymentMethod renewalMethod = UiHelpers.choosePaymentMethod();
        if (renewalMethod == null) {
            return;
        }


        try {
            membershipService.renewMembership(operationUser.getPhone(), renewalPlanId, renewalDuration, renewalMethod);
        } catch (IllegalArgumentException ex) {
            System.out.println("Membership renewal failed:");
            for (String reason : ex.getMessage().split("\\R")) {
                if (!reason.isBlank()) {
                    System.out.println("- " + reason);
                }
            }
            return;
        }

            Membership activeMem = membershipService.getActiveMembership(operationUser.getPhone());
            System.out.println("Payment Status: SUCCESS");
            System.out.println("Membership Status: " + (activeMem != null ? activeMem.getStatus() : "Unable to reload membership status"));
            if (activeMem != null && activeMem.getEndDate() != null) {
                System.out.println("Membership Expiry Date: " + activeMem.getEndDate());
            }
            if (activeMem != null && activeMem.getPendingPlanId() > 0
                    && activeMem.getPendingPlanStartDate() != null
                    && LocalDate.now().isBefore(activeMem.getPendingPlanStartDate())) {
                MembershipPlan pendingPlan = membershipPlanService.findById(activeMem.getPendingPlanId());
                System.out.println("Next Plan: " + (pendingPlan == null ? "Unknown" : pendingPlan.getPlanName()));
                System.out.println("Next Plan Activation Date: " + activeMem.getPendingPlanStartDate());
                System.out.println("Your current plan remains active until its existing period ends.");
            }
            System.out.println("Membership renewed successfully");

    }

        public static void handleViewCurrentlyRentedBooks() {
        List<Transaction> borrowed =
                bookTransactionService.getCurrentlyBorrowedBooks(getOperationUser().getPhone());
        if (borrowed.isEmpty()) {
            System.out.println("You have no currently issued books");
            return;
        }

        for (Transaction t : borrowed) {
            Book borrowedBook = bookService.getBookById(t.getBookId());
            if (borrowedBook != null) {
                System.out.println("ISBN: " + borrowedBook.getIsbn());
                System.out.println("Title: " + borrowedBook.getTitle());
                System.out.println("Status: " + t.getStatus());
                System.out.println("Due Date: " + t.getDueDate());
                System.out.println("--------------------");
            }
        }
    }

    public static void handleViewBorrowingHistory() {
        List<Transaction> history =
                bookTransactionService.getBorrowingHistory(getOperationUser().getPhone());
        if (history.isEmpty()) {
            System.out.println("No borrowing history found");
            return;
        }

        for (Transaction t : history) {
            Book historyBook = bookService.getBookById(t.getBookId());
            if (historyBook != null) {
                System.out.println("ISBN: " + historyBook.getIsbn());
                System.out.println("Title: " + historyBook.getTitle());
                System.out.println("Status: " + t.getStatus());
                System.out.println("Request Date: " + t.getRequestDate());
                System.out.println("Due Date: " + t.getDueDate());
                System.out.println("--------------------");
            }
        }
    }

    public static void handleManageFines() {
        User operationUser = getOperationUser();
        if (operationUser == null) {
            System.out.println("A valid member account is required to manage fines.");
            return;
        }

        while (true) {
            List<Fine> fineHistory = fineService.getFineHistory(operationUser.getPhone(), currentUser);
            if (fineHistory.isEmpty()) {
                System.out.println("No fines found");
                return;
            }
            List<Fine> outstandingFines = fineService.findOutstandingFines(operationUser.getPhone());
            for (int i = 0; i < fineHistory.size(); i++) {
                Fine fine = fineHistory.get(i);
                Transaction transaction = bookTransactionService.findTransactionById(fine.getTransactionId());
                Book fineBook = transaction == null ? null : bookService.getBookById(transaction.getBookId());
                System.out.println((i + 1) + ". ISBN: "
                        + (fineBook == null ? "Unavailable" : fineBook.getIsbn())
                        + ", Type: " + fine.getType()
                        + ", Amount: Rs." + fine.getAmount()
                        + ", Paid: Rs." + fine.getAmountPaid()
                        + ", Remaining: Rs." + fine.getRemainingAmount()
                        + ", Status: " + fine.getStatus());
            }
            if (outstandingFines.isEmpty()) {
                System.out.println("No outstanding fines to pay");
                return;
            }

            String fineIsbn = readMemberWorkflowInput("Enter the ISBN for the fine you want to pay");
            if (fineIsbn == null) continue;
            Fine activeFine = null;
            for (Fine fine : outstandingFines) {
                Transaction transaction = bookTransactionService.findTransactionById(fine.getTransactionId());
                Book fineBook = transaction == null ? null : bookService.getBookById(transaction.getBookId());
                if (fineBook != null && fineBook.getIsbn().equalsIgnoreCase(fineIsbn)) {
                    activeFine = fine;
                    break;
                }
            }
            if (activeFine == null) {
                System.out.println("No outstanding fine found for that ISBN. Try again.");
                continue;
            }

            System.out.println("Remaining amount: Rs." + activeFine.getRemainingAmount());
            String amountInput = readMemberWorkflowInput("Enter amount to pay");
            if (amountInput == null) continue;
            double amount;
            try {
                amount = Double.parseDouble(amountInput);
            } catch (NumberFormatException ex) {
                System.out.println("Invalid payment amount. Try again.");
                continue;
            }
            if (!Double.isFinite(amount) || amount <= 0 || amount > activeFine.getRemainingAmount()) {
                System.out.println("Invalid payment amount. Enter a positive amount no greater than the remaining balance.");
                continue;
            }

            PaymentMethod fineMethod = null;
            boolean backToFineSelection = false;
            while (fineMethod == null) {
                System.out.println("Select Payment Method: 1. UPI  2. Card  3. Net Banking");
                System.out.println("Enter -1 to go back to fine selection, or 0 to go to Home.");
                int methodChoice = readInt();
                if (methodChoice == 0) Main.goHome();
                if (methodChoice == -1) {
                    backToFineSelection = true;
                    break;
                }
                switch (methodChoice) {
                    case 1: fineMethod = PaymentMethod.UPI; break;
                    case 2: fineMethod = PaymentMethod.CARD; break;
                    case 3: fineMethod = PaymentMethod.NET_BANKING; break;
                    default: System.out.println("Invalid payment method. Please select 1, 2, or 3.");
                }
            }
            if (backToFineSelection || fineMethod == null) continue;

            Payment payment = paymentService.payFine(operationUser.getPhone(), activeFine.getFineId(), amount, fineMethod);
            if (payment != null && payment.getStatus() == PaymentStatus.SUCCESS) {
                System.out.println("Fine payment successful");
            } else {
                System.out.println("Fine payment failed. Please verify your fine balance before trying again.");
            }
            return;
        }
    }

    public static void handleUpdateProfile() {
        while (true) {
            System.out.println("1. Update Name");
            System.out.println("2. Update Email");
            System.out.println("3. Update Phone");
            System.out.println("4. Change Password");
            System.out.println("-1. Back to Member Menu");
            System.out.println("0. Go to Home");
            System.out.println("Enter choice");
            int profileChoice = readInt();
            if (profileChoice == 0) Main.goHome();
            if (profileChoice == -1) return;

            switch (profileChoice) {
                case 1: {
                    String newName;
                    while (true) {
                        newName = readMemberWorkflowInput("Enter new name");
                        if (newName == null) break;
                        if (!newName.isEmpty() && newName.matches("[\\p{L} ]+")) {
                            break;
                        }
                        System.out.println("Name must contain letters and spaces only. Please try again.");
                    }
                    if (newName == null) continue;
                    if (newName.equals(currentUser.getName())) {
                        System.out.println("Unable to update name: New name is identical to your current name.");
                    } else if (userService.updateNameForPhone(newName, getOperationUser().getPhone())) {
                        System.out.println("Name updated successfully");
                    } else {
                        System.out.println("User not found.");
                    }
                    break;
                }
                case 2: {
                    String newEmail = readMemberWorkflowInput("Enter new email");
                    if (newEmail == null) continue;
                    if (!newEmail.matches("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$")) {
                        System.out.println("Invalid email format. Please enter a valid email address.");
                    } else if (newEmail.equalsIgnoreCase(currentUser.getEmail())) {
                        System.out.println("Unable to update email: New email is identical to your current email.");
                    } else if (userService.findByEmail(newEmail) != null) {
                        System.out.println("Unable to update email: This email is already registered.");
                    } else if (userService.changeEmailForPhone(newEmail, getOperationUser().getPhone())) {
                        System.out.println("Email updated successfully");
                    } else {
                        System.out.println("Unable to update email: User not found.");
                    }
                    break;
                }
                case 3: {
                    String newPhone = readMemberWorkflowInput("Enter new phone number");
                    if (newPhone == null) continue;
                    if (!newPhone.matches("\\d{10}")) {
                        System.out.println("Enter a valid 10-digit phone number");
                    } else if (newPhone.equals(currentUser.getPhone())) {
                        System.out.println("Unable to update phone: New phone number is identical to your current phone number.");
                    } else if (userService.findByPhone(newPhone) != null) {
                        System.out.println("Unable to update phone: This phone number is already registered.");
                    } else if (userService.changePhoneForPhone(currentUser.getPhone(), newPhone)) {
                        System.out.println("Phone updated successfully");
                    } else {
                        System.out.println("Unable to update phone: User not found.");
                    }
                    break;
                }
                case 4: {
                    String oldPassword = readMemberWorkflowInput("Enter current password");
                    if (oldPassword == null) continue;
                    String newPassword = readMemberWorkflowInput("Enter new password");
                    if (newPassword == null) continue;
                    if (!isValidPassword(newPassword)) {
                        System.out.println("Password must be at least 8 characters and include an uppercase letter, a number, and a special character.");
                    } else if (!AuthService.verifyPassword(oldPassword, currentUser.getPasswordHash())) {
                        System.out.println("Password change failed: Current password is incorrect.");
                    } else if (AuthService.verifyPassword(newPassword, currentUser.getPasswordHash())) {
                        System.out.println("Password change failed: New password cannot be the same as your current password.");
                    } else if (userService.changePasswordForPhone(getOperationUser().getPhone(), oldPassword, newPassword)) {
                        System.out.println("Password changed successfully");
                    } else {
                        System.out.println("Password change failed: User not found.");
                    }
                    break;
                }
                default:
                    System.out.println("Invalid choice");
            }
        }
    }

    private static boolean isValidPassword(String password) {
        return password != null && password.length() >= 8
                && password.matches(".*[A-Z].*")
                && password.matches(".*\\d.*")
                && password.matches(".*[^A-Za-z0-9].*");
    }

    public static void runForTargetMember(Runnable operation) {
        if (currentUser == null || operation == null) {
            System.out.println("Please log in before performing this operation.");
            return;
        }
        System.out.println("Enter the member's phone number or email (0 to cancel):");
        String identifier = sc.nextLine().trim();
        if (identifier.isEmpty() || identifier.equals("0")) return;

        User target = userService.findByPhone(identifier);
        if (target == null && identifier.contains("@")) {
            target = userService.findByEmail(identifier);
        }
        if (target == null) {
            System.out.println("No account found for that phone number or email.");
            return;
        }
        if (target.getRole() != UserRole.MEMBER) {
            System.out.println("This operation is for member accounts only. The selected account is " + target.getRole() + ".");
            return;
        }
        if (target.getStatus() != UserStatus.ACTIVE) {
            System.out.println("This member account is not active. Activate the account before continuing.");
            return;
        }

        operationTargetUser = target;
        try {
            System.out.println("Selected member: " + target.getName() + " | Phone: " + target.getPhone() + " | Email: " + target.getEmail());
            operation.run();
        } finally {
            operationTargetUser = null;
        }
    }
    private static User operationTargetUser;

    private static User getOperationUser() {

        return operationTargetUser != null ? operationTargetUser : currentUser;
    }
}
