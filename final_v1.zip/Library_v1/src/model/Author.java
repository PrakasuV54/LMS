package model;

import java.util.Objects;

public class Author {
    private final int authorId;
    private String name;
    public Author(int authorId, String name) {
        if (name == null || name.isBlank())
            throw new IllegalArgumentException("Name cannot be blank");
        this.authorId=authorId;
        this.name=name.trim();
    }

    public int getAuthorId() {
        return authorId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        if (name == null || name.isBlank()) throw new IllegalArgumentException("Name cannot be blank");
        this.name = name.trim();
    }















}
