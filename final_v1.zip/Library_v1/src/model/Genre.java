package model;

import java.util.Objects;

public class Genre {
    private final int genreId;
    private String name;
    public Genre(int genreId, String name) {
        if (name == null || name.isBlank())
            throw new IllegalArgumentException("Name cannot be blank");
        this.genreId=genreId;
        this.name=name.trim();
    }

    public int getGenreId() {
        return genreId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        if (name == null || name.isBlank()) throw new IllegalArgumentException("Name cannot be blank");
        this.name = name.trim();
    }















}
