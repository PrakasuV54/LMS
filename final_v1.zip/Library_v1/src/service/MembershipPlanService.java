package service;

import model.MembershipPlan;
import model.User;
import enums.UserRole;
import repository.UserRepository;
import repository.DataStore;
import repository.MembershipPlanRepository;
import java.util.List;


public class MembershipPlanService {
    public static final String DEFAULT_STANDARD_PLAN_NAME = "Standard Plan";
    public static final double DEFAULT_STANDARD_PLAN_PRICE = 399.0;
    public static final String DEFAULT_PREMIUM_PLAN_NAME = "Premium Plan";
    public static final double DEFAULT_PREMIUM_PLAN_PRICE = 599.0;

    private final MembershipPlanRepository membershipPlanRepository;
    private final UserRepository users;


    public MembershipPlanService(MembershipPlanRepository membershipPlanRepository, UserRepository users) {
        if (membershipPlanRepository == null) {
            throw new IllegalArgumentException("Membership plan repository is required");
        }
        this.membershipPlanRepository = membershipPlanRepository;
        this.users = users;
    }



    public MembershipPlan createPlan(User admin, String planName, double amount, int maxBooks,
                                     int loanPeriodDays, double finePerDay,
                                     double lostBookCharge, double damagedBookCharge) {
        if (!isAdmin(admin)) {
            throw new SecurityException("Active administrator privileges required.");
        }
        if (planName == null || planName.isBlank()
                || !Double.isFinite(amount) || amount <= 0 || maxBooks < 1 || loanPeriodDays < 1 || !Double.isFinite(finePerDay) || finePerDay < 0
                || !Double.isFinite(lostBookCharge) || lostBookCharge < 0
                || !Double.isFinite(damagedBookCharge) || damagedBookCharge < 0) {
            throw new IllegalArgumentException(
                    "Plan name is required; amount must be positive; maximum books and loan days must be at least 1; charges cannot be negative.");
        }
        for (MembershipPlan existing : membershipPlanRepository.findAll()) {
            if (existing.getPlanName().equalsIgnoreCase(planName.trim())) {
                throw new IllegalStateException("A membership plan with this name already exists.");
            }
        }
        int planId = DataStore.getMembershipPlanId();
        MembershipPlan plan = new MembershipPlan(planId, planName, amount, maxBooks,
                loanPeriodDays, finePerDay, lostBookCharge, damagedBookCharge);
        membershipPlanRepository.save(plan);
        return plan;
    }

    public MembershipPlan updatePlanPolicies(User admin, int planId, int maxBooks,
                                             int loanPeriodDays, double finePerDay,
                                             double lostBookCharge, double damagedBookCharge) {
        if (!isAdmin(admin)) {
            throw new SecurityException("Active administrator privileges required.");
        }
        if (maxBooks < 1 || loanPeriodDays < 1 || finePerDay < 0
                || lostBookCharge < 0 || damagedBookCharge < 0) {
            throw new IllegalArgumentException(
                    "Maximum books and loan days must be at least 1; charges cannot be negative.");
        }
        MembershipPlan existing = membershipPlanRepository.findById(planId);
        if (existing == null) {
            throw new IllegalStateException("Membership plan not found.");
        }
        MembershipPlan updated = new MembershipPlan(existing.getPlanId(), existing.getPlanName(),
                existing.getAmount(), maxBooks, loanPeriodDays, finePerDay,
                lostBookCharge, damagedBookCharge);
        membershipPlanRepository.save(updated);
        return updated;
    }

    private boolean isAdmin(User admin) {
        if(users == null || admin == null || admin.getRole() != UserRole.ADMIN) return false;
        return true;
    }

    public MembershipPlan findById(int planId) {
        return membershipPlanRepository.findById(planId);
    }


    public List<MembershipPlan> getAllPlans() {
        return membershipPlanRepository.findAll();
    }


}
