package service;

import java.util.Objects;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * Runs membership expiration independently from the overdue-fine scheduler.
 */
public class MembershipExpirationSchedulerService {

    private final MembershipService membershipService;
    private ScheduledExecutorService scheduler;
    private Thread shutdownHook;

    public MembershipExpirationSchedulerService(MembershipService membershipService) {
        this.membershipService = Objects.requireNonNull(
                membershipService, "membershipService must not be null");
    }

    public synchronized void startScheduler() {
        if (scheduler != null && !scheduler.isShutdown()) {
            return;
        }

        scheduler = Executors.newSingleThreadScheduledExecutor(runnable -> {
            Thread thread = new Thread(runnable, "MembershipExpirationSchedulerThread");
            thread.setDaemon(true);
            return thread;
        });

        if (shutdownHook == null) {
            shutdownHook = new Thread(this::stopScheduler,
                    "MembershipExpirationSchedulerShutdownHook");
            try {
                Runtime.getRuntime().addShutdownHook(shutdownHook);
            } catch (IllegalStateException ignored) {
            }
        }

        scheduler.scheduleAtFixedRate(() -> {
            try {
                membershipService.processExpiredMemberships();
            } catch (RuntimeException e) {
                System.out.println("Membership expiration exception");
            }
        }, 0, 6, TimeUnit.HOURS);
    }

    public synchronized void stopScheduler() {
        if (scheduler != null && !scheduler.isShutdown()) {
            scheduler.shutdown();
            try {
                if (!scheduler.awaitTermination(2, TimeUnit.SECONDS)) {
                    scheduler.shutdownNow();
                }
            } catch (InterruptedException e) {
                scheduler.shutdownNow();
                Thread.currentThread().interrupt();
            }
        }
    }
}
