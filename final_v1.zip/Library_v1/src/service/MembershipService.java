package service;

import enums.MembershipStatus;
import enums.PaymentMethod;
import model.Membership;
import model.MembershipPlan;
import model.Payment;
import model.User;
import paymentStrategy.PaymentStrategy;
import repository.DataStore;
import repository.MembershipRepository;
import repository.PaymentRepository;
import repository.UserRepository;
import java.time.LocalDate;

public class  MembershipService {
    private final UserRepository userRepository;
    private final MembershipRepository membershipRepository;
    private final MembershipPlanService membershipPlanService;
    private final PaymentRepository paymentRepository;
    private final PaymentStrategy paymentStrategy;
    private final AuditService auditService;
    private final NotificationService notificationService;


    public MembershipService(UserRepository users, MembershipRepository memberships, MembershipPlanService plans,
    PaymentRepository payments, PaymentStrategy strategy, AuditService auditService,
    NotificationService notificationService) {
        this.userRepository=users;
        this.membershipRepository=memberships;
        this.membershipPlanService=plans;
        this.paymentRepository=payments;
        this.paymentStrategy=strategy;
        this.auditService=auditService;
        this.notificationService=notificationService;
    }

    public void processExpiredMemberships() {
        processExpiredMemberships(LocalDate.now());
    }

    public void processExpiredMemberships(LocalDate asOfDate) {
        if (asOfDate == null) asOfDate = LocalDate.now();
        for (Membership membership : membershipRepository.findAll()) {
            if (membership == null || membership.getStatus() != MembershipStatus.ACTIVE
                    || membership.getEndDate() == null || !asOfDate.isAfter(membership.getEndDate())) {
                continue;
            }
            membership.expire();
            membershipRepository.save(membership);
            if (auditService != null) {
                auditService.record("SYSTEM", "MEMBERSHIP_EXPIRED", "MEMBERSHIP",
                        String.valueOf(membership.getMembershipId()), "Membership end date " + membership.getEndDate());
            }
            sendUserNotification(membership, "Your membership has expired. Please renew or purchase a new membership.");
        }
    }



    private void sendUserNotification(Membership membership, String message) {
        if (notificationService == null || membership == null || userRepository == null) return;
        User user = userRepository.findById(membership.getUserId());
        if (user != null) notificationService.send(user, message);
    }

    public String getPurchaseFailureReason(String phone, int planId, int durationInMonths, PaymentMethod method) {
        java.util.List<String> failures = new java.util.ArrayList<>();
        User user = null;

        if (phone == null || phone.isBlank()) {
            failures.add("Phone number is required.");
        } else {
            user = userRepository.findByPhone(phone.trim());
            if (user == null) {
                failures.add("User account not found.");
                user = null;
            }
        }

        MembershipPlan plan = membershipPlanService.findById(planId);
        if (plan == null || plan.getAmount() <= 0) {
            failures.add("The selected membership plan is invalid or unavailable.");
        }

        if (durationInMonths <= 0) {
            failures.add("Duration must be greater than zero months.");
        }
        if (method == null) {
            failures.add("A payment method must be selected.");
        }

        if (user != null) {
            for (Membership previous : membershipRepository.findByUserId(user.getUserId())) {
                if (previous.getStatus() == MembershipStatus.ACTIVE) {
                    if (previous.getEndDate() == null) {
                        failures.add("The existing membership has no expiry date. Please contact library staff before purchasing another membership.");
                        break;
                    }
                    if (!LocalDate.now().isAfter(previous.getEndDate())) {
                        failures.add("You already have an active membership. Please use Renew Membership to extend or change plans.");
                        break;
                    }
                }
            }
        }

        return failures.isEmpty() ? null : String.join("\n", failures);
    }



    public void purchaseMembership(String phone, int planId, int durationInMonths, PaymentMethod method) {
        String failure = getPurchaseFailureReason(phone, planId, durationInMonths, method);
        if (failure != null) throw new IllegalArgumentException(failure);
        phone = phone.trim();
        User member = userRepository.findByPhone(phone);
        if (member == null) throw new IllegalArgumentException("Member account not found.");
        MembershipPlan planResult = membershipPlanService.findById(planId);
        for (Membership previous : membershipRepository.findByUserId(member.getUserId())) {
            if (previous.getStatus() == MembershipStatus.ACTIVE && previous.getEndDate() != null
                    && LocalDate.now().isAfter(previous.getEndDate())) {
                previous.expire();
                membershipRepository.save(previous);
            }
        }
        int membershipId=DataStore.getMembershipId();
        int paymentId=DataStore.getPaymentId();
        double totalCost = planResult.getAmount() * durationInMonths;
        Payment payment=Payment.forMembership(paymentId,membershipId,phone,totalCost,method);
        paymentRepository.save(payment);
        int gatewayReference = paymentStrategy.pay(totalCost);
        LocalDate start = LocalDate.now();
        Membership membership = new Membership(membershipId, member.getUserId(), planId, start,
                start.plusMonths(durationInMonths), MembershipStatus.ACTIVE, paymentId);
        payment.markSuccess("GATEWAY-" + gatewayReference);
        paymentRepository.save(payment);
        membershipRepository.save(membership);
        if (auditService != null) auditService.record(phone, "MEMBERSHIP_PURCHASED", "MEMBERSHIP", String.valueOf(membershipId), "Plan ID " + planId + ", payment ID " + paymentId);
        sendUserNotification(membership, "Membership activated until " + membership.getEndDate());
    }

    public boolean renewMembership(String phone, int planId, int durationInMonths, PaymentMethod method) {
        String failure = getRenewFailureReason(phone, planId, durationInMonths, method);
        if (failure != null) throw new IllegalArgumentException(failure);
        phone = phone.trim();
        Membership membership = membershipRepository.findActiveByUserId(userRepository.findByPhone(phone).getUserId());
        MembershipPlan plan = membershipPlanService.findById(planId);
        double totalCost = plan.getAmount() * durationInMonths;
        int paymentId = DataStore.getPaymentId();
        Payment payment = Payment.forMembership(paymentId, membership.getMembershipId(), phone, totalCost, method);
        paymentRepository.save(payment);
        int gatewayReference = paymentStrategy.pay(totalCost);
        LocalDate currentEndDate = membership.getEndDate();
        LocalDate baseDate = currentEndDate != null && currentEndDate.isAfter(LocalDate.now())
                ? currentEndDate : LocalDate.now();
        LocalDate newEndDate = baseDate.plusMonths(durationInMonths);
        payment.markSuccess("GATEWAY-" + gatewayReference);
        paymentRepository.save(payment);

        if (membership.getPlanId() == planId) {
            membership.extendCurrentPlan(newEndDate);
        } else {
            LocalDate newPlanStartDate = baseDate.plusDays(1);
            membership.extend(newEndDate);
            membership.schedulePlanChange(planId, newPlanStartDate);
        }
        membershipRepository.save(membership);
        if (auditService != null)
            auditService.record(phone, "MEMBERSHIP_RENEWED", "MEMBERSHIP", String.valueOf(membership.getMembershipId()), "Payment ID " + paymentId + ", new end date " + newEndDate);
        sendUserNotification(membership, "Membership renewed until " + newEndDate);
        return true;
    }



    public String manageMembershipStatus(User staff, String phone, boolean suspend) {
        try {
            if (!isAdminOrStaff(staff)) return "Insufficient permissions. Staff authorization required.";
            if (phone == null || phone.isBlank()) return "Member phone number is required.";
            String memberPhone = phone.trim();
            User memberUser = userRepository.findByPhone(memberPhone);
            if (memberUser == null) return "Member account was not found.";
            Membership membership = null;
            if (suspend) {
                membership = membershipRepository.findActiveByUserId(memberUser.getUserId());
                if (membership == null) return "Member does not have an active membership to suspend.";
            } else {
                for (Membership candidate : membershipRepository.findByUserId(memberUser.getUserId())) {
                    if (candidate.getStatus() == MembershipStatus.SUSPENDED) {
                        membership = candidate;
                        break;
                    }
                }
                if (membership == null) return "No suspended membership found for this member.";
                if (membership.getEndDate() != null && LocalDate.now().isAfter(membership.getEndDate())) {
                    membership.expire();
                    membershipRepository.save(membership);
                    if (auditService != null) {
                        auditService.record(staff.getPhone(), "MEMBERSHIP_EXPIRED", "MEMBERSHIP",
                                String.valueOf(membership.getMembershipId()),
                                "Suspended membership expired before reactivation; member phone " + memberPhone);
                    }
                    sendUserNotification(membership,
                            "Your suspended membership has expired. Please purchase a new membership.");
                    return "The suspended membership has expired. The member must purchase a new membership.";
                }
            }

            if (suspend) membership.suspend();
            else membership.activate();
            membershipRepository.save(membership);


                String action = suspend ? "MEMBERSHIP_SUSPENDED" : "MEMBERSHIP_REACTIVATED";
                auditService.record(staff.getPhone(), action, "MEMBERSHIP",
                        String.valueOf(membership.getMembershipId()), "Member phone " + memberPhone);

            return null;
        } catch (RuntimeException e) {
            return "Unable to update membership status. Please check the membership and try again.";
        }
    }

    private boolean isAdminOrStaff(User staff) {
        if (staff == null || (staff.getRole() != enums.UserRole.ADMIN && staff.getRole() != enums.UserRole.LIBRARIAN)) return false;
        User stored = userRepository.findByPhone(staff.getPhone());
        return stored != null && stored.getUserId() == staff.getUserId() && stored.getRole() == staff.getRole();
    }


    public Membership getActiveMembershipInternal(String phone) {
        if (phone == null || phone.isBlank()) return null;
        User user = userRepository.findByPhone(phone.trim());
        return user == null ? null : membershipRepository.findActiveByUserId(user.getUserId());
    }

    public Membership getActiveMembership(String phone) {
        return getActiveMembershipInternal(phone);
    }

    public String getRenewFailureReason(String phone, int planId, int durationInMonths, PaymentMethod method) {
        java.util.List<String> failures = new java.util.ArrayList<>();
        User user = null;
        Membership active = null;

        if (phone == null || phone.isBlank()) {
            failures.add("Phone number is required.");
        } else {
            user = userRepository.findByPhone(phone.trim());
            if (user == null) {
                failures.add("User account is not active.");
                user = null;
            } else {
                active = membershipRepository.findActiveByUserId(user.getUserId());
                if (active == null) {
                    failures.add("You do not have an active membership to renew. Please use Activate Membership to purchase a plan.");
                } else if (active.getEndDate() == null) {
                    failures.add("The existing membership has no expiry date. Please contact library staff before renewing it.");
                } else if (active.hasPendingPlanChange()) {
                    failures.add("A membership plan change is already scheduled. Please wait until it takes effect before renewing again.");
                }
            }
        }

        MembershipPlan plan = membershipPlanService.findById(planId);
        if (plan == null) {
            failures.add("Invalid membership plan ID: " + planId + ".");
        } else if (plan.getAmount() <= 0) {
            failures.add("The selected membership plan is invalid or unavailable.");
        }

        if (durationInMonths <= 0) {
            failures.add("Duration must be greater than zero months.");
        }
        if (method == null) {
            failures.add("Payment method is required.");
        }

        return failures.isEmpty() ? null : String.join("\n", failures);
    }

}
