package util;

public class IdGenerator {
    private static int userId = 1;
    private static int bookId = 1;
    private static int membershipId = 1;
    private static int membershipPlanId = 1;
    private static int bookCopyId = 1;
    private static int authorId = 1;
    private static int genreId = 1;
    private static int auditId = 1;
    private static int paymentId = 1;
    private static int fineId = 1;
    private static int transactionId = 1;

    private IdGenerator() {
    }

    public static int nextUserId() {
        if (userId <= 0 || userId == Integer.MAX_VALUE) {
            throw new IllegalStateException("ID range exhausted for userId");
        }
        return userId++;
    }

    public static int nextBookId() {
        if (bookId <= 0 || bookId == Integer.MAX_VALUE) {
            throw new IllegalStateException("ID range exhausted for bookId");
        }
        return bookId++;
    }

    public static int nextMembershipId() {
        if (membershipId <= 0 || membershipId == Integer.MAX_VALUE) {
            throw new IllegalStateException("ID range exhausted for membershipId");
        }
        return membershipId++;
    }

    public static int nextMembershipPlanId() {
        if (membershipPlanId <= 0 || membershipPlanId == Integer.MAX_VALUE) {
            throw new IllegalStateException("ID range exhausted for membershipPlanId");
        }
        return membershipPlanId++;
    }

    public static int nextBookCopyId() {
        if (bookCopyId <= 0 || bookCopyId == Integer.MAX_VALUE) {
            throw new IllegalStateException("ID range exhausted for bookCopyId");
        }
        return bookCopyId++;
    }

    public static int nextAuthorId() {
        if (authorId <= 0 || authorId == Integer.MAX_VALUE) {
            throw new IllegalStateException("ID range exhausted for authorId");
        }
        return authorId++;
    }

    public static int nextGenreId() {
        if (genreId <= 0 || genreId == Integer.MAX_VALUE) {
            throw new IllegalStateException("ID range exhausted for genreId");
        }
        return genreId++;
    }

    public static int nextAuditId() {
        if (auditId <= 0 || auditId == Integer.MAX_VALUE) {
            throw new IllegalStateException("ID range exhausted for auditId");
        }
        return auditId++;
    }

    public static int nextPaymentId() {
        if (paymentId <= 0 || paymentId == Integer.MAX_VALUE) {
            throw new IllegalStateException("ID range exhausted for paymentId");
        }
        return paymentId++;
    }

    public static int nextFineId() {
        if (fineId <= 0 || fineId == Integer.MAX_VALUE) {
            throw new IllegalStateException("ID range exhausted for fineId");
        }
        return fineId++;
    }

    public static int nextTransactionId() {
        if (transactionId <= 0 || transactionId == Integer.MAX_VALUE) {
            throw new IllegalStateException("ID range exhausted for transactionId");
        }
        return transactionId++;
    }
}
