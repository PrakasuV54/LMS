package repository;

import model.Membership;
import java.util.*;

public class InMemoryMembershipRepository implements MembershipRepository {
    private final DataStore dataStore;
    public InMemoryMembershipRepository(DataStore dataStore) {
        this.dataStore = Objects.requireNonNull(dataStore);
    }

    @Override
    public void save(Membership membership) {
        if (membership == null) return;
        if (!dataStore.userById.containsKey(membership.getUserId())) {
            throw new IllegalArgumentException("Membership owner does not exist");
        }
        dataStore.memberships.put(membership.getMembershipId(), membership);
    }

    @Override
    public Membership findById(int id) {
        return dataStore.memberships.get(id);
    }

    @Override
    public List<Membership> findByUserId(int userId) {
        List<Membership> result = new ArrayList<>();
        if (userId <= 0) return result;
        for (Membership membership : dataStore.memberships.values()) {
            if (membership.getUserId() == userId) result.add(membership);
        }
        return result;
    }

    @Override
    public Membership findActiveByUserId(int userId) {
        for (Membership membership : findByUserId(userId)) {
            if (membership.isActive()) {
                return membership;
            }
        }
        return null;
    }

    @Override
    public List<Membership> findAll() {
        return new ArrayList<>(dataStore.memberships.values());
    }

    @Override
    public boolean existsById(int id) {
        return dataStore.memberships.containsKey(id);
    }

    @Override
    public void deleteById(int id) {
        dataStore.memberships.remove(id);
    }

    @Override
    public model.MembershipPlan findPlanById(int planId) {
        return dataStore.membershipPlans.get(planId);
    }
}
