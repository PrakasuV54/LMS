package repository;

import model.BookCopy;
import model.Transaction;
import enums.BookCopyStatus;
import enums.TransactionStatus;
import java.util.*;

public class InMemoryTransactionRepository implements TransactionRepository {
    private final DataStore dataStore;

    public InMemoryTransactionRepository(DataStore dataStore) {
        this.dataStore = Objects.requireNonNull(dataStore);
    }

    @Override
    public void save(Transaction t) {
        if (t == null) return;

        
        if (t.isActive() && t.getBookCopyId() > 0) {
            for (Transaction existing : dataStore.transactions.values()) {
                if (existing.getTransactionId() != t.getTransactionId()
                        && existing.isActive()
                        && existing.getBookCopyId() == t.getBookCopyId()) {
                    throw new IllegalStateException("Copy " + t.getBookCopyId()
                            + " is already linked to active transaction "
                            + existing.getTransactionId());
                }
            }
        }

        model.User owner = dataStore.userByPhone.get(t.getUserPhone());
        if (owner != null) {
            t.assignUserId(owner.getUserId());
        }
        dataStore.transactions.put(t.getTransactionId(), t);
    }

    @Override
    public Transaction findById(int id) {
        return dataStore.transactions.get(id);
    }

    @Override
    public List<Transaction> findByUserPhone(String phone) {
        List<Transaction> result = new ArrayList<>();
        if (phone == null) return result;
        for (Transaction transaction : dataStore.transactions.values()) {
            if (phone.equals(transaction.getUserPhone())) result.add(transaction);
        }
        return result;
    }

    @Override
    public List<Transaction> findByBookId(int bookId) {
        List<Transaction> result = new ArrayList<>();
        for (Transaction transaction : dataStore.transactions.values()) {
            if (transaction.getBookId() == bookId) result.add(transaction);
        }
        return result;
    }


    @Override
    public Transaction findActiveByCopyId(int copyId) {
        if (copyId <= 0) return null;
        for (Transaction transaction : dataStore.transactions.values()) {
            if (transaction.isActive() && transaction.getBookCopyId() == copyId) {
                return transaction;
            }
        }
        return null;
    }

    @Override
    public List<Transaction> findAll() {
        return new ArrayList<>(dataStore.transactions.values());
    }

    @Override
    public boolean existsById(int id) {
        return dataStore.transactions.containsKey(id);
    }

    @Override
    public void deleteById(int id) {
        dataStore.transactions.remove(id);
    }

    @Override
    public List<Transaction> findQueuedRequestsByBookId(int bookId) {
        List<Transaction> result = new ArrayList<>();
        for (Transaction transaction : dataStore.transactions.values()) {
            if (transaction.getBookId() == bookId && transaction.getStatus() == TransactionStatus.REQUESTED) {
                result.add(transaction);
            }
        }
        return result;
    }
}
