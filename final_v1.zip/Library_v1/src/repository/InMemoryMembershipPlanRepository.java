package repository;

import model.MembershipPlan;
import java.util.ArrayList;
import java.util.List;

public class InMemoryMembershipPlanRepository implements MembershipPlanRepository {
    private final DataStore dataStore;

    public InMemoryMembershipPlanRepository(DataStore dataStore) {
        this.dataStore = dataStore;
    }

    @Override
    public void save(MembershipPlan plan) {
        if (plan == null) return;
        dataStore.membershipPlans.put(plan.getPlanId(), plan);
    }

    @Override
    public MembershipPlan findById(int planId) {
        return dataStore.membershipPlans.get(planId);
    }

    @Override
    public MembershipPlan findByName(String planName) {
        if (planName == null) {
            return null;
        }
        for (MembershipPlan plan : dataStore.membershipPlans.values()) {
            if (plan.getPlanName().equals(planName)) {
                return plan;
            }
        }
        return null;
    }



    @Override
    public List<MembershipPlan> findAll() {
        return new ArrayList<>(dataStore.membershipPlans.values());
    }

    @Override
    public boolean existsById(int planId) {
        return dataStore.membershipPlans.containsKey(planId);
    }
}
