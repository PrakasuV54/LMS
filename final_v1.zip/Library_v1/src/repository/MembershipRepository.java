package repository;

import model.Membership;
import java.util.List;

public interface MembershipRepository {
    void save(Membership membership);
    Membership findById(int membershipId);
    List<Membership> findByUserId(int userId);
    Membership findActiveByUserId(int userId);
    List<Membership> findAll();
    boolean existsById(int membershipId);
    void deleteById(int membershipId);
    default model.MembershipPlan findPlanById(int planId) {
        return null;
    }
}
