package ui;

import enums.UserRole;
import enums.UserStatus;
import model.User;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import repository.SyntheticData;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.PrintStream;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

import static org.junit.jupiter.api.Assertions.*;

public class NavigationTest {

    private final InputStream originalIn = System.in;
    private final PrintStream originalOut = System.out;
    private ByteArrayOutputStream outContent;

    @BeforeEach
    void setUp() {
        outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));
        SyntheticData data = new SyntheticData(Main.userRepository, Main.membershipPlanRepository, Main.bookService,
                Main.authorRepository, Main.genreRepository, Main.membershipRepository, Main.transactionRepository,
                Main.fineRepository, Main.paymentRepository, Main.auditLogRepository, Main.categoryRepository,
                Main.bookCopyRepository);
        data.syntheticData();
    }

    @AfterEach
    void tearDown() {
        System.setIn(originalIn);
        System.setOut(originalOut);
        Main.currentUser = null;
        Main.sc = new Scanner(System.in);
    }

    private void provideInput(String input) {
        Main.sc = new Scanner(new ByteArrayInputStream(input.getBytes(StandardCharsets.UTF_8)));
    }

    @Test
    void test1_MemberCanReturnHomeFromNestedSearchMenu() {
        User member = Main.userService.findByPhone("9870000001");
        assertNotNull(member);
        Main.currentUser = member;

        // In memberMenu:
        // 2: Search Books -> inside searchBooks, 0: Go to Home -> returns to memberMenu
        // 12: Logout
        provideInput("2\n0\n12\n");
        Member.memberMenu();

        String output = outContent.toString();
        assertTrue(output.contains("Search Options:"));
        assertTrue(output.contains("0.Go to Home"));
        assertTrue(output.contains("Logged out successfully"));
    }

    @Test
    void test2_MemberCanReturnHomeFromBookDetailsOrCatalogue() {
        User member = Main.userService.findByPhone("9870000001");
        Main.currentUser = member;

        // In memberMenu:
        // 1: View All Books -> inside handleBookListInteraction, 0: Go to Home -> returns to memberMenu
        // 12: Logout
        provideInput("1\n0\n12\n");
        Member.memberMenu();

        String output = outContent.toString();
        assertTrue(output.contains("--- Books ("));
        assertTrue(output.contains("0.Go to Home"));
        assertTrue(output.contains("Logged out successfully"));
    }

    @Test
    void test3_LibrarianCanReturnHomeFromInventoryOperation() {
        User librarian = Main.userService.findByPhone("8888888888");
        assertNotNull(librarian);
        Main.currentUser = librarian;

        // 16: Issue Book -> prompt request ID (0 to go back) -> 0 -> returns to librarianMenu
        // 25: Logout
        provideInput("16\n0\n25\n");
        Librarian.librarian();

        String output = outContent.toString();
        assertTrue(output.contains("Librarian Menu"));
        assertTrue(output.contains("Logged out"));
    }

    @Test
    void test4_AdminCanReturnHomeFromAuditLogFiltering() {
        User admin = Main.userService.findByPhone("9999999999");
        assertNotNull(admin);
        Main.currentUser = admin;

        // 28: View Audit Logs -> 1: Filter by role -> 1: Member -> 0: Go to Home -> returns to adminMenu
        // 29: Logout
        provideInput("28\n1\n1\n0\n29\n");
        Admin.admin();

        String output = outContent.toString();
        assertTrue(output.contains("Audit Logs"));
        assertTrue(output.contains("0. Go to Home"));
        assertTrue(output.contains("Admin Menu"));
        assertTrue(output.contains("Logged out"));
    }

    @Test
    void test5_GoingHomePreservesAuthenticatedUserAndRole() {
        User member = Main.userService.findByPhone("9870000001");
        Main.currentUser = member;

        provideInput("0\n");
        assertThrows(GoHomeException.class, UiHelpers::searchBooks);

        assertNotNull(Main.currentUser);
        assertEquals("9870000001", Main.currentUser.getPhone());
        assertEquals(UserRole.MEMBER, Main.currentUser.getRole());
    }

    @Test
    void test6_LogoutClearsAuthenticatedSessionAndReturnsToInitialMenu() {
        User member = Main.userService.findByPhone("9870000001");
        Main.currentUser = member;

        provideInput("12\n");
        Member.memberMenu();

        assertNull(Main.currentUser);
        assertTrue(outContent.toString().contains("Logged out successfully"));
    }

    @Test
    void test7_BackReturnsToImmediateParentMenu() {
        User member = Main.userService.findByPhone("9870000001");
        Main.currentUser = member;

        // Search Books:
        // 2: Search by Field -> 9: Back (returns to searchBooks) -> 3: Back (returns to caller)
        provideInput("2\n9\n3\n");
        UiHelpers.searchBooks();

        String output = outContent.toString();
        assertTrue(output.contains("Search by Field:"));
        assertTrue(output.contains("Search Options:"));
    }

    @Test
    void test8_ExitTerminatesApplication() {
        // Main.main with choice 4: Exit
        provideInput("4\n");
        Main.main(new String[]{});

        assertTrue(outContent.toString().contains("Exiting Library Management System. Goodbye!"));
    }

    @Test
    void test9_ExistingNumericInputsAndCancellationsWorkCorrectly() {
        User member = Main.userService.findByPhone("9870000001");
        Main.currentUser = member;

        // In handleRequestBook, choice 1 (Request directly by ISBN) -> 0 to cancel -> 4 (Back)
        provideInput("1\n0\n4\n");
        Member.handleRequestBook();

        assertTrue(outContent.toString().contains("Enter ISBN (0 to cancel):"));
    }

    @Test
    void test10_ExistingBusinessOperationsRemainUnchanged() {
        // Verify book search returns correct books
        var books = Main.bookService.searchBooks("Clean Code");
        assertFalse(books.isEmpty());
        assertEquals("978-0132350884", books.get(0).getIsbn());
    }

    @Test
    void test11_RepeatedNavigationAvoidsRecursiveMenuGrowthAndStaleLoops() {
        User member = Main.userService.findByPhone("9870000001");
        Main.currentUser = member;

        // Perform multiple nested navigations each returning Home:
        // 1. View all books (1) -> Go Home (0)
        // 2. Search books (2) -> Go Home (0)
        // 3. Request book (3) -> Go Home (0)
        // 4. Update profile (11) -> Go Home (0)
        // 5. Logout (12)
        provideInput("1\n0\n2\n0\n3\n0\n11\n0\n12\n");
        Member.memberMenu();

        assertNull(Main.currentUser);
        String output = outContent.toString();
        assertTrue(output.contains("Logged out successfully"));
    }

    @Test
    void test12_DeeplyNestedSearchInteractionReturnsHomeDirectly() {
        User member = Main.userService.findByPhone("9870000001");
        Main.currentUser = member;

        // From memberMenu:
        // 2: Search Books -> 1: General Search -> query: "Clean" -> handleBookListInteraction -> 0: Go to Home
        // Unwinds directly out of handleBookListInteraction, generalSearch, searchBooks to memberMenu!
        // Then 12: Logout
        provideInput("2\n1\nClean\n0\n12\n");
        Member.memberMenu();

        assertNull(Main.currentUser);
        String output = outContent.toString();
        assertTrue(output.contains("--- Books ("));
        assertTrue(output.contains("Logged out successfully"));
    }
}
