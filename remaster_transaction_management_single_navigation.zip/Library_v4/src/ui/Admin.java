package ui;

import enums.*;
import model.*;

public class Admin extends Main {

    public static void admin() {
        if (currentUser == null || currentUser.getStatus() != UserStatus.ACTIVE || !authService.hasRole(currentUser, UserRole.ADMIN)) {
            System.out.println("Please log in as Admin"); return;
        }
        while (true) {
            System.out.println("\nAdmin Menu");
            System.out.println("1.View All Books");
            System.out.println("2.Search Books");
            System.out.println("3.Request Book");
            System.out.println("4.Cancel Request");
            System.out.println("5.Renew Book");
            System.out.println("6.Activate Membership");
            System.out.println("7.Renew Membership");
            System.out.println("8.View Currently Rented Books");
            System.out.println("9.View Borrowing History");
            System.out.println("10.Fine Management");
            System.out.println("11.Update My Profile");
            System.out.println("12.Add Book");
            System.out.println("13.Remove Book Copy");
            System.out.println("14.Transaction Management");
            System.out.println("15.View Defaulters");
            System.out.println("16.Manage Membership Status");
            System.out.println("17.Manage Payments");
            System.out.println("18.Dashboard");
            System.out.println("19.Manage Users");
            System.out.println("20.Manage Policies");
            System.out.println("21.Manage Membership Plans");
            System.out.println("22.View Audit Logs");
            System.out.println("23.Logout");
            System.out.println("Enter choice");
            int choice = readInt();
            try {
                switch (choice) {
                    case 1: Member.handleViewAllBooks(); break;
                    case 2: Member.handleSearchBooks(); break;
                    case 3: Member.runForTargetMember(Member::handleRequestBook); break;
                    case 4: Member.runForTargetMember(Member::handleCancelRequest); break;
                    case 5: Member.runForTargetMember(Member::handleRenewBook); break;
                    case 6: Member.runForTargetMember(Member::handleActivateMembership); break;
                    case 7: Member.runForTargetMember(Member::handleRenewMembership); break;
                    case 8: Member.runForTargetMember(Member::handleViewCurrentlyRentedBooks); break;
                    case 9: Member.runForTargetMember(Member::handleViewBorrowingHistory); break;
                    case 10: Librarian.handleFineManagementMenu(); break;
                    case 11: Member.runForTargetMember(Member::handleUpdateProfile); break;
                    case 12: Librarian.handleAddBook(); break;
                    case 13: Librarian.handleRemoveBookCopy(); break;
                    case 14: Librarian.handleTransactionManagement(); break;
                    case 15: Librarian.handleViewDefaulters(); break;
                    case 16: Librarian.handleManageMembershipStatus(); break;
                    case 17: Librarian.handleManagePayments(); break;
                    case 18: handleDashboard(); break;
                    case 19: handleManageUsers(); break;
                    case 20: handleManagePolicies(); break;
                    case 21: handleManageMembershipPlans(); break;
                    case 22: handleViewAuditLogs(); break;
                    case 23:
                        currentUser = null;
                        System.out.println("Logged out");
                        return;
                    default:
                        System.out.println("Invalid choice");
                }
            } catch (RuntimeException e) {
                throw e;
            }
        }
    }

    public static void handleDashboard() {
        while (true) {
            System.out.println("Dashboard");
            System.out.println("Enter year for dashboard (0 to go back to Admin Menu):");
            int year = readInt();
            if (year == 0) return;
            try {
                AnalyticsDashboard dashboard = analyticsService.getDashboardForYear(year);
                dashboard.display();
            } catch (RuntimeException e) {
                System.out.println("Unable to display dashboard: " + e.getMessage());
            }
        }
    }

        public static void handleManageUsers() {
        while (true) {
            System.out.println("Manage Users");
            System.out.println("1. View users");
            System.out.println("2. Add librarian");
            System.out.println("3. Add admin");
            System.out.println("4. Activate account");
            System.out.println("5. Deactivate account");
            System.out.println("6. Delete user");
            System.out.println("0. Back to Admin Menu");
            System.out.println("Enter choice:");
            int userChoice = readInt();
            if (userChoice == 0) return;
            if (userChoice < 1 || userChoice > 6) {
                System.out.println("Invalid choice. Please try again.");
                continue;
            }
            try {
                if (userChoice == 1) {
                    java.util.List<User> users = userService.getAllUsers(currentUser);
                    if (users == null || users.isEmpty()) {
                        System.out.println("No users found.");
                    } else {
                        System.out.println("--- Registered Users (" + users.size() + ") ---");
                        for (User user : users) {
                            System.out.println("User ID: " + user.getUserId()
                                    + " | Name: " + user.getName()
                                    + " | Email: " + user.getEmail()
                                    + " | Phone: " + user.getPhone()
                                    + " | Role: " + user.getRole()
                                    + " | Status: " + user.getStatus()
                                    + " | Created: " + user.getCreatedAt());
                        }
                    }
                } else if (userChoice == 2 || userChoice == 3) {
                    System.out.println("Enter name (blank to cancel)");
                    String name = sc.nextLine().trim();
                    if (name.isEmpty()) { System.out.println("Operation cancelled."); continue; }
                    System.out.println("Enter email (blank to cancel)");
                    String email = sc.nextLine().trim();
                    if (email.isEmpty()) { System.out.println("Operation cancelled."); continue; }
                    System.out.println("Enter phone (blank to cancel)");
                    String phone = sc.nextLine().trim();
                    if (phone.isEmpty()) { System.out.println("Operation cancelled."); continue; }
                    System.out.println("Enter password (blank to cancel)");
                    String password = sc.nextLine();
                    if (password.isBlank()) { System.out.println("Operation cancelled."); continue; }
                    if (userChoice == 2) userService.addLibrarian(currentUser, name, email, phone, password);
                    else userService.addAdmin(currentUser, name, email, phone, password);
                    System.out.println("User created successfully.");
                } else {
                    System.out.println("Enter user ID (0 to cancel)");
                    int userId = readInt();
                    if (userId == 0) continue;
                    if (userChoice == 4) userService.activateAccount(currentUser, userId);
                    else if (userChoice == 5) userService.deactivateAccount(currentUser, userId);
                    else userService.deleteUser(currentUser, userId);
                    System.out.println(userChoice == 6 ? "User deleted successfully." : "User updated successfully.");
                }
            } catch (SecurityException | IllegalArgumentException | IllegalStateException e) {
                String action = userChoice == 2 || userChoice == 3 ? "create user"
                        : userChoice == 4 ? "activate account"
                        : userChoice == 5 ? "deactivate account"
                        : userChoice == 6 ? "delete user" : "view users";
                System.out.println("Unable to " + action + ": " + e.getMessage());
            }
        }
    }

        public static void handleManagePolicies() {
        while (true) {
            System.out.println("Manage Policies");
            System.out.println("1. Update policies for a membership plan");
            System.out.println("0. Back to Admin Menu");
            System.out.println("Enter choice:");
            int action = readInt();
            if (action == 0) return;
            if (action != 1) { System.out.println("Invalid choice. Please try again."); continue; }
            try {
                java.util.List<MembershipPlan> plans = membershipPlanService.getAllPlans();
                if (plans == null || plans.isEmpty()) {
                    System.out.println("No membership plans exist. Create a plan first.");
                    continue;
                }
                System.out.println("Select the plan whose policies you want to manage (0 to go back, -1 for Home):");
                for (MembershipPlan plan : plans) {
                    System.out.println("Plan ID: " + plan.getPlanId() + " | " + plan.getPlanName()
                            + " | Max books: " + plan.getMaxBooks()
                            + " | Loan days: " + plan.getLoanPeriodDays()
                            + " | Fine/day: Rs." + plan.getFinePerDay()
                            + " | Lost: Rs." + plan.getLostBookCharge()
                            + " | Damaged: Rs." + plan.getDamagedBookCharge());
                }
                int planId = readInt();
                if (planId == -1) goHome();
                if (planId == 0) continue;
                MembershipPlan selected = membershipPlanService.findById(planId);
                if (selected == null) { System.out.println("Membership plan not found. Please try again."); continue; }
                System.out.println("Managing policies for " + selected.getPlanName() + " (ID " + planId + ")");
                System.out.println("1. Maximum books (" + selected.getMaxBooks() + ")");
                System.out.println("2. Loan days (" + selected.getLoanPeriodDays() + ")");
                System.out.println("3. Fine per day (Rs." + selected.getFinePerDay() + ")");
                System.out.println("4. Lost book charge (Rs." + selected.getLostBookCharge() + ")");
                System.out.println("5. Damaged book charge (Rs." + selected.getDamagedBookCharge() + ")");
                System.out.println("0. Back to policy management");
                int choice = readInt();
                if (choice == 0) continue;
                if (choice < 1 || choice > 5) { System.out.println("Invalid choice. Please try again."); continue; }
                int maxBooks = selected.getMaxBooks();
                int loanDays = selected.getLoanPeriodDays();
                double fine = selected.getFinePerDay();
                double lost = selected.getLostBookCharge();
                double damaged = selected.getDamagedBookCharge();
                switch (choice) {
                    case 1: System.out.println("Enter maximum books allowed (0 to cancel)"); maxBooks = readInt(); if (maxBooks == 0) continue; break;
                    case 2: System.out.println("Enter loan period in days (0 to cancel)"); loanDays = readInt(); if (loanDays == 0) continue; break;
                    case 3: System.out.println("Enter fine per overdue day (-1 to cancel)"); fine = readDouble(); if (fine == -1) continue; break;
                    case 4: System.out.println("Enter lost book charge (-1 to cancel)"); lost = readDouble(); if (lost == -1) continue; break;
                    case 5: System.out.println("Enter damaged book charge (-1 to cancel)"); damaged = readDouble(); if (damaged == -1) continue; break;
                    default: continue;
                }
                MembershipPlan updated = membershipPlanService.updatePlanPolicies(currentUser, planId,
                        maxBooks, loanDays, fine, lost, damaged);
                System.out.println("Policy updated for " + updated.getPlanName() + " only.");
            } catch (SecurityException | IllegalArgumentException | IllegalStateException e) {
                System.out.println("Unable to manage policies: " + e.getMessage());
            }
        }
    }

        public static void handleManageMembershipPlans() {
        while (true) {
            System.out.println("Manage Membership Plans");
            System.out.println("1. View all plans");
            System.out.println("2. Create plan");
            System.out.println("0. Back to Admin Menu");
            System.out.println("Enter choice:");
            int planChoice = readInt();
            if (planChoice == 0) return;
            if (planChoice != 1 && planChoice != 2) {
                System.out.println("Invalid choice. Please try again.");
                continue;
            }
            try {
                if (planChoice == 1) {
                    java.util.List<MembershipPlan> plans = membershipPlanService.getAllPlans();
                    if (plans == null || plans.isEmpty()) {
                        System.out.println("No membership plans exist.");
                    } else {
                        for (MembershipPlan plan : plans) {
                            System.out.println("Plan ID: " + plan.getPlanId() + ", Name: " + plan.getPlanName()
                                    + ", Amount: Rs." + plan.getAmount()
                                    + ", Max books: " + plan.getMaxBooks()
                                    + ", Loan days: " + plan.getLoanPeriodDays()
                                    + ", Fine/day: Rs." + plan.getFinePerDay()
                                    + ", Lost charge: Rs." + plan.getLostBookCharge()
                                    + ", Damaged charge: Rs." + plan.getDamagedBookCharge());
                        }
                    }
                } else {
                    System.out.println("Enter plan name (blank to cancel)");
                    String planName = sc.nextLine().trim();
                    if (planName.isEmpty()) { System.out.println("Operation cancelled."); continue; }
                    System.out.println("Enter plan amount (-1 to cancel)");
                    double planAmount = readDouble();
                    if (planAmount == -1) continue;
                    System.out.println("Enter maximum books that can be borrowed at once (0 to cancel)");
                    int maxBooks = readInt();
                    if (maxBooks == 0) continue;
                    System.out.println("Enter loan period in days (0 to cancel)");
                    int loanDays = readInt();
                    if (loanDays == 0) continue;
                    System.out.println("Enter fine per overdue day (Rs.; -1 to cancel)");
                    double finePerDay = readDouble();
                    if (finePerDay == -1) continue;
                    System.out.println("Enter lost book charge (Rs.; -1 to cancel)");
                    double lostCharge = readDouble();
                    if (lostCharge == -1) continue;
                    System.out.println("Enter damaged book charge (Rs.; -1 to cancel)");
                    double damagedCharge = readDouble();
                    if (damagedCharge == -1) continue;
                    MembershipPlan created = membershipPlanService.createPlan(currentUser, planName, planAmount,
                            maxBooks, loanDays, finePerDay, lostCharge, damagedCharge);
                    System.out.println("Plan created successfully: " + created.getPlanName());
                }
            } catch (SecurityException | IllegalArgumentException | IllegalStateException e) {
                System.out.println("Unable to manage membership plans: " + e.getMessage());
            }
        }
    }
}
