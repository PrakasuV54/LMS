package ui;

import enums.*;
import model.*;

public class Admin extends Main {

    public static void admin() {
        if (currentUser == null || !authService.hasRole(currentUser, UserRole.ADMIN)) {
            System.out.println("Please log in as Admin"); return;
        }
        while (true) {
            System.out.println("\nAdmin Menu");
            System.out.println("1.View All Books");
            System.out.println("2.Search Books");
            System.out.println("3.Request Book");
            System.out.println("4.Cancel Request");
            System.out.println("5.Renew Book");
            System.out.println("6.Activate Membership");
            System.out.println("7.Renew Membership");
            System.out.println("8.View Currently Rented Books");
            System.out.println("9.View Borrowing History");
            System.out.println("10.Fine Management");
            System.out.println("11.Manage User Profile");
            System.out.println("12.Add Book");
            System.out.println("13.Remove Book Copy");
            System.out.println("14.Transaction Management");
            System.out.println("15.View Defaulters");
            System.out.println("16.Manage Membership Status");
            System.out.println("17.Manage Payments");
            System.out.println("18.Dashboard");
            System.out.println("19.Manage Users");
            System.out.println("20.Manage Membership Plans & Policies");
            System.out.println("21.View Audit Logs");
            System.out.println("22.Logout");
            System.out.println("Enter choice");
            int choice = readInt();
            try {
                switch (choice) {
                    case 1: Member.handleViewAllBooks(); break;
                    case 2: Member.handleSearchBooks(); break;
                    case 3: Member.runForTargetMember(Member::handleRequestBook); break;
                    case 4: Member.runForTargetMember(Member::handleCancelRequest); break;
                    case 5: Member.runForTargetMember(Member::handleRenewBook); break;
                    case 6: Member.runForTargetMember(Member::handleActivateMembership); break;
                    case 7: Member.runForTargetMember(Member::handleRenewMembership); break;
                    case 8: Member.runForTargetMember(Member::handleViewCurrentlyRentedBooks); break;
                    case 9: Member.runForTargetMember(Member::handleViewBorrowingHistory); break;
                    case 10: Librarian.handleFineManagementMenu(); break;
                    case 11: Member.runForTargetMember(Member::handleUpdateProfile); break;
                    case 12: Librarian.handleAddBook(); break;
                    case 13: Librarian.handleRemoveBookCopy(); break;
                    case 14: Librarian.handleTransactionManagement(); break;
                    case 15: Librarian.handleViewDefaulters(); break;
                    case 16: Librarian.handleManageMembershipStatus(); break;
                    case 17: Librarian.handleManagePayments(); break;
                    case 18: handleDashboard(); break;
                    case 19: handleManageUsers(); break;
                    case 20: handleManageMembershipPlansAndPolicies(); break;
                    case 21: handleViewAuditLogs(); break;
                    case 22:
                        currentUser = null;
                        System.out.println("Logged out");
                        return;
                    default:
                        System.out.println("Invalid choice");
                }
            } catch (RuntimeException e) {
                if(e!= GO_HOME) throw e;
            }
        }
    }

    public static void handleDashboard() {
        while (true) {
            System.out.println("Dashboard");
            System.out.println("Enter year for dashboard (0 to go back to Admin Menu):");
            int year = readInt();
            if (year == 0) return;
            try {
                AnalyticsDashboard dashboard = analyticsService.getDashboardForYear(year);
                dashboard.display();
            } catch (RuntimeException e) {
                System.out.println("Unable to display dashboard: " + e.getMessage());
            }
        }
    }

        public static void handleManageUsers() {
        while (true) {
            System.out.println("Manage Users");
            System.out.println("1. View users");
            System.out.println("2. Add librarian");
            System.out.println("3. Add admin");
            System.out.println("0. Back to Admin Menu");
            System.out.println("Enter choice:");
            int userChoice = readInt();
            if (userChoice == 0) return;
            if (userChoice < 1 || userChoice > 3) {
                System.out.println("Invalid choice. Please try again.");
                continue;
            }
            try {
                if (userChoice == 1) {
                    java.util.List<User> users = userService.getAllUsers(currentUser);
                    if (users == null || users.isEmpty()) {
                        System.out.println("No users found.");
                    } else {
                        System.out.println("--- Registered Users (" + users.size() + ") ---");
                        for (User user : users) {
                            System.out.println("User ID: " + user.getUserId()
                                    + " | Name: " + user.getName()
                                    + " | Email: " + user.getEmail()
                                    + " | Phone: " + user.getPhone()
                                    + " | Role: " + user.getRole()
                                    + " | Created: " + user.getCreatedAt());
                        }
                    }
                } else if (userChoice == 2 || userChoice == 3) {
                    System.out.println("Enter name (blank to cancel)");
                    String name = sc.nextLine().trim();
                    if (name.isEmpty()) { System.out.println("Operation cancelled."); continue; }
                    System.out.println("Enter email (blank to cancel)");
                    String email = sc.nextLine().trim();
                    if (email.isEmpty()) { System.out.println("Operation cancelled."); continue; }
                    System.out.println("Enter phone (blank to cancel)");
                    String phone = sc.nextLine().trim();
                    if (phone.isEmpty()) { System.out.println("Operation cancelled."); continue; }
                    System.out.println("Enter password (blank to cancel)");
                    String password = sc.nextLine();
                    if (password.isBlank()) { System.out.println("Operation cancelled."); continue; }
                    if (userChoice == 2) userService.addLibrarian(currentUser, name, email, phone, password);
                    else userService.addAdmin(currentUser, name, email, phone, password);
                    System.out.println("User created successfully.");
                }
            } catch (SecurityException | IllegalArgumentException | IllegalStateException e) {
                String action = userChoice == 2 || userChoice == 3 ? "create user" : "view users";
                System.out.println("Unable to " + action + ": " + e.getMessage());
            }
        }
    }

    public static void handleManageMembershipPlansAndPolicies() {
        while (true) {
            System.out.println("\\nManage Membership Plans & Policies");
            System.out.println("1. View existing plan details");
            System.out.println("2. Create membership plan");
            System.out.println("3. Manage plan policies");
            System.out.println("0. Back to Admin Menu");
            System.out.println("-1. Go to Home");
            System.out.println("Enter choice:");
            int choice = readInt();
            if (choice == 0) return;
            if (choice == -1) goHome();
            if (choice < 1 || choice > 3) {
                System.out.println("Invalid choice. Please try again.");
                continue;
            }

            try {
                if (choice == 1) {
                    viewExistingMembershipPlanDetails();
                } else if (choice == 2) {
                    createMembershipPlan();
                } else {
                    manageMembershipPlanPolicies();
                }
            } catch (SecurityException | IllegalArgumentException | IllegalStateException e) {
                System.out.println("Unable to manage membership plans or policies: " + e.getMessage());
            }
        }
    }

    private static java.util.List<MembershipPlan> getMembershipPlansForSelection() {
        java.util.List<MembershipPlan> plans = membershipPlanService.getAllPlans();
        if (plans == null || plans.isEmpty()) {
            System.out.println("No membership plans exist. Create a plan first.");
            return java.util.Collections.emptyList();
        }
        for (MembershipPlan plan : plans) {
            System.out.println("Plan ID: " + plan.getPlanId() + " | " + plan.getPlanName());
        }
        return plans;
    }

    private static MembershipPlan selectMembershipPlan(String prompt) {
        java.util.List<MembershipPlan> plans = getMembershipPlansForSelection();
        if (plans.isEmpty()) return null;

        while (true) {
            System.out.println(prompt + " (0 to go back, -1 to go Home):");
            int planId = readInt();
            if (planId == 0) return null;
            if (planId == -1) goHome();

            MembershipPlan selected = membershipPlanService.findById(planId);
            if (selected == null) {
                System.out.println("Membership plan not found. Please try again.");
                continue;
            }
            return selected;
        }
    }

    private static void viewExistingMembershipPlanDetails() {
        MembershipPlan selected = selectMembershipPlan("Enter plan ID to view details");
        if (selected == null) return;

        System.out.println("\\nMembership Plan Details");
        System.out.println("Plan ID: " + selected.getPlanId());
        System.out.println("Plan name: " + selected.getPlanName());
        System.out.println("Amount: Rs." + selected.getAmount());
        System.out.println("Maximum books: " + selected.getMaxBooks());
        System.out.println("Loan period: " + selected.getLoanPeriodDays() + " days");
        System.out.println("Fine per overdue day: Rs." + selected.getFinePerDay());
        System.out.println("Lost book charge: Rs." + selected.getLostBookCharge());
        System.out.println("Damaged book charge: Rs." + selected.getDamagedBookCharge());
        System.out.println("Enter 0 to return to Membership Plans & Policies, or -1 to go Home:");
        int navigationChoice = readInt();
        if (navigationChoice == -1) goHome();
    }

    private static void createMembershipPlan() {
        String planName = "";
        double planAmount = 0;
        int maxBooks = 0;
        int loanDays = 0;
        double finePerDay = 0;
        double lostCharge = 0;
        double damagedCharge = 0;
        int step = 0;

        while (step < 7) {
            String prompt;
            switch (step) {
                case 0: prompt = "Enter plan name"; break;
                case 1: prompt = "Enter plan amount"; break;
                case 2: prompt = "Enter maximum books that can be borrowed at once"; break;
                case 3: prompt = "Enter loan period in days"; break;
                case 4: prompt = "Enter fine per overdue day (Rs.)"; break;
                case 5: prompt = "Enter lost book charge (Rs.)"; break;
                default: prompt = "Enter damaged book charge (Rs.)";
            }

            System.out.println(prompt + " (-1 to go back, 0 to go Home)");
            String input = sc.nextLine().trim();
            if (input.equals("0")) goHome();
            if (input.equals("-1")) {
                if (step == 0) return;
                step--;
                continue;
            }

            try {
                switch (step) {
                    case 0:
                        if (input.isEmpty()) {
                            System.out.println("Plan name cannot be empty. Please try again.");
                            continue;
                        }
                        planName = input;
                        break;
                    case 1:
                        planAmount = Double.parseDouble(input);
                        if (!Double.isFinite(planAmount) || planAmount <= 0) {
                            System.out.println("Amount must be greater than 0. Please try again.");
                            continue;
                        }
                        break;
                    case 2:
                        maxBooks = Integer.parseInt(input);
                        if (maxBooks < 1) {
                            System.out.println("Maximum books must be at least 1. Please try again.");
                            continue;
                        }
                        break;
                    case 3:
                        loanDays = Integer.parseInt(input);
                        if (loanDays < 1) {
                            System.out.println("Loan period must be at least 1 day. Please try again.");
                            continue;
                        }
                        break;
                    case 4:
                        finePerDay = Double.parseDouble(input);
                        if (!Double.isFinite(finePerDay) || finePerDay < 0) {
                            System.out.println("Fine cannot be negative. Please try again.");
                            continue;
                        }
                        break;
                    case 5:
                        lostCharge = Double.parseDouble(input);
                        if (!Double.isFinite(lostCharge) || lostCharge < 0) {
                            System.out.println("Lost book charge cannot be negative. Please try again.");
                            continue;
                        }
                        break;
                    case 6:
                        damagedCharge = Double.parseDouble(input);
                        if (!Double.isFinite(damagedCharge) || damagedCharge < 0) {
                            System.out.println("Damaged book charge cannot be negative. Please try again.");
                            continue;
                        }
                        break;
                    default:
                        break;
                }
                step++;
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a valid " +
                        (step == 2 || step == 3 ? "whole number." : "number."));
            }
        }

        MembershipPlan created = membershipPlanService.createPlan(currentUser, planName, planAmount,
                maxBooks, loanDays, finePerDay, lostCharge, damagedCharge);
        System.out.println("Plan created successfully: " + created.getPlanName());
    }

    private static void manageMembershipPlanPolicies() {
        MembershipPlan selected = selectMembershipPlan("Select plan whose policies you want to manage");
        if (selected == null) return;

        while (true) {
            System.out.println("\\nManaging policies for " + selected.getPlanName() + " (ID " + selected.getPlanId() + ")");
            System.out.println("1. Maximum books (" + selected.getMaxBooks() + ")");
            System.out.println("2. Loan days (" + selected.getLoanPeriodDays() + ")");
            System.out.println("3. Fine per day (Rs." + selected.getFinePerDay() + ")");
            System.out.println("4. Lost book charge (Rs." + selected.getLostBookCharge() + ")");
            System.out.println("5. Damaged book charge (Rs." + selected.getDamagedBookCharge() + ")");
            System.out.println("0. Back to plan selection");
            System.out.println("-1. Go to Home");
            System.out.println("Enter choice:");
            int choice = readInt();
            if (choice == 0) return;
            if (choice == -1) goHome();
            if (choice < 1 || choice > 5) {
                System.out.println("Invalid choice. Please try again.");
                continue;
            }

            int maxBooks = selected.getMaxBooks();
            int loanDays = selected.getLoanPeriodDays();
            double fine = selected.getFinePerDay();
            double lost = selected.getLostBookCharge();
            double damaged = selected.getDamagedBookCharge();

            switch (choice) {
                case 1:
                    System.out.println("Enter maximum books allowed (-1 to go back, 0 to go Home)");
                    String maxInput = sc.nextLine().trim();
                    if (maxInput.equals("0")) goHome();
                    if (maxInput.equals("-1")) continue;
                    try { maxBooks = Integer.parseInt(maxInput); }
                    catch (NumberFormatException e) { System.out.println("Invalid number of books."); continue; }
                    break;
                case 2:
                    System.out.println("Enter loan period in days (-1 to go back, 0 to go Home)");
                    String loanInput = sc.nextLine().trim();
                    if (loanInput.equals("0")) goHome();
                    if (loanInput.equals("-1")) continue;
                    try { loanDays = Integer.parseInt(loanInput); }
                    catch (NumberFormatException e) { System.out.println("Invalid loan period."); continue; }
                    break;
                case 3:
                    System.out.println("Enter fine per overdue day (-1 to go back, 0 to go Home)");
                    String fineInput = sc.nextLine().trim();
                    if (fineInput.equals("0")) goHome();
                    if (fineInput.equals("-1")) continue;
                    try { fine = Double.parseDouble(fineInput); }
                    catch (NumberFormatException e) { System.out.println("Invalid fine amount."); continue; }
                    break;
                case 4:
                    System.out.println("Enter lost book charge (-1 to go back, 0 to go Home)");
                    String lostInput = sc.nextLine().trim();
                    if (lostInput.equals("0")) goHome();
                    if (lostInput.equals("-1")) continue;
                    try { lost = Double.parseDouble(lostInput); }
                    catch (NumberFormatException e) { System.out.println("Invalid lost book charge."); continue; }
                    break;
                case 5:
                    System.out.println("Enter damaged book charge (-1 to go back, 0 to go Home)");
                    String damagedInput = sc.nextLine().trim();
                    if (damagedInput.equals("0")) goHome();
                    if (damagedInput.equals("-1")) continue;
                    try { damaged = Double.parseDouble(damagedInput); }
                    catch (NumberFormatException e) { System.out.println("Invalid damaged book charge."); continue; }
                    break;
                default:
                    continue;
            }

            MembershipPlan updated = membershipPlanService.updatePlanPolicies(currentUser, selected.getPlanId(),
                    maxBooks, loanDays, fine, lost, damaged);
            System.out.println("Policy updated for " + updated.getPlanName() + " only.");
            selected = membershipPlanService.findById(selected.getPlanId());
            if (selected == null) return;
        }
    }

}
