package model;

import enums.UserRole;
import java.time.LocalDateTime;

public class User {
    private final int userId;
    private String phone;
    private String name;
    private String email;
    private String passwordHash;
    private UserRole role;
    private final LocalDateTime createdAt;
    private int age;
    private String gender;
    public User(String name, String email, String phone, String passwordHash, UserRole role) {
        this(name, email, phone, passwordHash, role, 0, "UNSPECIFIED");
    }

    public User(String name, String email, String phone, String passwordHash, UserRole role, int age, String gender) {
        if(name==null||name.isBlank())
            throw new IllegalArgumentException("Name is required");
        if(email==null||email.isBlank()||!email.contains("@"))
            throw new IllegalArgumentException("Valid email is required");
        if(phone==null||phone.isBlank())
            throw new IllegalArgumentException("Phone is required");
        if(passwordHash==null||passwordHash.isBlank())
            throw new IllegalArgumentException("Password hash is required");
        if(role==null)
            throw new IllegalArgumentException("Role is required");
        this.userId = util.IdGenerator.nextUserId();
        this.name=name.trim();
        this.email=email.trim().toLowerCase();
        this.phone=phone.trim();
        this.passwordHash=passwordHash;
        this.role=role;
        if (age < 0 || age > 120) throw new IllegalArgumentException("Age must be between 0 and 120");
        this.age = age;
        this.gender = gender == null || gender.isBlank() ? "UNSPECIFIED" : gender.trim().toUpperCase();
        this.createdAt=LocalDateTime.now();
    }

    public int getUserId() {
        return userId;
    }

    public String getPhone() {
        return phone;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public String getPasswordHash() {
        return passwordHash;
    }

    public UserRole getRole() {
        return role;
    }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public int getAge() { return age; }
    public String getGender() { return gender; }
    public void setAge(int age) {
        if (age < 0 || age > 120) throw new IllegalArgumentException("Age must be between 0 and 120");
        this.age = age;
    }
    public void setGender(String gender) {
        if (gender == null || gender.isBlank()) throw new IllegalArgumentException("Gender is required");
        this.gender = gender.trim().toUpperCase();
    }

    public void setPhone(String phone) {
        if(phone==null||phone.isBlank())
            throw new IllegalArgumentException("Phone is required");
        this.phone=phone.trim();
    }

    public void setName(String name) {
        if(name==null||name.isBlank())
            throw new IllegalArgumentException("Name is required");
        this.name=name.trim();
    }

    public void setEmail(String email) {
        if(email==null||email.isBlank()||!email.contains("@"))
            throw new IllegalArgumentException("Valid email is required");
        this.email=email.trim().toLowerCase();
    }

    public void setPasswordHash(String hash) {
        if(hash==null||hash.isBlank())
            throw new IllegalArgumentException("Password hash is required");
        passwordHash=hash;
    }

    public void setRole(UserRole role) {
        if(role==null)
            throw new IllegalArgumentException("Role is required");
        this.role=role;
    }

    @Override
    public String toString() {
        return "User ID: " + userId +"\n"
                + " | Name: " + name +"\n"
                + " | Email: " + email +"\n"
                + " | Phone: " + phone +"\n"
                + " | Age: " + (age == 0 ? "Not provided" : age) +"\n"
                + " | Gender: " + gender +"\n"
                + " | Role: " + role +"\n"
                + " | Created: " + createdAt;
    }

}
