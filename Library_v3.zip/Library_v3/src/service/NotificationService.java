package service;

import model.User;

public class NotificationService {
    public NotificationService() {}

    public boolean send(String recipient, String message) {
        if (recipient == null || recipient.isBlank() || message == null || message.isBlank()) {
            return false;
        }
        System.out.println(formatNotificationMessage(null, recipient.trim(), message));
        return true;
    }

    public boolean send(User recipient, String message) {
        if (recipient == null) {
            return false;
        }
        return send(recipient.getName(), recipient.getPhone(), message);
    }

    public boolean send(String recipientName, String recipientPhone, String message) {
        if ((recipientPhone == null || recipientPhone.isBlank()) && (recipientName == null || recipientName.isBlank())) {
            return false;
        }
        if (message == null || message.isBlank()) {
            return false;
        }

        String effectivePhone = (recipientPhone != null && !recipientPhone.isBlank()) ? recipientPhone.trim() : null;
        String effectiveName = (recipientName != null && !recipientName.isBlank()) ? recipientName.trim() : null;
        System.out.println(formatNotificationMessage(effectiveName, effectivePhone, message));
        return true;
    }

    public static String formatNotificationMessage(String recipientName, String recipientPhone, String message) {
        if (message == null) {
            return "";
        }
        if (message.startsWith("Notification for:")) {
            return message;
        }

        String name = (recipientName != null && !recipientName.isBlank()) ? recipientName.trim() : null;
        String phone = (recipientPhone != null && !recipientPhone.isBlank()) ? recipientPhone.trim() : null;

        if (name != null && name.matches("\\d+")) {
            name = "Member (ID: " + name + ")";
        }

        String header;
        if (name != null && phone != null && !name.equalsIgnoreCase(phone)) {
            header = "Notification for: " + name + " (Phone: " + phone + ")";
        } else if (phone != null) {
            header = "Notification for: " + phone;
        } else if (name != null) {
            header = "Notification for: " + name;
        } else {
            header = "Notification for: Unknown";
        }

        return header + "\nMessage: " + message;
    }
}
