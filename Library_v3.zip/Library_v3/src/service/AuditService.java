package service;

import model.Audit;
import repository.AuditLogRepository;
import repository.DataStore;
import repository.UserRepository;
import enums.UserRole;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class AuditService {
    private final AuditLogRepository repository;
    private final UserRepository users;

    public AuditService(AuditLogRepository repository) {
        this(repository, null);
    }

    public AuditService(AuditLogRepository repository, UserRepository users) {
        this.repository = repository;
        this.users = users;
    }

    public Audit record(String actorPhone,String action,String entityType,String entityId,String details) {
        Audit audit=new Audit(DataStore.getAuditId(),actorPhone,action,entityType,entityId,details);
        repository.save(audit);
        return audit;
    }

    public List<Audit> findAll() {
        return repository.findAll();
    }


    public List<Audit> findFiltered(LocalDateTime startInclusive, LocalDateTime endExclusive, UserRole role) {
        List<Audit> filtered = new ArrayList<>();
        for (Audit audit : repository.findAll()) {
            LocalDateTime timestamp = audit.getTimestamp();
            if (startInclusive != null && (timestamp == null || timestamp.isBefore(startInclusive))) continue;
            if (endExclusive != null && (timestamp == null || !timestamp.isBefore(endExclusive))) continue;
            if (role != null) {
                if (users == null || audit.getUserPhone() == null) continue;
                model.User actor = users.findByPhone(audit.getUserPhone());
                if (actor == null || actor.getRole() != role) continue;
            }
            filtered.add(audit);
        }
        filtered.sort(Comparator.comparing(Audit::getTimestamp,
                Comparator.nullsLast(Comparator.naturalOrder())).reversed());
        return filtered;
    }

    public List<Audit> findByUserPhone(String phone) {
        return repository.findByUserPhone(phone);
    }
}
