package ui;
import model.*;
import enums.*;
import service.AnalyticsService;
import service.AuthService;
import service.BookService;
import service.BookTransactionService;

import java.util.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.YearMonth;

import repository.*;
import service.*;
import authentication.*;
import paymentStrategy.*;

import  repository.SyntheticData.*;

public class Main {

    static Scanner sc = new Scanner(System.in);
    static User currentUser = null;


    static final RuntimeException GO_HOME = new RuntimeException("GO_HOME");

    public static void goHome() {
        throw GO_HOME;
    }

    public static int readInt() {
        while (true) {
            String line = sc.nextLine().trim();
            if (line.isEmpty()) continue;
            try {
                return Integer.parseInt(line);
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a valid number:");
            }
        }
    }

    public static double readDouble() {
        while (true) {
            String line = sc.nextLine().trim();
            if (line.isEmpty()) continue;
            try {
                return Double.parseDouble(line);
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a valid amount:");
            }
        }
    }



    public static void main(String[] args) {
        membershipExpirationSchedulerService.startScheduler();
        SyntheticData data = new SyntheticData(userRepository, membershipPlanRepository, bookService,
                authorRepository, genreRepository, membershipRepository, transactionRepository, fineRepository,
                paymentRepository, auditLogRepository, bookCopyRepository);
        data.syntheticData();

        while (true) {
            currentUser = null;
            System.out.println("\n========== LIBRARY MANAGEMENT SYSTEM ==========");
            System.out.println("1. Login");
            System.out.println("2. Register");
            System.out.println("0. Exit");
            System.out.println("Enter choice:");

            int choice = readInt();
            switch (choice) {
                case 1:
                    try {
                        loginUser();
                    } catch (RuntimeException e) {
                        if (e != GO_HOME) throw e;
                    }
                    break;
                case 2:
                    Member.registerMember();
                    break;
                case 0:
                    System.out.println("Exiting Library Management System. Goodbye!");
                    return;
                default:
                    System.out.println("Invalid choice. Please select 1, 2, or 0.");
            }
        }
    }

    private static void loginUser() {
        User user;

        while (true) {
            System.out.println("Enter phone or email (0 to go back):");
            String identifier = sc.nextLine().trim();
            if (identifier.equals("0")) return;

            User identifiedUser = findUserByIdentifier(identifier);
            if (identifiedUser == null) {
                System.out.println("No account found with that phone number or email. Please try again.");
                continue;
            }

            while (true) {
                System.out.println("Enter password (0 to go back):");
                String password = sc.nextLine();
                if (password.equals("0")) break;

                user = authService.login(identifier, password);
                if (user == null) {
                    System.out.println("Incorrect password. Please try again, or enter 0 to go back.");
                    continue;
                }

                currentUser = user;
                System.out.println("Login successful.");

                switch (user.getRole()) {
                    case MEMBER:
                        Member.memberMenu();
                        break;
                    case LIBRARIAN:
                        Librarian.librarian();
                        break;
                    case ADMIN:
                        Admin.admin();
                        break;
                    default:
                        System.out.println("Login failed: Unsupported account role.");
                        currentUser = null;
                }
                return;
            }
        }
    }

    public static void handleViewAuditLogs() {
        UserRole roleFilter = null;
        Integer selectedYear = null;
        Integer selectedMonth = null;

        displayAuditRecords(getFilteredAuditLogs(selectedYear, selectedMonth, roleFilter));

        while (true) {
            System.out.println("\nAudit Logs");
            System.out.println("1. Filter by role");
            System.out.println("2. Filter by year");
            if (selectedYear != null) {
                System.out.println("3. Filter by month");
                System.out.println("4. Clear filters");
            } else {
                System.out.println("3. Clear filters");
            }
            System.out.println("0. Back to previous menu");
            System.out.println("Enter choice:");
            int choice = readInt();
            if (choice == 0) return;

            if (choice == 1) {
                System.out.println("Role: 1.Member  2.Librarian  3.Admin");
                int roleChoice = readInt();
                if (roleChoice < 1 || roleChoice > 3) {
                    System.out.println("Invalid role.");
                    continue;
                }
                roleFilter = roleChoice == 1 ? UserRole.MEMBER
                        : roleChoice == 2 ? UserRole.LIBRARIAN : UserRole.ADMIN;
                displayAuditRecords(getFilteredAuditLogs(selectedYear, selectedMonth, roleFilter));
            } else if (choice == 2) {
                System.out.println("Year (YYYY):");
                try {
                    int year = Integer.parseInt(sc.nextLine().trim());
                    selectedYear = year;
                    selectedMonth = null;
                    displayAuditRecords(getFilteredAuditLogs(selectedYear, selectedMonth, roleFilter));
                } catch (NumberFormatException e) {
                    System.out.println("Invalid year.");
                }
            } else if (selectedYear != null && choice == 3) {
                System.out.println("Select Month:");
                for (int i = 0; i < AnalyticsDashboard.MONTH_NAMES.length; i++) {
                    System.out.println((i + 1) + ". " + AnalyticsDashboard.MONTH_NAMES[i]);
                }
                System.out.println("Enter month (1-12):");
                int monthChoice = readInt();
                if (monthChoice < 1 || monthChoice > 12) {
                    System.out.println("Invalid month.");
                    continue;
                }
                selectedMonth = monthChoice;
                displayAuditRecords(getFilteredAuditLogs(selectedYear, selectedMonth, roleFilter));
            } else if ((selectedYear != null && choice == 4) || (selectedYear == null && choice == 3)) {
                roleFilter = null;
                selectedYear = null;
                selectedMonth = null;
                displayAuditRecords(getFilteredAuditLogs(selectedYear, selectedMonth, roleFilter));
            } else {
                System.out.println("Invalid choice.");
            }
        }
    }

    private static List<Audit> getFilteredAuditLogs(Integer year, Integer month, UserRole role) {
        LocalDateTime start = null;
        LocalDateTime end = null;
        if (year != null) {
            if (month != null) {
                start = LocalDate.of(year, month, 1).atStartOfDay();
                end = YearMonth.of(year, month).plusMonths(1).atDay(1).atStartOfDay();
            } else {
                start = LocalDate.of(year, 1, 1).atStartOfDay();
                end = LocalDate.of(year + 1, 1, 1).atStartOfDay();
            }
        }
        return auditService.findFiltered(start, end, role);
    }

    private static void displayAuditRecords(List<Audit> filtered) {
        if (filtered == null || filtered.isEmpty()) {
            System.out.println("No audit records found.");
            return;
        }

        System.out.printf("%-7s %-20s %-12s %-18s %-20s %-19s %s%n",
                "ID", "Actor phone", "Role", "Action", "Entity", "Timestamp", "Details");
        for (Audit audit : filtered) {
            User actor = audit.getUserPhone() == null ? null : userService.findByPhone(audit.getUserPhone());
            String actorRole = actor == null ? "UNKNOWN" : actor.getRole().name();
            String entity = audit.getEntityType() + (audit.getEntityId() == null ? "" : "#" + audit.getEntityId());
            System.out.printf("%-7d %-20s %-12s %-18s %-20s %-19s %s%n",
                    audit.getAuditId(),
                    audit.getUserPhone() == null ? "-" : audit.getUserPhone(),
                    actorRole,
                    truncateAudit(audit.getAction(), 17),
                    truncateAudit(entity, 19),
                    audit.getTimestamp().toString().replace('T', ' '),
                    audit.getDetails() == null ? "-" : audit.getDetails());
        }
        System.out.println("Records: " + filtered.size());
    }

    private static String truncateAudit(String value, int maxLength) {
        if (value == null) return "-";
        return value.length() <= maxLength ? value : value.substring(0, maxLength - 1) + "…";
    }



    static User findUserByIdentifier(String identifier) {
        User user = userService.findByPhone(identifier);
        if (user == null) user = userService.findByEmail(identifier);
        return user;
    }



    




    static DataStore dataStore = new DataStore();
    static UserRepository userRepository = new InMemoryUserRepository(dataStore);
    static AuthorRepository authorRepository = new InMemoryAuthorRepository(dataStore);
    static GenreRepository genreRepository = new InMemoryGenreRepository(dataStore);
    static BookRepository bookRepository = new InMemoryBookRepository(dataStore);
    static BookCopyRepository bookCopyRepository = new InMemoryBookCopyRepository(dataStore);
    static TransactionRepository transactionRepository = new InMemoryTransactionRepository(dataStore);
    static MembershipRepository membershipRepository = new InMemoryMembershipRepository(dataStore);
    static FineRepository fineRepository = new InMemoryFineRepository(dataStore);
    static PaymentRepository paymentRepository = new InMemoryPaymentRepository(dataStore);
    static MembershipPlanRepository membershipPlanRepository = new InMemoryMembershipPlanRepository(dataStore);
    static AuditLogRepository auditLogRepository = new InMemoryAuditLogRepository(dataStore);
    static AuditService auditService = new AuditService(auditLogRepository, userRepository);
    static NotificationService notificationService = new NotificationService();
    static PolicyService policyService = new PolicyService(userRepository, membershipRepository, transactionRepository, fineRepository, auditService, membershipPlanRepository);
    static FineService fineService = new FineService(fineRepository, transactionRepository, policyService, auditService);
    static UserService userService = new UserService(userRepository, auditService);
    static AuthService authService = new AuthService(userService, userRepository, new PasswordAuthentication(), auditService);
    static BookService bookService = new BookService(bookRepository, bookCopyRepository, transactionRepository,
            auditService, authorRepository, genreRepository);
    static BookTransactionService bookTransactionService = new BookTransactionService(bookRepository, bookCopyRepository, transactionRepository, policyService, auditService, notificationService, fineService, userRepository);
    static PaymentService paymentService = new PaymentService(paymentRepository, fineRepository, new Razorpay(), auditService, membershipRepository, transactionRepository);
    static MembershipPlanService membershipPlanService = new MembershipPlanService(membershipPlanRepository, userRepository);
    static MembershipService membershipService = new MembershipService(userRepository, membershipRepository, membershipPlanService, paymentRepository, new Razorpay(), auditService, notificationService);
    static MembershipExpirationSchedulerService membershipExpirationSchedulerService =
            new MembershipExpirationSchedulerService(membershipService);
    static AnalyticsService analyticsService = new AnalyticsService(bookRepository, transactionRepository, userRepository, paymentRepository, bookCopyRepository, membershipRepository, fineRepository, membershipPlanRepository);

}
